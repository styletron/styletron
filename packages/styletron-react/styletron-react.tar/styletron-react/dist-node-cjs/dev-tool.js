"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.NoopDebugEngine = exports.DebugEngine = void 0;
exports.addDebugMetadata = addDebugMetadata;
exports.setupDevtoolsExtension = void 0;

/* eslint-env browser */

/* global module */
function addDebugMetadata(instance, stackIndex) {
  // @ts-expect-error todo: stacktrace does not exist on error (non standard browser?)
  const {
    stack,
    stacktrace,
    message
  } = new Error("stacktrace source");
  instance.debug = {
    stackInfo: {
      stack,
      stacktrace,
      message
    },
    stackIndex: stackIndex
  };
} // DEVTOOLS SETUP


const setupDevtoolsExtension = () => {
  const atomicMap = {};
  const extensionsMap = new Map();
  const stylesMap = new Map();

  const getStyles = className => {
    const styles = {};

    if (typeof className !== "string") {
      return styles;
    }

    if (stylesMap.has(className)) {
      styles.styles = stylesMap.get(className);
      const classList = className.split(" ");

      if (classList.length) {
        const classes = {};
        classList.forEach(singleClassName => {
          classes[singleClassName] = atomicMap[singleClassName];
        });
        styles.classes = classes;
      }

      if (extensionsMap.has(className)) {
        const extension = extensionsMap.get(className);
        styles.extends = extension;
      }

      return styles;
    }
  };

  window.__STYLETRON_DEVTOOLS__ = {
    atomicMap,
    extensionsMap,
    stylesMap,
    getStyles
  };
}; // todo: export debug engine interface


exports.setupDevtoolsExtension = setupDevtoolsExtension;

class NoopDebugEngine {
  debug() {
    return;
  }

}

exports.NoopDebugEngine = NoopDebugEngine;
const DebugEngine = NoopDebugEngine;
exports.DebugEngine = DebugEngine;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJhZGREZWJ1Z01ldGFkYXRhIiwiaW5zdGFuY2UiLCJzdGFja0luZGV4Iiwic3RhY2siLCJzdGFja3RyYWNlIiwibWVzc2FnZSIsIkVycm9yIiwiZGVidWciLCJzdGFja0luZm8iLCJzZXR1cERldnRvb2xzRXh0ZW5zaW9uIiwiYXRvbWljTWFwIiwiZXh0ZW5zaW9uc01hcCIsIk1hcCIsInN0eWxlc01hcCIsImdldFN0eWxlcyIsImNsYXNzTmFtZSIsInN0eWxlcyIsImhhcyIsImdldCIsImNsYXNzTGlzdCIsInNwbGl0IiwibGVuZ3RoIiwiY2xhc3NlcyIsImZvckVhY2giLCJzaW5nbGVDbGFzc05hbWUiLCJleHRlbnNpb24iLCJleHRlbmRzIiwid2luZG93IiwiX19TVFlMRVRST05fREVWVE9PTFNfXyIsIk5vb3BEZWJ1Z0VuZ2luZSIsIkRlYnVnRW5naW5lIl0sInNvdXJjZXMiOlsic3JjL2Rldi10b29sLnRzIl0sInNvdXJjZXNDb250ZW50IjpbIi8qIGVzbGludC1lbnYgYnJvd3NlciAqL1xuLyogZ2xvYmFsIG1vZHVsZSAqL1xuXG5leHBvcnQgZnVuY3Rpb24gYWRkRGVidWdNZXRhZGF0YShpbnN0YW5jZSwgc3RhY2tJbmRleCkge1xuICAvLyBAdHMtZXhwZWN0LWVycm9yIHRvZG86IHN0YWNrdHJhY2UgZG9lcyBub3QgZXhpc3Qgb24gZXJyb3IgKG5vbiBzdGFuZGFyZCBicm93c2VyPylcbiAgY29uc3Qge3N0YWNrLCBzdGFja3RyYWNlLCBtZXNzYWdlfSA9IG5ldyBFcnJvcihcInN0YWNrdHJhY2Ugc291cmNlXCIpO1xuICBpbnN0YW5jZS5kZWJ1ZyA9IHtcbiAgICBzdGFja0luZm86IHtzdGFjaywgc3RhY2t0cmFjZSwgbWVzc2FnZX0sXG4gICAgc3RhY2tJbmRleDogc3RhY2tJbmRleCxcbiAgfTtcbn1cblxuLy8gREVWVE9PTFMgU0VUVVBcbnR5cGUgU3R5bGV0cm9uU3R5bGVzID0ge1xuICBjbGFzc2VzPzogYW55O1xuICBzdHlsZXM/OiBhbnk7XG4gIGV4dGVuZHM/OiBhbnk7XG59O1xuXG5leHBvcnQgY29uc3Qgc2V0dXBEZXZ0b29sc0V4dGVuc2lvbiA9ICgpID0+IHtcbiAgY29uc3QgYXRvbWljTWFwID0ge307XG4gIGNvbnN0IGV4dGVuc2lvbnNNYXAgPSBuZXcgTWFwKCk7XG4gIGNvbnN0IHN0eWxlc01hcCA9IG5ldyBNYXAoKTtcbiAgY29uc3QgZ2V0U3R5bGVzOiAoY2xhc3NOYW1lOiBzdHJpbmcpID0+IFN0eWxldHJvblN0eWxlcyA9IGNsYXNzTmFtZSA9PiB7XG4gICAgY29uc3Qgc3R5bGVzOiBTdHlsZXRyb25TdHlsZXMgPSB7fTtcbiAgICBpZiAodHlwZW9mIGNsYXNzTmFtZSAhPT0gXCJzdHJpbmdcIikge1xuICAgICAgcmV0dXJuIHN0eWxlcztcbiAgICB9XG4gICAgaWYgKHN0eWxlc01hcC5oYXMoY2xhc3NOYW1lKSkge1xuICAgICAgc3R5bGVzLnN0eWxlcyA9IHN0eWxlc01hcC5nZXQoY2xhc3NOYW1lKTtcbiAgICAgIGNvbnN0IGNsYXNzTGlzdCA9IGNsYXNzTmFtZS5zcGxpdChcIiBcIik7XG4gICAgICBpZiAoY2xhc3NMaXN0Lmxlbmd0aCkge1xuICAgICAgICBjb25zdCBjbGFzc2VzID0ge307XG4gICAgICAgIGNsYXNzTGlzdC5mb3JFYWNoKHNpbmdsZUNsYXNzTmFtZSA9PiB7XG4gICAgICAgICAgY2xhc3Nlc1tzaW5nbGVDbGFzc05hbWVdID0gYXRvbWljTWFwW3NpbmdsZUNsYXNzTmFtZV07XG4gICAgICAgIH0pO1xuICAgICAgICBzdHlsZXMuY2xhc3NlcyA9IGNsYXNzZXM7XG4gICAgICB9XG4gICAgICBpZiAoZXh0ZW5zaW9uc01hcC5oYXMoY2xhc3NOYW1lKSkge1xuICAgICAgICBjb25zdCBleHRlbnNpb24gPSBleHRlbnNpb25zTWFwLmdldChjbGFzc05hbWUpO1xuICAgICAgICBzdHlsZXMuZXh0ZW5kcyA9IGV4dGVuc2lvbjtcbiAgICAgIH1cbiAgICAgIHJldHVybiBzdHlsZXM7XG4gICAgfVxuICB9O1xuICB3aW5kb3cuX19TVFlMRVRST05fREVWVE9PTFNfXyA9IHtcbiAgICBhdG9taWNNYXAsXG4gICAgZXh0ZW5zaW9uc01hcCxcbiAgICBzdHlsZXNNYXAsXG4gICAgZ2V0U3R5bGVzLFxuICB9O1xufTtcblxuLy8gdG9kbzogZXhwb3J0IGRlYnVnIGVuZ2luZSBpbnRlcmZhY2VcbmV4cG9ydCBjbGFzcyBOb29wRGVidWdFbmdpbmUge1xuICBkZWJ1ZygpOiB1bmRlZmluZWQge1xuICAgIHJldHVybjtcbiAgfVxufVxuXG5leHBvcnQgY29uc3QgRGVidWdFbmdpbmUgPSBOb29wRGVidWdFbmdpbmU7XG4iXSwibWFwcGluZ3MiOiI7Ozs7Ozs7OztBQUFBOztBQUNBO0FBRU8sU0FBU0EsZ0JBQVQsQ0FBMEJDLFFBQTFCLEVBQW9DQyxVQUFwQyxFQUFnRDtFQUNyRDtFQUNBLE1BQU07SUFBQ0MsS0FBRDtJQUFRQyxVQUFSO0lBQW9CQztFQUFwQixJQUErQixJQUFJQyxLQUFKLENBQVUsbUJBQVYsQ0FBckM7RUFDQUwsUUFBUSxDQUFDTSxLQUFULEdBQWlCO0lBQ2ZDLFNBQVMsRUFBRTtNQUFDTCxLQUFEO01BQVFDLFVBQVI7TUFBb0JDO0lBQXBCLENBREk7SUFFZkgsVUFBVSxFQUFFQTtFQUZHLENBQWpCO0FBSUQsQyxDQUVEOzs7QUFPTyxNQUFNTyxzQkFBc0IsR0FBRyxNQUFNO0VBQzFDLE1BQU1DLFNBQVMsR0FBRyxFQUFsQjtFQUNBLE1BQU1DLGFBQWEsR0FBRyxJQUFJQyxHQUFKLEVBQXRCO0VBQ0EsTUFBTUMsU0FBUyxHQUFHLElBQUlELEdBQUosRUFBbEI7O0VBQ0EsTUFBTUUsU0FBaUQsR0FBR0MsU0FBUyxJQUFJO0lBQ3JFLE1BQU1DLE1BQXVCLEdBQUcsRUFBaEM7O0lBQ0EsSUFBSSxPQUFPRCxTQUFQLEtBQXFCLFFBQXpCLEVBQW1DO01BQ2pDLE9BQU9DLE1BQVA7SUFDRDs7SUFDRCxJQUFJSCxTQUFTLENBQUNJLEdBQVYsQ0FBY0YsU0FBZCxDQUFKLEVBQThCO01BQzVCQyxNQUFNLENBQUNBLE1BQVAsR0FBZ0JILFNBQVMsQ0FBQ0ssR0FBVixDQUFjSCxTQUFkLENBQWhCO01BQ0EsTUFBTUksU0FBUyxHQUFHSixTQUFTLENBQUNLLEtBQVYsQ0FBZ0IsR0FBaEIsQ0FBbEI7O01BQ0EsSUFBSUQsU0FBUyxDQUFDRSxNQUFkLEVBQXNCO1FBQ3BCLE1BQU1DLE9BQU8sR0FBRyxFQUFoQjtRQUNBSCxTQUFTLENBQUNJLE9BQVYsQ0FBa0JDLGVBQWUsSUFBSTtVQUNuQ0YsT0FBTyxDQUFDRSxlQUFELENBQVAsR0FBMkJkLFNBQVMsQ0FBQ2MsZUFBRCxDQUFwQztRQUNELENBRkQ7UUFHQVIsTUFBTSxDQUFDTSxPQUFQLEdBQWlCQSxPQUFqQjtNQUNEOztNQUNELElBQUlYLGFBQWEsQ0FBQ00sR0FBZCxDQUFrQkYsU0FBbEIsQ0FBSixFQUFrQztRQUNoQyxNQUFNVSxTQUFTLEdBQUdkLGFBQWEsQ0FBQ08sR0FBZCxDQUFrQkgsU0FBbEIsQ0FBbEI7UUFDQUMsTUFBTSxDQUFDVSxPQUFQLEdBQWlCRCxTQUFqQjtNQUNEOztNQUNELE9BQU9ULE1BQVA7SUFDRDtFQUNGLENBckJEOztFQXNCQVcsTUFBTSxDQUFDQyxzQkFBUCxHQUFnQztJQUM5QmxCLFNBRDhCO0lBRTlCQyxhQUY4QjtJQUc5QkUsU0FIOEI7SUFJOUJDO0VBSjhCLENBQWhDO0FBTUQsQ0FoQ00sQyxDQWtDUDs7Ozs7QUFDTyxNQUFNZSxlQUFOLENBQXNCO0VBQzNCdEIsS0FBSyxHQUFjO0lBQ2pCO0VBQ0Q7O0FBSDBCOzs7QUFNdEIsTUFBTXVCLFdBQVcsR0FBR0QsZUFBcEIifQ==