"use strict";

var _enzyme = _interopRequireDefault(require("enzyme"));

var _enzymeAdapterReact = _interopRequireDefault(require("enzyme-adapter-react-16"));

var React = _interopRequireWildcard(require("react"));

var _index = require("../index");

var _styletronStandard = require("styletron-standard");

function _getRequireWildcardCache(nodeInterop) { if (typeof WeakMap !== "function") return null; var cacheBabelInterop = new WeakMap(); var cacheNodeInterop = new WeakMap(); return (_getRequireWildcardCache = function (nodeInterop) { return nodeInterop ? cacheNodeInterop : cacheBabelInterop; })(nodeInterop); }

function _interopRequireWildcard(obj, nodeInterop) { if (!nodeInterop && obj && obj.__esModule) { return obj; } if (obj === null || typeof obj !== "object" && typeof obj !== "function") { return { default: obj }; } var cache = _getRequireWildcardCache(nodeInterop); if (cache && cache.has(obj)) { return cache.get(obj); } var newObj = {}; var hasPropertyDescriptor = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var key in obj) { if (key !== "default" && Object.prototype.hasOwnProperty.call(obj, key)) { var desc = hasPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : null; if (desc && (desc.get || desc.set)) { Object.defineProperty(newObj, key, desc); } else { newObj[key] = obj[key]; } } } newObj.default = obj; if (cache) { cache.set(obj, newObj); } return newObj; }

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

_enzyme.default.configure({
  adapter: new _enzymeAdapterReact.default()
});

test("styled (static)", () => {
  const style = {
    color: "red"
  };
  const Widget = (0, _index.styled)("div", style);

  _enzyme.default.mount( /*#__PURE__*/React.createElement(_index.Provider, {
    value: {
      renderStyle: x => {
        expect(x).toEqual(style);
        return "";
      },
      renderKeyframes: () => "",
      renderFontFace: () => ""
    }
  }, /*#__PURE__*/React.createElement(Widget, null)));

  const wrapper = _enzyme.default.mount( /*#__PURE__*/React.createElement(_index.Provider, {
    value: {
      renderStyle: () => "bar",
      renderKeyframes: () => "",
      renderFontFace: () => ""
    }
  }, /*#__PURE__*/React.createElement(Widget, {
    className: "foo"
  })));

  const divs = wrapper.find("div");
  expect(divs.length).toBe(1);
  expect(divs.hasClass("foo bar")).toBe(true);
});
test("styled (dynamic)", () => {
  const Widget = (0, _index.styled)("div", props => ({
    color: props.$foo ? "red" : "blue"
  }));

  _enzyme.default.mount( /*#__PURE__*/React.createElement(_index.Provider, {
    value: {
      renderStyle: x => {
        expect(x).toEqual({
          color: "red"
        });
        return "";
      },
      renderKeyframes: () => "",
      renderFontFace: () => ""
    }
  }, /*#__PURE__*/React.createElement(Widget, {
    $foo: true
  })));
});
test("withStyle (static)", () => {
  const Widget = (0, _index.styled)("div", {
    borderWidth: 0,
    color: "red",
    ":hover": {
      fontSize: "12px"
    }
  });
  const SuperWidget = (0, _index.withStyle)(Widget, {
    color: "blue",
    ":hover": {
      borderWidth: "10px"
    }
  });

  _enzyme.default.mount( /*#__PURE__*/React.createElement(_index.Provider, {
    value: {
      renderStyle: x => {
        expect(x).toEqual({
          borderWidth: 0,
          color: "blue",
          ":hover": {
            fontSize: "12px",
            borderWidth: "10px"
          }
        });
        return "";
      },
      renderKeyframes: () => "",
      renderFontFace: () => ""
    }
  }, /*#__PURE__*/React.createElement(SuperWidget, null)));
});
test("withStyle (dynamic)", () => {
  const Widget = (0, _index.styled)("div", {
    lineHeight: 1,
    color: "red",
    ":hover": {
      fontSize: "12px"
    }
  });
  const SuperWidget = (0, _index.withStyle)(Widget, props => ({
    background: props.$round ? "yellow" : "green",
    ":hover": {
      borderWidth: 0
    }
  }));

  _enzyme.default.mount( /*#__PURE__*/React.createElement(_index.Provider, {
    value: {
      renderStyle: x => {
        expect(x).toEqual({
          color: "red",
          background: "yellow",
          lineHeight: 1,
          ":hover": {
            borderWidth: 0,
            fontSize: "12px"
          }
        });
        return "";
      },
      renderKeyframes: () => "",
      renderFontFace: () => ""
    }
  }, /*#__PURE__*/React.createElement(SuperWidget, {
    $round: true
  })));
});
test("$style prop (static)", () => {
  const Widget = (0, _index.styled)("div", {
    lineHeight: 1,
    color: "red",
    ":hover": {
      fontSize: "12px"
    }
  });

  _enzyme.default.mount( /*#__PURE__*/React.createElement(_index.Provider, {
    value: {
      renderStyle: x => {
        expect(x).toEqual({
          color: "blue",
          lineHeight: 1,
          ":hover": {
            fontSize: "12px"
          }
        });
        return "";
      },
      renderKeyframes: () => "",
      renderFontFace: () => ""
    }
  }, /*#__PURE__*/React.createElement(Widget, {
    $style: {
      color: "blue"
    }
  })));
});
test("$style prop (dynamic)", () => {
  const Widget = (0, _index.styled)("div", {
    lineHeight: 1,
    color: "red",
    ":hover": {
      fontSize: "12px"
    }
  });

  _enzyme.default.mount( /*#__PURE__*/React.createElement(_index.Provider, {
    value: {
      renderStyle: x => {
        expect(x).toEqual({
          color: "blue",
          background: "yellow",
          lineHeight: 1,
          ":hover": {
            fontSize: "12px",
            borderWidth: 0
          }
        });
        return "";
      },
      renderKeyframes: () => "",
      renderFontFace: () => ""
    }
  }, /*#__PURE__*/React.createElement(Widget, {
    $style: props => ({
      color: "blue",
      background: props.$round ? "yellow" : "green",
      ":hover": {
        borderWidth: 0
      }
    }),
    $round: true
  })));
});
test("$style overrides nested withStyle", () => {
  const Widget = (0, _index.styled)("div", {
    color: "red",
    fontSize: "12px"
  });
  const WidgetColor = (0, _index.withStyle)(Widget, {
    color: "blue"
  });
  const WidgetFontSize = (0, _index.withStyle)(WidgetColor, {
    fontSize: "14px"
  });

  _enzyme.default.mount( /*#__PURE__*/React.createElement(_index.Provider, {
    value: {
      renderStyle: x => {
        expect(x).toEqual({
          color: "yellow",
          fontSize: "14px",
          padding: "10px"
        });
        return "";
      },
      renderKeyframes: () => "",
      renderFontFace: () => ""
    }
  }, /*#__PURE__*/React.createElement(WidgetFontSize, {
    $style: {
      color: "yellow",
      padding: "10px"
    }
  })));
});
test("withTransform", () => {
  const Widget = (0, _index.styled)("div", {
    color: "red",
    background: "green"
  });
  const SuperWidget = (0, _index.withTransform)(Widget, (style, props) => ({ ...style,
    background: props.$round ? "yellow" : "green"
  }));

  _enzyme.default.mount( /*#__PURE__*/React.createElement(_index.Provider, {
    value: {
      renderStyle: x => {
        expect(x).toEqual({
          color: "red",
          background: "yellow"
        });
        return "";
      },
      renderFontFace: () => {
        return "";
      },
      renderKeyframes: () => {
        return "";
      }
    }
  }, /*#__PURE__*/React.createElement(SuperWidget, {
    $round: true
  })));
});
test("$as works", () => {
  const Widget = (0, _index.styled)("div", {});

  const MockComponent = props => {
    expect(props.className).toBe("foo");
    return /*#__PURE__*/React.createElement("div", null);
  };

  _enzyme.default.mount( /*#__PURE__*/React.createElement(_index.Provider, {
    value: {
      renderStyle: () => "foo",
      renderKeyframes: () => "",
      renderFontFace: () => ""
    }
  }, /*#__PURE__*/React.createElement(Widget, {
    $as: MockComponent
  })));

  const wrapper = _enzyme.default.mount( /*#__PURE__*/React.createElement(_index.Provider, {
    value: {
      renderStyle: () => "",
      renderKeyframes: () => "",
      renderFontFace: () => ""
    }
  }, /*#__PURE__*/React.createElement(Widget, {
    $as: "span"
  })));

  expect(wrapper.find("span").length).toBe(1);
});
test("$-prefixed props not passed", () => {
  class InnerComponent extends React.Component {
    render() {
      expect(this.props).toEqual({
        className: "styleclass",
        "data-bar": "bar"
      });
      return /*#__PURE__*/React.createElement("button", null, "InnerComponent");
    }

  }

  const Widget = (0, _index.styled)(InnerComponent, {
    color: "red"
  });

  _enzyme.default.mount( /*#__PURE__*/React.createElement(_index.Provider, {
    value: {
      renderStyle: () => "styleclass",
      renderKeyframes: () => "",
      renderFontFace: () => ""
    }
  }, /*#__PURE__*/React.createElement(Widget, {
    $foo: "foo",
    $baz: "baz",
    "data-bar": "bar"
  })));
});
test("callback ref forwarding", () => {
  const Widget = (0, _index.styled)("button", {
    color: "red"
  });

  class TestComponent extends React.Component {
    componentDidMount() {
      expect(this.widgetInner instanceof HTMLButtonElement).toBe(true);
    }

    render() {
      return /*#__PURE__*/React.createElement(_index.Provider, {
        value: {
          renderStyle: () => "",
          renderKeyframes: () => "",
          renderFontFace: () => ""
        }
      }, /*#__PURE__*/React.createElement(Widget, {
        ref: c => {
          this.widgetInner = c;
        }
      }));
    }

  }

  _enzyme.default.mount( /*#__PURE__*/React.createElement(TestComponent, null));
});
test("React.createRef() ref forwarding", () => {
  const Widget = (0, _index.styled)("button", {
    color: "red"
  });

  class TestComponent extends React.Component {
    widgetInner = /*#__PURE__*/React.createRef();

    componentDidMount() {
      expect(this.widgetInner.current instanceof HTMLButtonElement).toBe(true);
    }

    render() {
      return /*#__PURE__*/React.createElement(_index.Provider, {
        value: {
          renderStyle: () => "",
          renderKeyframes: () => "",
          renderFontFace: () => ""
        }
      }, /*#__PURE__*/React.createElement(Widget, {
        ref: this.widgetInner
      }));
    }

  }

  _enzyme.default.mount( /*#__PURE__*/React.createElement(TestComponent, null));
});
test("React.useRef() ref forwarding", () => {
  const Widget = (0, _index.styled)("button", {
    color: "red"
  });

  const TestComponent = () => {
    const widgetInner = React.useRef(null);
    React.useEffect(() => {
      expect(widgetInner.current instanceof HTMLButtonElement).toBe(true);
    }, []);
    return /*#__PURE__*/React.createElement(_index.Provider, {
      value: {
        renderStyle: () => "",
        renderKeyframes: () => "",
        renderFontFace: () => ""
      }
    }, /*#__PURE__*/React.createElement(Widget, {
      ref: widgetInner
    }));
  };

  _enzyme.default.mount( /*#__PURE__*/React.createElement(TestComponent, null));
});
test("legacy string ref forwarding", () => {
  const Widget = (0, _index.styled)("button", {
    color: "red"
  });

  class TestComponent extends React.Component {
    componentDidMount() {
      expect(this.refs.myButton instanceof HTMLButtonElement).toBe(true);
    }

    render() {
      return /*#__PURE__*/React.createElement(_index.Provider, {
        value: {
          renderStyle: () => "",
          renderKeyframes: () => "",
          renderFontFace: () => ""
        }
      }, /*#__PURE__*/React.createElement(Widget, {
        ref: "myButton"
      }));
    }

  }

  _enzyme.default.mount( /*#__PURE__*/React.createElement(TestComponent, null));
});
test("withWrapper", () => {
  const Widget = (0, _index.styled)("button", {
    color: "red"
  });
  const WrappedWidget = (0, _index.withWrapper)(Widget, StyledElement => props => {
    expect(props).toEqual({
      foo: "bar"
    });
    return /*#__PURE__*/React.createElement("section", null, /*#__PURE__*/React.createElement(StyledElement, props));
  });

  const wrapper1 = _enzyme.default.mount( /*#__PURE__*/React.createElement(_index.Provider, {
    value: {
      renderStyle: style => {
        expect(style).toEqual({
          color: "red"
        });
        return "";
      },
      renderKeyframes: () => "",
      renderFontFace: () => ""
    }
  }, /*#__PURE__*/React.createElement(WrappedWidget, {
    foo: "bar"
  })));

  expect(wrapper1.find("section").length).toBe(1);
  const DeluxeWrappedWidget = (0, _index.withStyle)(WrappedWidget, {
    color: "blue"
  });

  const wrapper2 = _enzyme.default.mount( /*#__PURE__*/React.createElement(_index.Provider, {
    value: {
      renderStyle: style => {
        expect(style).toEqual({
          color: "blue"
        });
        return "";
      },
      renderKeyframes: () => "",
      renderFontFace: () => ""
    }
  }, /*#__PURE__*/React.createElement(DeluxeWrappedWidget, {
    foo: "bar"
  })));

  expect(wrapper2.find("section").length).toBe(1);
});
test("styled debug mode (client only)", () => {
  let debugCallCount = 0;
  const style = {
    color: "red"
  };
  const Widget = (0, _index.styled)("div", style);

  const wrapper = _enzyme.default.mount( /*#__PURE__*/React.createElement(_index.Provider, {
    value: {
      renderStyle: () => "bar",
      renderKeyframes: () => "",
      renderFontFace: () => ""
    },
    debug: {
      debug: ({
        stackIndex,
        stackInfo
      }) => {
        debugCallCount++;
        expect(stackIndex).toBe(2);
        expect(typeof stackInfo).toBe("object");
        expect(typeof stackInfo.stack).toBe("string");
        expect(typeof stackInfo.message).toBe("string");
        return "__arbitrary_debug_class__";
      }
    }
  }, /*#__PURE__*/React.createElement(Widget, {
    className: "foo"
  })));

  const divs = wrapper.find("div");
  expect(divs.length).toBe(1);
  expect(divs.hasClass("__arbitrary_debug_class__ foo bar")).toBe(true);
  wrapper.unmount();
  wrapper.mount();
  wrapper.unmount();
  expect(debugCallCount).toBe(1);
});
test("styled debug mode (ssr)", () => {
  const style = {
    color: "red"
  };
  let count = 0;
  const Widget = (0, _index.styled)("div", style);

  const wrapper = _enzyme.default.mount( /*#__PURE__*/React.createElement(_index.Provider, {
    value: {
      renderStyle: () => {
        count++;
        return "foo";
      },
      renderKeyframes: () => "",
      renderFontFace: () => ""
    },
    debug: {
      debug: () => {
        expect(count).toBe(2);
        return "__some_debug_class";
      }
    },
    debugAfterHydration: true
  }, /*#__PURE__*/React.createElement(Widget, null)));

  const divs = wrapper.find("div");
  expect(count).toBe(2);
  expect(divs.hasClass("__some_debug_class foo")).toBe(true);
});
test("font-face injection", () => {
  const fontFace = {
    src: "foo"
  };
  const style = {
    fontFamily: fontFace
  };
  const Widget = (0, _index.styled)("div", style);

  _enzyme.default.mount( /*#__PURE__*/React.createElement(_index.Provider, {
    value: {
      renderStyle: x => {
        expect(x).toEqual({
          fontFamily: "foo"
        });
        return "";
      },
      renderFontFace: x => {
        expect(x).toEqual(fontFace);
        return "foo";
      },
      renderKeyframes: () => ""
    }
  }, /*#__PURE__*/React.createElement(Widget, null)));
});
test("keyframes injection", () => {
  const keyframes = {
    from: {
      color: "red"
    },
    to: {
      color: "green"
    }
  };
  const style = {
    animationName: keyframes
  };
  const Widget = (0, _index.styled)("div", style);

  _enzyme.default.mount( /*#__PURE__*/React.createElement(_index.Provider, {
    value: {
      renderStyle: x => {
        expect(x).toEqual({
          animationName: "foo"
        });
        return "";
      },
      renderKeyframes: x => {
        expect(x).toEqual(keyframes);
        return "foo";
      },
      renderFontFace: () => ""
    }
  }, /*#__PURE__*/React.createElement(Widget, null)));
});
test("createStyled wrapper", () => {
  const customStyled = (0, _index.createStyled)({
    driver: _styletronStandard.driver,
    getInitialStyle: _styletronStandard.getInitialStyle,
    wrapper: _Component => props => {
      expect(props.foo).toBe("foo");
      return /*#__PURE__*/React.createElement("div", null, "hello world");
    }
  });
  const Widget = customStyled("div", {
    color: "red"
  });

  _enzyme.default.mount( /*#__PURE__*/React.createElement(_index.Provider, {
    value: {
      renderStyle: () => "",
      renderKeyframes: () => "",
      renderFontFace: () => ""
    }
  }, /*#__PURE__*/React.createElement(Widget, {
    foo: "foo"
  })));
});
test("useStyletron css", () => {
  function Link() {
    const [css] = (0, _index.useStyletron)();
    const className = css({
      color: "blue"
    });
    expect(className).toBe(".abc");
    return /*#__PURE__*/React.createElement("a", {
      className: className
    }, "Foo");
  }

  _enzyme.default.mount( /*#__PURE__*/React.createElement(_index.Provider, {
    value: {
      renderStyle: x => {
        expect(x).toEqual({
          color: "blue"
        });
        return ".abc";
      },
      renderKeyframes: () => "",
      renderFontFace: () => ""
    }
  }, /*#__PURE__*/React.createElement(Link, null)));
});
test("useStyletron debug mode", () => {
  function Widget() {
    const [css] = (0, _index.useStyletron)();
    const [on, setOn] = React.useState(false);
    const className = css({
      color: "red"
    });
    return /*#__PURE__*/React.createElement("button", {
      onClick: () => setOn(!on),
      className: className
    }, "test");
  }

  let debugCallCount = 0;

  const wrapper = _enzyme.default.mount( /*#__PURE__*/React.createElement(_index.Provider, {
    value: {
      renderStyle: () => "bar",
      renderKeyframes: () => "",
      renderFontFace: () => ""
    },
    debug: {
      debug: () => {
        debugCallCount++;
        return `__debug-${debugCallCount}`;
      }
    }
  }, /*#__PURE__*/React.createElement(Widget, null)));

  const button = wrapper.find("button");
  expect(button.hasClass("__debug-1 bar")).toBe(true);
  button.simulate("click");
  expect(button.hasClass("__debug-1 bar")).toBe(true);
  expect(debugCallCount).toBe(1);
});
test("no-op engine", () => {
  const consoleWarn = console.warn; // eslint-disable-line

  console.warn = message => {
    expect(message.split("\n")[1]).toBe("Styletron has been switched to a no-op (test) mode.");
  };

  const Widget = (0, _index.styled)("div", {
    color: "red"
  });

  _enzyme.default.mount( /*#__PURE__*/React.createElement(Widget, null));

  console.warn = consoleWarn;
});
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJFbnp5bWUiLCJjb25maWd1cmUiLCJhZGFwdGVyIiwiQWRhcHRlciIsInRlc3QiLCJzdHlsZSIsImNvbG9yIiwiV2lkZ2V0Iiwic3R5bGVkIiwibW91bnQiLCJyZW5kZXJTdHlsZSIsIngiLCJleHBlY3QiLCJ0b0VxdWFsIiwicmVuZGVyS2V5ZnJhbWVzIiwicmVuZGVyRm9udEZhY2UiLCJ3cmFwcGVyIiwiZGl2cyIsImZpbmQiLCJsZW5ndGgiLCJ0b0JlIiwiaGFzQ2xhc3MiLCJwcm9wcyIsIiRmb28iLCJib3JkZXJXaWR0aCIsImZvbnRTaXplIiwiU3VwZXJXaWRnZXQiLCJ3aXRoU3R5bGUiLCJsaW5lSGVpZ2h0IiwiYmFja2dyb3VuZCIsIiRyb3VuZCIsIldpZGdldENvbG9yIiwiV2lkZ2V0Rm9udFNpemUiLCJwYWRkaW5nIiwid2l0aFRyYW5zZm9ybSIsIk1vY2tDb21wb25lbnQiLCJjbGFzc05hbWUiLCJJbm5lckNvbXBvbmVudCIsIlJlYWN0IiwiQ29tcG9uZW50IiwicmVuZGVyIiwiVGVzdENvbXBvbmVudCIsImNvbXBvbmVudERpZE1vdW50Iiwid2lkZ2V0SW5uZXIiLCJIVE1MQnV0dG9uRWxlbWVudCIsImMiLCJjcmVhdGVSZWYiLCJjdXJyZW50IiwidXNlUmVmIiwidXNlRWZmZWN0IiwicmVmcyIsIm15QnV0dG9uIiwiV3JhcHBlZFdpZGdldCIsIndpdGhXcmFwcGVyIiwiU3R5bGVkRWxlbWVudCIsImZvbyIsIndyYXBwZXIxIiwiRGVsdXhlV3JhcHBlZFdpZGdldCIsIndyYXBwZXIyIiwiZGVidWdDYWxsQ291bnQiLCJkZWJ1ZyIsInN0YWNrSW5kZXgiLCJzdGFja0luZm8iLCJzdGFjayIsIm1lc3NhZ2UiLCJ1bm1vdW50IiwiY291bnQiLCJmb250RmFjZSIsInNyYyIsImZvbnRGYW1pbHkiLCJrZXlmcmFtZXMiLCJmcm9tIiwidG8iLCJhbmltYXRpb25OYW1lIiwiY3VzdG9tU3R5bGVkIiwiY3JlYXRlU3R5bGVkIiwiZHJpdmVyIiwiZ2V0SW5pdGlhbFN0eWxlIiwiX0NvbXBvbmVudCIsIkxpbmsiLCJjc3MiLCJ1c2VTdHlsZXRyb24iLCJvbiIsInNldE9uIiwidXNlU3RhdGUiLCJidXR0b24iLCJzaW11bGF0ZSIsImNvbnNvbGVXYXJuIiwiY29uc29sZSIsIndhcm4iLCJzcGxpdCJdLCJzb3VyY2VzIjpbInNyYy9fX3Rlc3RzX18vdGVzdHMuYnJvd3Nlci50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IEVuenltZSBmcm9tIFwiZW56eW1lXCI7XG5pbXBvcnQgQWRhcHRlciBmcm9tIFwiZW56eW1lLWFkYXB0ZXItcmVhY3QtMTZcIjtcbmltcG9ydCAqIGFzIFJlYWN0IGZyb20gXCJyZWFjdFwiO1xuXG5pbXBvcnQge1xuICBzdHlsZWQsXG4gIGNyZWF0ZVN0eWxlZCxcbiAgd2l0aFdyYXBwZXIsXG4gIHdpdGhTdHlsZSxcbiAgd2l0aFRyYW5zZm9ybSxcbiAgUHJvdmlkZXIsXG4gIHVzZVN0eWxldHJvbixcbn0gZnJvbSBcIi4uL2luZGV4XCI7XG5cbmltcG9ydCB7Z2V0SW5pdGlhbFN0eWxlLCBkcml2ZXJ9IGZyb20gXCJzdHlsZXRyb24tc3RhbmRhcmRcIjtcbmltcG9ydCB0eXBlIHtTdHlsZU9iamVjdH0gZnJvbSBcInN0eWxldHJvbi1zdGFuZGFyZFwiO1xuXG5Fbnp5bWUuY29uZmlndXJlKHthZGFwdGVyOiBuZXcgQWRhcHRlcigpfSk7XG5cbnRlc3QoXCJzdHlsZWQgKHN0YXRpYylcIiwgKCkgPT4ge1xuICBjb25zdCBzdHlsZSA9IHtjb2xvcjogXCJyZWRcIn07XG4gIGNvbnN0IFdpZGdldCA9IHN0eWxlZChcImRpdlwiLCBzdHlsZSk7XG4gIEVuenltZS5tb3VudChcbiAgICA8UHJvdmlkZXJcbiAgICAgIHZhbHVlPXt7XG4gICAgICAgIHJlbmRlclN0eWxlOiB4ID0+IHtcbiAgICAgICAgICBleHBlY3QoeCkudG9FcXVhbChzdHlsZSk7XG4gICAgICAgICAgcmV0dXJuIFwiXCI7XG4gICAgICAgIH0sXG4gICAgICAgIHJlbmRlcktleWZyYW1lczogKCkgPT4gXCJcIixcbiAgICAgICAgcmVuZGVyRm9udEZhY2U6ICgpID0+IFwiXCIsXG4gICAgICB9fVxuICAgID5cbiAgICAgIDxXaWRnZXQgLz5cbiAgICA8L1Byb3ZpZGVyPixcbiAgKTtcbiAgY29uc3Qgd3JhcHBlciA9IEVuenltZS5tb3VudChcbiAgICA8UHJvdmlkZXJcbiAgICAgIHZhbHVlPXt7XG4gICAgICAgIHJlbmRlclN0eWxlOiAoKSA9PiBcImJhclwiLFxuICAgICAgICByZW5kZXJLZXlmcmFtZXM6ICgpID0+IFwiXCIsXG4gICAgICAgIHJlbmRlckZvbnRGYWNlOiAoKSA9PiBcIlwiLFxuICAgICAgfX1cbiAgICA+XG4gICAgICA8V2lkZ2V0IGNsYXNzTmFtZT1cImZvb1wiIC8+XG4gICAgPC9Qcm92aWRlcj4sXG4gICk7XG4gIGNvbnN0IGRpdnMgPSB3cmFwcGVyLmZpbmQoXCJkaXZcIik7XG4gIGV4cGVjdChkaXZzLmxlbmd0aCkudG9CZSgxKTtcbiAgZXhwZWN0KGRpdnMuaGFzQ2xhc3MoXCJmb28gYmFyXCIpKS50b0JlKHRydWUpO1xufSk7XG5cbnRlc3QoXCJzdHlsZWQgKGR5bmFtaWMpXCIsICgpID0+IHtcbiAgY29uc3QgV2lkZ2V0ID0gc3R5bGVkKFwiZGl2XCIsIChwcm9wczogeyRmb286IGJvb2xlYW59KSA9PiAoe1xuICAgIGNvbG9yOiBwcm9wcy4kZm9vID8gXCJyZWRcIiA6IFwiYmx1ZVwiLFxuICB9KSk7XG5cbiAgRW56eW1lLm1vdW50KFxuICAgIDxQcm92aWRlclxuICAgICAgdmFsdWU9e3tcbiAgICAgICAgcmVuZGVyU3R5bGU6IHggPT4ge1xuICAgICAgICAgIGV4cGVjdCh4KS50b0VxdWFsKHtjb2xvcjogXCJyZWRcIn0pO1xuICAgICAgICAgIHJldHVybiBcIlwiO1xuICAgICAgICB9LFxuICAgICAgICByZW5kZXJLZXlmcmFtZXM6ICgpID0+IFwiXCIsXG4gICAgICAgIHJlbmRlckZvbnRGYWNlOiAoKSA9PiBcIlwiLFxuICAgICAgfX1cbiAgICA+XG4gICAgICA8V2lkZ2V0ICRmb289e3RydWV9IC8+XG4gICAgPC9Qcm92aWRlcj4sXG4gICk7XG59KTtcblxudGVzdChcIndpdGhTdHlsZSAoc3RhdGljKVwiLCAoKSA9PiB7XG4gIGNvbnN0IFdpZGdldCA9IHN0eWxlZChcImRpdlwiLCB7XG4gICAgYm9yZGVyV2lkdGg6IDAsXG4gICAgY29sb3I6IFwicmVkXCIsXG4gICAgXCI6aG92ZXJcIjoge2ZvbnRTaXplOiBcIjEycHhcIn0sXG4gIH0pO1xuICBjb25zdCBTdXBlcldpZGdldCA9IHdpdGhTdHlsZShXaWRnZXQsIHtcbiAgICBjb2xvcjogXCJibHVlXCIsXG4gICAgXCI6aG92ZXJcIjoge2JvcmRlcldpZHRoOiBcIjEwcHhcIn0sXG4gIH0pO1xuICBFbnp5bWUubW91bnQoXG4gICAgPFByb3ZpZGVyXG4gICAgICB2YWx1ZT17e1xuICAgICAgICByZW5kZXJTdHlsZTogeCA9PiB7XG4gICAgICAgICAgZXhwZWN0KHgpLnRvRXF1YWwoe1xuICAgICAgICAgICAgYm9yZGVyV2lkdGg6IDAsXG4gICAgICAgICAgICBjb2xvcjogXCJibHVlXCIsXG4gICAgICAgICAgICBcIjpob3ZlclwiOiB7Zm9udFNpemU6IFwiMTJweFwiLCBib3JkZXJXaWR0aDogXCIxMHB4XCJ9LFxuICAgICAgICAgIH0pO1xuICAgICAgICAgIHJldHVybiBcIlwiO1xuICAgICAgICB9LFxuICAgICAgICByZW5kZXJLZXlmcmFtZXM6ICgpID0+IFwiXCIsXG4gICAgICAgIHJlbmRlckZvbnRGYWNlOiAoKSA9PiBcIlwiLFxuICAgICAgfX1cbiAgICA+XG4gICAgICA8U3VwZXJXaWRnZXQgLz5cbiAgICA8L1Byb3ZpZGVyPixcbiAgKTtcbn0pO1xuXG50ZXN0KFwid2l0aFN0eWxlIChkeW5hbWljKVwiLCAoKSA9PiB7XG4gIGNvbnN0IFdpZGdldCA9IHN0eWxlZChcImRpdlwiLCB7XG4gICAgbGluZUhlaWdodDogMSxcbiAgICBjb2xvcjogXCJyZWRcIixcbiAgICBcIjpob3ZlclwiOiB7Zm9udFNpemU6IFwiMTJweFwifSxcbiAgfSk7XG4gIGNvbnN0IFN1cGVyV2lkZ2V0ID0gd2l0aFN0eWxlPHR5cGVvZiBXaWRnZXQsIHskcm91bmQ6IGJvb2xlYW59PihcbiAgICBXaWRnZXQsXG4gICAgcHJvcHMgPT4gKHtcbiAgICAgIGJhY2tncm91bmQ6IHByb3BzLiRyb3VuZCA/IFwieWVsbG93XCIgOiBcImdyZWVuXCIsXG4gICAgICBcIjpob3ZlclwiOiB7Ym9yZGVyV2lkdGg6IDB9LFxuICAgIH0pLFxuICApO1xuICBFbnp5bWUubW91bnQoXG4gICAgPFByb3ZpZGVyXG4gICAgICB2YWx1ZT17e1xuICAgICAgICByZW5kZXJTdHlsZTogeCA9PiB7XG4gICAgICAgICAgZXhwZWN0KHgpLnRvRXF1YWwoe1xuICAgICAgICAgICAgY29sb3I6IFwicmVkXCIsXG4gICAgICAgICAgICBiYWNrZ3JvdW5kOiBcInllbGxvd1wiLFxuICAgICAgICAgICAgbGluZUhlaWdodDogMSxcbiAgICAgICAgICAgIFwiOmhvdmVyXCI6IHtib3JkZXJXaWR0aDogMCwgZm9udFNpemU6IFwiMTJweFwifSxcbiAgICAgICAgICB9KTtcblxuICAgICAgICAgIHJldHVybiBcIlwiO1xuICAgICAgICB9LFxuICAgICAgICByZW5kZXJLZXlmcmFtZXM6ICgpID0+IFwiXCIsXG4gICAgICAgIHJlbmRlckZvbnRGYWNlOiAoKSA9PiBcIlwiLFxuICAgICAgfX1cbiAgICA+XG4gICAgICA8U3VwZXJXaWRnZXQgJHJvdW5kPXt0cnVlfSAvPlxuICAgIDwvUHJvdmlkZXI+LFxuICApO1xufSk7XG5cbnRlc3QoXCIkc3R5bGUgcHJvcCAoc3RhdGljKVwiLCAoKSA9PiB7XG4gIGNvbnN0IFdpZGdldCA9IHN0eWxlZChcImRpdlwiLCB7XG4gICAgbGluZUhlaWdodDogMSxcbiAgICBjb2xvcjogXCJyZWRcIixcbiAgICBcIjpob3ZlclwiOiB7Zm9udFNpemU6IFwiMTJweFwifSxcbiAgfSk7XG5cbiAgRW56eW1lLm1vdW50KFxuICAgIDxQcm92aWRlclxuICAgICAgdmFsdWU9e3tcbiAgICAgICAgcmVuZGVyU3R5bGU6IHggPT4ge1xuICAgICAgICAgIGV4cGVjdCh4KS50b0VxdWFsKHtcbiAgICAgICAgICAgIGNvbG9yOiBcImJsdWVcIixcbiAgICAgICAgICAgIGxpbmVIZWlnaHQ6IDEsXG4gICAgICAgICAgICBcIjpob3ZlclwiOiB7Zm9udFNpemU6IFwiMTJweFwifSxcbiAgICAgICAgICB9KTtcbiAgICAgICAgICByZXR1cm4gXCJcIjtcbiAgICAgICAgfSxcbiAgICAgICAgcmVuZGVyS2V5ZnJhbWVzOiAoKSA9PiBcIlwiLFxuICAgICAgICByZW5kZXJGb250RmFjZTogKCkgPT4gXCJcIixcbiAgICAgIH19XG4gICAgPlxuICAgICAgPFdpZGdldCAkc3R5bGU9e3tjb2xvcjogXCJibHVlXCJ9fSAvPlxuICAgIDwvUHJvdmlkZXI+LFxuICApO1xufSk7XG5cbnRlc3QoXCIkc3R5bGUgcHJvcCAoZHluYW1pYylcIiwgKCkgPT4ge1xuICBjb25zdCBXaWRnZXQgPSBzdHlsZWQ8XCJkaXZcIiwgeyRyb3VuZDogYm9vbGVhbn0+KFwiZGl2XCIsIHtcbiAgICBsaW5lSGVpZ2h0OiAxLFxuICAgIGNvbG9yOiBcInJlZFwiLFxuICAgIFwiOmhvdmVyXCI6IHtmb250U2l6ZTogXCIxMnB4XCJ9LFxuICB9KTtcblxuICBFbnp5bWUubW91bnQoXG4gICAgPFByb3ZpZGVyXG4gICAgICB2YWx1ZT17e1xuICAgICAgICByZW5kZXJTdHlsZTogeCA9PiB7XG4gICAgICAgICAgZXhwZWN0KHgpLnRvRXF1YWwoe1xuICAgICAgICAgICAgY29sb3I6IFwiYmx1ZVwiLFxuICAgICAgICAgICAgYmFja2dyb3VuZDogXCJ5ZWxsb3dcIixcbiAgICAgICAgICAgIGxpbmVIZWlnaHQ6IDEsXG4gICAgICAgICAgICBcIjpob3ZlclwiOiB7Zm9udFNpemU6IFwiMTJweFwiLCBib3JkZXJXaWR0aDogMH0sXG4gICAgICAgICAgfSk7XG4gICAgICAgICAgcmV0dXJuIFwiXCI7XG4gICAgICAgIH0sXG4gICAgICAgIHJlbmRlcktleWZyYW1lczogKCkgPT4gXCJcIixcbiAgICAgICAgcmVuZGVyRm9udEZhY2U6ICgpID0+IFwiXCIsXG4gICAgICB9fVxuICAgID5cbiAgICAgIDxXaWRnZXRcbiAgICAgICAgJHN0eWxlPXtwcm9wcyA9PiAoe1xuICAgICAgICAgIGNvbG9yOiBcImJsdWVcIixcbiAgICAgICAgICBiYWNrZ3JvdW5kOiBwcm9wcy4kcm91bmQgPyBcInllbGxvd1wiIDogXCJncmVlblwiLFxuICAgICAgICAgIFwiOmhvdmVyXCI6IHtib3JkZXJXaWR0aDogMH0sXG4gICAgICAgIH0pfVxuICAgICAgICAkcm91bmQ9e3RydWV9XG4gICAgICAvPlxuICAgIDwvUHJvdmlkZXI+LFxuICApO1xufSk7XG5cbnRlc3QoXCIkc3R5bGUgb3ZlcnJpZGVzIG5lc3RlZCB3aXRoU3R5bGVcIiwgKCkgPT4ge1xuICBjb25zdCBXaWRnZXQgPSBzdHlsZWQoXCJkaXZcIiwge1xuICAgIGNvbG9yOiBcInJlZFwiLFxuICAgIGZvbnRTaXplOiBcIjEycHhcIixcbiAgfSk7XG5cbiAgY29uc3QgV2lkZ2V0Q29sb3IgPSB3aXRoU3R5bGUoV2lkZ2V0LCB7Y29sb3I6IFwiYmx1ZVwifSk7XG4gIGNvbnN0IFdpZGdldEZvbnRTaXplID0gd2l0aFN0eWxlKFdpZGdldENvbG9yLCB7Zm9udFNpemU6IFwiMTRweFwifSk7XG5cbiAgRW56eW1lLm1vdW50KFxuICAgIDxQcm92aWRlclxuICAgICAgdmFsdWU9e3tcbiAgICAgICAgcmVuZGVyU3R5bGU6IHggPT4ge1xuICAgICAgICAgIGV4cGVjdCh4KS50b0VxdWFsKHtcbiAgICAgICAgICAgIGNvbG9yOiBcInllbGxvd1wiLFxuICAgICAgICAgICAgZm9udFNpemU6IFwiMTRweFwiLFxuICAgICAgICAgICAgcGFkZGluZzogXCIxMHB4XCIsXG4gICAgICAgICAgfSk7XG4gICAgICAgICAgcmV0dXJuIFwiXCI7XG4gICAgICAgIH0sXG4gICAgICAgIHJlbmRlcktleWZyYW1lczogKCkgPT4gXCJcIixcbiAgICAgICAgcmVuZGVyRm9udEZhY2U6ICgpID0+IFwiXCIsXG4gICAgICB9fVxuICAgID5cbiAgICAgIDxXaWRnZXRGb250U2l6ZVxuICAgICAgICAkc3R5bGU9e3tcbiAgICAgICAgICBjb2xvcjogXCJ5ZWxsb3dcIixcbiAgICAgICAgICBwYWRkaW5nOiBcIjEwcHhcIixcbiAgICAgICAgfX1cbiAgICAgIC8+XG4gICAgPC9Qcm92aWRlcj4sXG4gICk7XG59KTtcblxudGVzdChcIndpdGhUcmFuc2Zvcm1cIiwgKCkgPT4ge1xuICBjb25zdCBXaWRnZXQgPSBzdHlsZWQoXCJkaXZcIiwge2NvbG9yOiBcInJlZFwiLCBiYWNrZ3JvdW5kOiBcImdyZWVuXCJ9KTtcbiAgY29uc3QgU3VwZXJXaWRnZXQgPSB3aXRoVHJhbnNmb3JtKFxuICAgIFdpZGdldCxcbiAgICAoc3R5bGUsIHByb3BzOiB7JHJvdW5kOiBib29sZWFufSkgPT4gKHtcbiAgICAgIC4uLnN0eWxlLFxuICAgICAgYmFja2dyb3VuZDogcHJvcHMuJHJvdW5kID8gXCJ5ZWxsb3dcIiA6IFwiZ3JlZW5cIixcbiAgICB9KSxcbiAgKTtcbiAgRW56eW1lLm1vdW50KFxuICAgIDxQcm92aWRlclxuICAgICAgdmFsdWU9e3tcbiAgICAgICAgcmVuZGVyU3R5bGU6IHggPT4ge1xuICAgICAgICAgIGV4cGVjdCh4KS50b0VxdWFsKHtjb2xvcjogXCJyZWRcIiwgYmFja2dyb3VuZDogXCJ5ZWxsb3dcIn0pO1xuICAgICAgICAgIHJldHVybiBcIlwiO1xuICAgICAgICB9LFxuICAgICAgICByZW5kZXJGb250RmFjZTogKCkgPT4ge1xuICAgICAgICAgIHJldHVybiBcIlwiO1xuICAgICAgICB9LFxuICAgICAgICByZW5kZXJLZXlmcmFtZXM6ICgpID0+IHtcbiAgICAgICAgICByZXR1cm4gXCJcIjtcbiAgICAgICAgfSxcbiAgICAgIH19XG4gICAgPlxuICAgICAgPFN1cGVyV2lkZ2V0ICRyb3VuZD17dHJ1ZX0gLz5cbiAgICA8L1Byb3ZpZGVyPixcbiAgKTtcbn0pO1xuXG50ZXN0KFwiJGFzIHdvcmtzXCIsICgpID0+IHtcbiAgY29uc3QgV2lkZ2V0ID0gc3R5bGVkKFwiZGl2XCIsIHt9KTtcbiAgY29uc3QgTW9ja0NvbXBvbmVudCA9IHByb3BzID0+IHtcbiAgICBleHBlY3QocHJvcHMuY2xhc3NOYW1lKS50b0JlKFwiZm9vXCIpO1xuICAgIHJldHVybiA8ZGl2IC8+O1xuICB9O1xuICBFbnp5bWUubW91bnQoXG4gICAgPFByb3ZpZGVyXG4gICAgICB2YWx1ZT17e1xuICAgICAgICByZW5kZXJTdHlsZTogKCkgPT4gXCJmb29cIixcbiAgICAgICAgcmVuZGVyS2V5ZnJhbWVzOiAoKSA9PiBcIlwiLFxuICAgICAgICByZW5kZXJGb250RmFjZTogKCkgPT4gXCJcIixcbiAgICAgIH19XG4gICAgPlxuICAgICAgPFdpZGdldCAkYXM9e01vY2tDb21wb25lbnR9IC8+XG4gICAgPC9Qcm92aWRlcj4sXG4gICk7XG4gIGNvbnN0IHdyYXBwZXIgPSBFbnp5bWUubW91bnQoXG4gICAgPFByb3ZpZGVyXG4gICAgICB2YWx1ZT17e1xuICAgICAgICByZW5kZXJTdHlsZTogKCkgPT4gXCJcIixcbiAgICAgICAgcmVuZGVyS2V5ZnJhbWVzOiAoKSA9PiBcIlwiLFxuICAgICAgICByZW5kZXJGb250RmFjZTogKCkgPT4gXCJcIixcbiAgICAgIH19XG4gICAgPlxuICAgICAgPFdpZGdldCAkYXM9XCJzcGFuXCIgLz5cbiAgICA8L1Byb3ZpZGVyPixcbiAgKTtcbiAgZXhwZWN0KHdyYXBwZXIuZmluZChcInNwYW5cIikubGVuZ3RoKS50b0JlKDEpO1xufSk7XG5cbnRlc3QoXCIkLXByZWZpeGVkIHByb3BzIG5vdCBwYXNzZWRcIiwgKCkgPT4ge1xuICBjbGFzcyBJbm5lckNvbXBvbmVudCBleHRlbmRzIFJlYWN0LkNvbXBvbmVudDx7XG4gICAgY2xhc3NOYW1lPzogc3RyaW5nO1xuICB9PiB7XG4gICAgcmVuZGVyKCkge1xuICAgICAgZXhwZWN0KHRoaXMucHJvcHMpLnRvRXF1YWwoe1xuICAgICAgICBjbGFzc05hbWU6IFwic3R5bGVjbGFzc1wiLFxuICAgICAgICBcImRhdGEtYmFyXCI6IFwiYmFyXCIsXG4gICAgICB9KTtcbiAgICAgIHJldHVybiA8YnV0dG9uPklubmVyQ29tcG9uZW50PC9idXR0b24+O1xuICAgIH1cbiAgfVxuXG4gIGNvbnN0IFdpZGdldCA9IHN0eWxlZDx0eXBlb2YgSW5uZXJDb21wb25lbnQsIHskZm9vOiBhbnk7ICRiYXo6IGFueX0+KFxuICAgIElubmVyQ29tcG9uZW50LFxuICAgIHtjb2xvcjogXCJyZWRcIn0sXG4gICk7XG5cbiAgRW56eW1lLm1vdW50KFxuICAgIDxQcm92aWRlclxuICAgICAgdmFsdWU9e3tcbiAgICAgICAgcmVuZGVyU3R5bGU6ICgpID0+IFwic3R5bGVjbGFzc1wiLFxuICAgICAgICByZW5kZXJLZXlmcmFtZXM6ICgpID0+IFwiXCIsXG4gICAgICAgIHJlbmRlckZvbnRGYWNlOiAoKSA9PiBcIlwiLFxuICAgICAgfX1cbiAgICA+XG4gICAgICA8V2lkZ2V0ICRmb289XCJmb29cIiAkYmF6PVwiYmF6XCIgZGF0YS1iYXI9XCJiYXJcIiAvPlxuICAgIDwvUHJvdmlkZXI+LFxuICApO1xufSk7XG5cbnRlc3QoXCJjYWxsYmFjayByZWYgZm9yd2FyZGluZ1wiLCAoKSA9PiB7XG4gIGNvbnN0IFdpZGdldCA9IHN0eWxlZChcImJ1dHRvblwiLCB7Y29sb3I6IFwicmVkXCJ9KTtcbiAgY2xhc3MgVGVzdENvbXBvbmVudCBleHRlbmRzIFJlYWN0LkNvbXBvbmVudDx7fT4ge1xuICAgIHdpZGdldElubmVyOiBIVE1MQnV0dG9uRWxlbWVudCB8IHVuZGVmaW5lZCB8IG51bGw7XG4gICAgY29tcG9uZW50RGlkTW91bnQoKSB7XG4gICAgICBleHBlY3QodGhpcy53aWRnZXRJbm5lciBpbnN0YW5jZW9mIEhUTUxCdXR0b25FbGVtZW50KS50b0JlKHRydWUpO1xuICAgIH1cblxuICAgIHJlbmRlcigpIHtcbiAgICAgIHJldHVybiAoXG4gICAgICAgIDxQcm92aWRlclxuICAgICAgICAgIHZhbHVlPXt7XG4gICAgICAgICAgICByZW5kZXJTdHlsZTogKCkgPT4gXCJcIixcbiAgICAgICAgICAgIHJlbmRlcktleWZyYW1lczogKCkgPT4gXCJcIixcbiAgICAgICAgICAgIHJlbmRlckZvbnRGYWNlOiAoKSA9PiBcIlwiLFxuICAgICAgICAgIH19XG4gICAgICAgID5cbiAgICAgICAgICA8V2lkZ2V0XG4gICAgICAgICAgICByZWY9e2MgPT4ge1xuICAgICAgICAgICAgICB0aGlzLndpZGdldElubmVyID0gYztcbiAgICAgICAgICAgIH19XG4gICAgICAgICAgLz5cbiAgICAgICAgPC9Qcm92aWRlcj5cbiAgICAgICk7XG4gICAgfVxuICB9XG4gIEVuenltZS5tb3VudCg8VGVzdENvbXBvbmVudCAvPik7XG59KTtcblxudGVzdChcIlJlYWN0LmNyZWF0ZVJlZigpIHJlZiBmb3J3YXJkaW5nXCIsICgpID0+IHtcbiAgY29uc3QgV2lkZ2V0ID0gc3R5bGVkKFwiYnV0dG9uXCIsIHtjb2xvcjogXCJyZWRcIn0pO1xuICBjbGFzcyBUZXN0Q29tcG9uZW50IGV4dGVuZHMgUmVhY3QuQ29tcG9uZW50PHt9PiB7XG4gICAgd2lkZ2V0SW5uZXIgPSBSZWFjdC5jcmVhdGVSZWY8YW55PigpO1xuXG4gICAgY29tcG9uZW50RGlkTW91bnQoKSB7XG4gICAgICBleHBlY3QodGhpcy53aWRnZXRJbm5lci5jdXJyZW50IGluc3RhbmNlb2YgSFRNTEJ1dHRvbkVsZW1lbnQpLnRvQmUodHJ1ZSk7XG4gICAgfVxuXG4gICAgcmVuZGVyKCkge1xuICAgICAgcmV0dXJuIChcbiAgICAgICAgPFByb3ZpZGVyXG4gICAgICAgICAgdmFsdWU9e3tcbiAgICAgICAgICAgIHJlbmRlclN0eWxlOiAoKSA9PiBcIlwiLFxuICAgICAgICAgICAgcmVuZGVyS2V5ZnJhbWVzOiAoKSA9PiBcIlwiLFxuICAgICAgICAgICAgcmVuZGVyRm9udEZhY2U6ICgpID0+IFwiXCIsXG4gICAgICAgICAgfX1cbiAgICAgICAgPlxuICAgICAgICAgIDxXaWRnZXQgcmVmPXt0aGlzLndpZGdldElubmVyfSAvPlxuICAgICAgICA8L1Byb3ZpZGVyPlxuICAgICAgKTtcbiAgICB9XG4gIH1cbiAgRW56eW1lLm1vdW50KDxUZXN0Q29tcG9uZW50IC8+KTtcbn0pO1xuXG50ZXN0KFwiUmVhY3QudXNlUmVmKCkgcmVmIGZvcndhcmRpbmdcIiwgKCkgPT4ge1xuICBjb25zdCBXaWRnZXQgPSBzdHlsZWQoXCJidXR0b25cIiwge2NvbG9yOiBcInJlZFwifSk7XG4gIGNvbnN0IFRlc3RDb21wb25lbnQgPSAoKSA9PiB7XG4gICAgY29uc3Qgd2lkZ2V0SW5uZXIgPSBSZWFjdC51c2VSZWY8SFRNTEJ1dHRvbkVsZW1lbnQ+KG51bGwpO1xuICAgIFJlYWN0LnVzZUVmZmVjdCgoKSA9PiB7XG4gICAgICBleHBlY3Qod2lkZ2V0SW5uZXIuY3VycmVudCBpbnN0YW5jZW9mIEhUTUxCdXR0b25FbGVtZW50KS50b0JlKHRydWUpO1xuICAgIH0sIFtdKTtcbiAgICByZXR1cm4gKFxuICAgICAgPFByb3ZpZGVyXG4gICAgICAgIHZhbHVlPXt7XG4gICAgICAgICAgcmVuZGVyU3R5bGU6ICgpID0+IFwiXCIsXG4gICAgICAgICAgcmVuZGVyS2V5ZnJhbWVzOiAoKSA9PiBcIlwiLFxuICAgICAgICAgIHJlbmRlckZvbnRGYWNlOiAoKSA9PiBcIlwiLFxuICAgICAgICB9fVxuICAgICAgPlxuICAgICAgICA8V2lkZ2V0IHJlZj17d2lkZ2V0SW5uZXJ9IC8+XG4gICAgICA8L1Byb3ZpZGVyPlxuICAgICk7XG4gIH07XG5cbiAgRW56eW1lLm1vdW50KDxUZXN0Q29tcG9uZW50IC8+KTtcbn0pO1xuXG50ZXN0KFwibGVnYWN5IHN0cmluZyByZWYgZm9yd2FyZGluZ1wiLCAoKSA9PiB7XG4gIGNvbnN0IFdpZGdldCA9IHN0eWxlZChcImJ1dHRvblwiLCB7Y29sb3I6IFwicmVkXCJ9KTtcbiAgY2xhc3MgVGVzdENvbXBvbmVudCBleHRlbmRzIFJlYWN0LkNvbXBvbmVudDx7fT4ge1xuICAgIGNvbXBvbmVudERpZE1vdW50KCkge1xuICAgICAgZXhwZWN0KHRoaXMucmVmcy5teUJ1dHRvbiBpbnN0YW5jZW9mIEhUTUxCdXR0b25FbGVtZW50KS50b0JlKHRydWUpO1xuICAgIH1cbiAgICByZW5kZXIoKSB7XG4gICAgICByZXR1cm4gKFxuICAgICAgICA8UHJvdmlkZXJcbiAgICAgICAgICB2YWx1ZT17e1xuICAgICAgICAgICAgcmVuZGVyU3R5bGU6ICgpID0+IFwiXCIsXG4gICAgICAgICAgICByZW5kZXJLZXlmcmFtZXM6ICgpID0+IFwiXCIsXG4gICAgICAgICAgICByZW5kZXJGb250RmFjZTogKCkgPT4gXCJcIixcbiAgICAgICAgICB9fVxuICAgICAgICA+XG4gICAgICAgICAgPFdpZGdldCByZWY9XCJteUJ1dHRvblwiIC8+XG4gICAgICAgIDwvUHJvdmlkZXI+XG4gICAgICApO1xuICAgIH1cbiAgfVxuICBFbnp5bWUubW91bnQoPFRlc3RDb21wb25lbnQgLz4pO1xufSk7XG5cbnRlc3QoXCJ3aXRoV3JhcHBlclwiLCAoKSA9PiB7XG4gIGNvbnN0IFdpZGdldCA9IHN0eWxlZDxcImJ1dHRvblwiLCB7Zm9vPzogc3RyaW5nfT4oXCJidXR0b25cIiwge1xuICAgIGNvbG9yOiBcInJlZFwiLFxuICB9KTtcbiAgY29uc3QgV3JhcHBlZFdpZGdldCA9IHdpdGhXcmFwcGVyKFdpZGdldCwgU3R5bGVkRWxlbWVudCA9PiBwcm9wcyA9PiB7XG4gICAgZXhwZWN0KHByb3BzKS50b0VxdWFsKHtmb286IFwiYmFyXCJ9KTtcbiAgICByZXR1cm4gKFxuICAgICAgPHNlY3Rpb24+XG4gICAgICAgIDxTdHlsZWRFbGVtZW50IHsuLi5wcm9wc30gLz5cbiAgICAgIDwvc2VjdGlvbj5cbiAgICApO1xuICB9KTtcbiAgY29uc3Qgd3JhcHBlcjEgPSBFbnp5bWUubW91bnQoXG4gICAgPFByb3ZpZGVyXG4gICAgICB2YWx1ZT17e1xuICAgICAgICByZW5kZXJTdHlsZTogc3R5bGUgPT4ge1xuICAgICAgICAgIGV4cGVjdChzdHlsZSkudG9FcXVhbCh7Y29sb3I6IFwicmVkXCJ9KTtcbiAgICAgICAgICByZXR1cm4gXCJcIjtcbiAgICAgICAgfSxcbiAgICAgICAgcmVuZGVyS2V5ZnJhbWVzOiAoKSA9PiBcIlwiLFxuICAgICAgICByZW5kZXJGb250RmFjZTogKCkgPT4gXCJcIixcbiAgICAgIH19XG4gICAgPlxuICAgICAgPFdyYXBwZWRXaWRnZXQgZm9vPVwiYmFyXCIgLz5cbiAgICA8L1Byb3ZpZGVyPixcbiAgKTtcbiAgZXhwZWN0KHdyYXBwZXIxLmZpbmQoXCJzZWN0aW9uXCIpLmxlbmd0aCkudG9CZSgxKTtcblxuICBjb25zdCBEZWx1eGVXcmFwcGVkV2lkZ2V0ID0gd2l0aFN0eWxlKFdyYXBwZWRXaWRnZXQsIHtjb2xvcjogXCJibHVlXCJ9KTtcbiAgY29uc3Qgd3JhcHBlcjIgPSBFbnp5bWUubW91bnQoXG4gICAgPFByb3ZpZGVyXG4gICAgICB2YWx1ZT17e1xuICAgICAgICByZW5kZXJTdHlsZTogc3R5bGUgPT4ge1xuICAgICAgICAgIGV4cGVjdChzdHlsZSkudG9FcXVhbCh7Y29sb3I6IFwiYmx1ZVwifSk7XG4gICAgICAgICAgcmV0dXJuIFwiXCI7XG4gICAgICAgIH0sXG4gICAgICAgIHJlbmRlcktleWZyYW1lczogKCkgPT4gXCJcIixcbiAgICAgICAgcmVuZGVyRm9udEZhY2U6ICgpID0+IFwiXCIsXG4gICAgICB9fVxuICAgID5cbiAgICAgIDxEZWx1eGVXcmFwcGVkV2lkZ2V0IGZvbz1cImJhclwiIC8+XG4gICAgPC9Qcm92aWRlcj4sXG4gICk7XG4gIGV4cGVjdCh3cmFwcGVyMi5maW5kKFwic2VjdGlvblwiKS5sZW5ndGgpLnRvQmUoMSk7XG59KTtcblxudGVzdChcInN0eWxlZCBkZWJ1ZyBtb2RlIChjbGllbnQgb25seSlcIiwgKCkgPT4ge1xuICBsZXQgZGVidWdDYWxsQ291bnQgPSAwO1xuXG4gIGNvbnN0IHN0eWxlID0ge2NvbG9yOiBcInJlZFwifTtcbiAgY29uc3QgV2lkZ2V0ID0gc3R5bGVkKFwiZGl2XCIsIHN0eWxlKTtcblxuICBjb25zdCB3cmFwcGVyID0gRW56eW1lLm1vdW50KFxuICAgIDxQcm92aWRlclxuICAgICAgdmFsdWU9e3tcbiAgICAgICAgcmVuZGVyU3R5bGU6ICgpID0+IFwiYmFyXCIsXG4gICAgICAgIHJlbmRlcktleWZyYW1lczogKCkgPT4gXCJcIixcbiAgICAgICAgcmVuZGVyRm9udEZhY2U6ICgpID0+IFwiXCIsXG4gICAgICB9fVxuICAgICAgZGVidWc9e3tcbiAgICAgICAgZGVidWc6ICh7c3RhY2tJbmRleCwgc3RhY2tJbmZvfSkgPT4ge1xuICAgICAgICAgIGRlYnVnQ2FsbENvdW50Kys7XG4gICAgICAgICAgZXhwZWN0KHN0YWNrSW5kZXgpLnRvQmUoMik7XG4gICAgICAgICAgZXhwZWN0KHR5cGVvZiBzdGFja0luZm8pLnRvQmUoXCJvYmplY3RcIik7XG4gICAgICAgICAgZXhwZWN0KHR5cGVvZiBzdGFja0luZm8uc3RhY2spLnRvQmUoXCJzdHJpbmdcIik7XG4gICAgICAgICAgZXhwZWN0KHR5cGVvZiBzdGFja0luZm8ubWVzc2FnZSkudG9CZShcInN0cmluZ1wiKTtcbiAgICAgICAgICByZXR1cm4gXCJfX2FyYml0cmFyeV9kZWJ1Z19jbGFzc19fXCI7XG4gICAgICAgIH0sXG4gICAgICB9fVxuICAgID5cbiAgICAgIDxXaWRnZXQgY2xhc3NOYW1lPVwiZm9vXCIgLz5cbiAgICA8L1Byb3ZpZGVyPixcbiAgKTtcblxuICBjb25zdCBkaXZzID0gd3JhcHBlci5maW5kKFwiZGl2XCIpO1xuICBleHBlY3QoZGl2cy5sZW5ndGgpLnRvQmUoMSk7XG4gIGV4cGVjdChkaXZzLmhhc0NsYXNzKFwiX19hcmJpdHJhcnlfZGVidWdfY2xhc3NfXyBmb28gYmFyXCIpKS50b0JlKHRydWUpO1xuICB3cmFwcGVyLnVubW91bnQoKTtcbiAgd3JhcHBlci5tb3VudCgpO1xuICB3cmFwcGVyLnVubW91bnQoKTtcbiAgZXhwZWN0KGRlYnVnQ2FsbENvdW50KS50b0JlKDEpO1xufSk7XG5cbnRlc3QoXCJzdHlsZWQgZGVidWcgbW9kZSAoc3NyKVwiLCAoKSA9PiB7XG4gIGNvbnN0IHN0eWxlID0ge2NvbG9yOiBcInJlZFwifTtcbiAgbGV0IGNvdW50ID0gMDtcbiAgY29uc3QgV2lkZ2V0ID0gc3R5bGVkKFwiZGl2XCIsIHN0eWxlKTtcbiAgY29uc3Qgd3JhcHBlciA9IEVuenltZS5tb3VudChcbiAgICA8UHJvdmlkZXJcbiAgICAgIHZhbHVlPXt7XG4gICAgICAgIHJlbmRlclN0eWxlOiAoKSA9PiB7XG4gICAgICAgICAgY291bnQrKztcbiAgICAgICAgICByZXR1cm4gXCJmb29cIjtcbiAgICAgICAgfSxcbiAgICAgICAgcmVuZGVyS2V5ZnJhbWVzOiAoKSA9PiBcIlwiLFxuICAgICAgICByZW5kZXJGb250RmFjZTogKCkgPT4gXCJcIixcbiAgICAgIH19XG4gICAgICBkZWJ1Zz17e1xuICAgICAgICBkZWJ1ZzogKCkgPT4ge1xuICAgICAgICAgIGV4cGVjdChjb3VudCkudG9CZSgyKTtcbiAgICAgICAgICByZXR1cm4gXCJfX3NvbWVfZGVidWdfY2xhc3NcIjtcbiAgICAgICAgfSxcbiAgICAgIH19XG4gICAgICBkZWJ1Z0FmdGVySHlkcmF0aW9uXG4gICAgPlxuICAgICAgPFdpZGdldCAvPlxuICAgIDwvUHJvdmlkZXI+LFxuICApO1xuICBjb25zdCBkaXZzID0gd3JhcHBlci5maW5kKFwiZGl2XCIpO1xuICBleHBlY3QoY291bnQpLnRvQmUoMik7XG4gIGV4cGVjdChkaXZzLmhhc0NsYXNzKFwiX19zb21lX2RlYnVnX2NsYXNzIGZvb1wiKSkudG9CZSh0cnVlKTtcbn0pO1xuXG50ZXN0KFwiZm9udC1mYWNlIGluamVjdGlvblwiLCAoKSA9PiB7XG4gIGNvbnN0IGZvbnRGYWNlID0ge1xuICAgIHNyYzogXCJmb29cIixcbiAgfTtcbiAgY29uc3Qgc3R5bGUgPSB7Zm9udEZhbWlseTogZm9udEZhY2V9IGFzIFN0eWxlT2JqZWN0O1xuICBjb25zdCBXaWRnZXQgPSBzdHlsZWQoXCJkaXZcIiwgc3R5bGUpO1xuICBFbnp5bWUubW91bnQoXG4gICAgPFByb3ZpZGVyXG4gICAgICB2YWx1ZT17e1xuICAgICAgICByZW5kZXJTdHlsZTogeCA9PiB7XG4gICAgICAgICAgZXhwZWN0KHgpLnRvRXF1YWwoe1xuICAgICAgICAgICAgZm9udEZhbWlseTogXCJmb29cIixcbiAgICAgICAgICB9KTtcbiAgICAgICAgICByZXR1cm4gXCJcIjtcbiAgICAgICAgfSxcbiAgICAgICAgcmVuZGVyRm9udEZhY2U6IHggPT4ge1xuICAgICAgICAgIGV4cGVjdCh4KS50b0VxdWFsKGZvbnRGYWNlKTtcbiAgICAgICAgICByZXR1cm4gXCJmb29cIjtcbiAgICAgICAgfSxcbiAgICAgICAgcmVuZGVyS2V5ZnJhbWVzOiAoKSA9PiBcIlwiLFxuICAgICAgfX1cbiAgICA+XG4gICAgICA8V2lkZ2V0IC8+XG4gICAgPC9Qcm92aWRlcj4sXG4gICk7XG59KTtcblxudGVzdChcImtleWZyYW1lcyBpbmplY3Rpb25cIiwgKCkgPT4ge1xuICBjb25zdCBrZXlmcmFtZXMgPSB7XG4gICAgZnJvbToge2NvbG9yOiBcInJlZFwifSxcbiAgICB0bzoge2NvbG9yOiBcImdyZWVuXCJ9LFxuICB9O1xuICBjb25zdCBzdHlsZSA9IHthbmltYXRpb25OYW1lOiBrZXlmcmFtZXN9O1xuICBjb25zdCBXaWRnZXQgPSBzdHlsZWQoXCJkaXZcIiwgc3R5bGUpO1xuICBFbnp5bWUubW91bnQoXG4gICAgPFByb3ZpZGVyXG4gICAgICB2YWx1ZT17e1xuICAgICAgICByZW5kZXJTdHlsZTogeCA9PiB7XG4gICAgICAgICAgZXhwZWN0KHgpLnRvRXF1YWwoe2FuaW1hdGlvbk5hbWU6IFwiZm9vXCJ9KTtcbiAgICAgICAgICByZXR1cm4gXCJcIjtcbiAgICAgICAgfSxcbiAgICAgICAgcmVuZGVyS2V5ZnJhbWVzOiB4ID0+IHtcbiAgICAgICAgICBleHBlY3QoeCkudG9FcXVhbChrZXlmcmFtZXMpO1xuICAgICAgICAgIHJldHVybiBcImZvb1wiO1xuICAgICAgICB9LFxuICAgICAgICByZW5kZXJGb250RmFjZTogKCkgPT4gXCJcIixcbiAgICAgIH19XG4gICAgPlxuICAgICAgPFdpZGdldCAvPlxuICAgIDwvUHJvdmlkZXI+LFxuICApO1xufSk7XG5cbnRlc3QoXCJjcmVhdGVTdHlsZWQgd3JhcHBlclwiLCAoKSA9PiB7XG4gIGNvbnN0IGN1c3RvbVN0eWxlZCA9IGNyZWF0ZVN0eWxlZCh7XG4gICAgZHJpdmVyLFxuICAgIGdldEluaXRpYWxTdHlsZSxcbiAgICB3cmFwcGVyOiBfQ29tcG9uZW50ID0+IHByb3BzID0+IHtcbiAgICAgIGV4cGVjdChwcm9wcy5mb28pLnRvQmUoXCJmb29cIik7XG4gICAgICByZXR1cm4gPGRpdj5oZWxsbyB3b3JsZDwvZGl2PjtcbiAgICB9LFxuICB9KTtcbiAgY29uc3QgV2lkZ2V0ID0gY3VzdG9tU3R5bGVkPFwiZGl2XCIsIHtmb286IHN0cmluZ30+KFwiZGl2XCIsIHtcbiAgICBjb2xvcjogXCJyZWRcIixcbiAgfSk7XG4gIEVuenltZS5tb3VudChcbiAgICA8UHJvdmlkZXJcbiAgICAgIHZhbHVlPXt7XG4gICAgICAgIHJlbmRlclN0eWxlOiAoKSA9PiBcIlwiLFxuICAgICAgICByZW5kZXJLZXlmcmFtZXM6ICgpID0+IFwiXCIsXG4gICAgICAgIHJlbmRlckZvbnRGYWNlOiAoKSA9PiBcIlwiLFxuICAgICAgfX1cbiAgICA+XG4gICAgICA8V2lkZ2V0IGZvbz1cImZvb1wiIC8+XG4gICAgPC9Qcm92aWRlcj4sXG4gICk7XG59KTtcblxudGVzdChcInVzZVN0eWxldHJvbiBjc3NcIiwgKCkgPT4ge1xuICBmdW5jdGlvbiBMaW5rKCkge1xuICAgIGNvbnN0IFtjc3NdID0gdXNlU3R5bGV0cm9uKCk7XG4gICAgY29uc3QgY2xhc3NOYW1lID0gY3NzKHtjb2xvcjogXCJibHVlXCJ9KTtcbiAgICBleHBlY3QoY2xhc3NOYW1lKS50b0JlKFwiLmFiY1wiKTtcbiAgICByZXR1cm4gPGEgY2xhc3NOYW1lPXtjbGFzc05hbWV9PkZvbzwvYT47XG4gIH1cblxuICBFbnp5bWUubW91bnQoXG4gICAgPFByb3ZpZGVyXG4gICAgICB2YWx1ZT17e1xuICAgICAgICByZW5kZXJTdHlsZTogeCA9PiB7XG4gICAgICAgICAgZXhwZWN0KHgpLnRvRXF1YWwoe1xuICAgICAgICAgICAgY29sb3I6IFwiYmx1ZVwiLFxuICAgICAgICAgIH0pO1xuICAgICAgICAgIHJldHVybiBcIi5hYmNcIjtcbiAgICAgICAgfSxcbiAgICAgICAgcmVuZGVyS2V5ZnJhbWVzOiAoKSA9PiBcIlwiLFxuICAgICAgICByZW5kZXJGb250RmFjZTogKCkgPT4gXCJcIixcbiAgICAgIH19XG4gICAgPlxuICAgICAgPExpbmsgLz5cbiAgICA8L1Byb3ZpZGVyPixcbiAgKTtcbn0pO1xuXG50ZXN0KFwidXNlU3R5bGV0cm9uIGRlYnVnIG1vZGVcIiwgKCkgPT4ge1xuICBmdW5jdGlvbiBXaWRnZXQoKSB7XG4gICAgY29uc3QgW2Nzc10gPSB1c2VTdHlsZXRyb24oKTtcbiAgICBjb25zdCBbb24sIHNldE9uXSA9IFJlYWN0LnVzZVN0YXRlKGZhbHNlKTtcbiAgICBjb25zdCBjbGFzc05hbWUgPSBjc3Moe2NvbG9yOiBcInJlZFwifSk7XG4gICAgcmV0dXJuIChcbiAgICAgIDxidXR0b24gb25DbGljaz17KCkgPT4gc2V0T24oIW9uKX0gY2xhc3NOYW1lPXtjbGFzc05hbWV9PlxuICAgICAgICB0ZXN0XG4gICAgICA8L2J1dHRvbj5cbiAgICApO1xuICB9XG5cbiAgbGV0IGRlYnVnQ2FsbENvdW50ID0gMDtcbiAgY29uc3Qgd3JhcHBlciA9IEVuenltZS5tb3VudChcbiAgICA8UHJvdmlkZXJcbiAgICAgIHZhbHVlPXt7XG4gICAgICAgIHJlbmRlclN0eWxlOiAoKSA9PiBcImJhclwiLFxuICAgICAgICByZW5kZXJLZXlmcmFtZXM6ICgpID0+IFwiXCIsXG4gICAgICAgIHJlbmRlckZvbnRGYWNlOiAoKSA9PiBcIlwiLFxuICAgICAgfX1cbiAgICAgIGRlYnVnPXt7XG4gICAgICAgIGRlYnVnOiAoKSA9PiB7XG4gICAgICAgICAgZGVidWdDYWxsQ291bnQrKztcbiAgICAgICAgICByZXR1cm4gYF9fZGVidWctJHtkZWJ1Z0NhbGxDb3VudH1gO1xuICAgICAgICB9LFxuICAgICAgfX1cbiAgICA+XG4gICAgICA8V2lkZ2V0IC8+XG4gICAgPC9Qcm92aWRlcj4sXG4gICk7XG5cbiAgY29uc3QgYnV0dG9uID0gd3JhcHBlci5maW5kKFwiYnV0dG9uXCIpO1xuICBleHBlY3QoYnV0dG9uLmhhc0NsYXNzKFwiX19kZWJ1Zy0xIGJhclwiKSkudG9CZSh0cnVlKTtcbiAgYnV0dG9uLnNpbXVsYXRlKFwiY2xpY2tcIik7XG4gIGV4cGVjdChidXR0b24uaGFzQ2xhc3MoXCJfX2RlYnVnLTEgYmFyXCIpKS50b0JlKHRydWUpO1xuICBleHBlY3QoZGVidWdDYWxsQ291bnQpLnRvQmUoMSk7XG59KTtcblxudGVzdChcIm5vLW9wIGVuZ2luZVwiLCAoKSA9PiB7XG4gIGNvbnN0IGNvbnNvbGVXYXJuID0gY29uc29sZS53YXJuOyAvLyBlc2xpbnQtZGlzYWJsZS1saW5lXG5cbiAgKGNvbnNvbGUgYXMgYW55KS53YXJuID0gbWVzc2FnZSA9PiB7XG4gICAgZXhwZWN0KG1lc3NhZ2Uuc3BsaXQoXCJcXG5cIilbMV0pLnRvQmUoXG4gICAgICBcIlN0eWxldHJvbiBoYXMgYmVlbiBzd2l0Y2hlZCB0byBhIG5vLW9wICh0ZXN0KSBtb2RlLlwiLFxuICAgICk7XG4gIH07XG4gIGNvbnN0IFdpZGdldCA9IHN0eWxlZChcImRpdlwiLCB7XG4gICAgY29sb3I6IFwicmVkXCIsXG4gIH0pO1xuICBFbnp5bWUubW91bnQoPFdpZGdldCAvPik7XG5cbiAgKGNvbnNvbGUgYXMgYW55KS53YXJuID0gY29uc29sZVdhcm47XG59KTtcbiJdLCJtYXBwaW5ncyI6Ijs7QUFBQTs7QUFDQTs7QUFDQTs7QUFFQTs7QUFVQTs7Ozs7Ozs7QUFHQUEsZUFBQSxDQUFPQyxTQUFQLENBQWlCO0VBQUNDLE9BQU8sRUFBRSxJQUFJQywyQkFBSjtBQUFWLENBQWpCOztBQUVBQyxJQUFJLENBQUMsaUJBQUQsRUFBb0IsTUFBTTtFQUM1QixNQUFNQyxLQUFLLEdBQUc7SUFBQ0MsS0FBSyxFQUFFO0VBQVIsQ0FBZDtFQUNBLE1BQU1DLE1BQU0sR0FBRyxJQUFBQyxhQUFBLEVBQU8sS0FBUCxFQUFjSCxLQUFkLENBQWY7O0VBQ0FMLGVBQUEsQ0FBT1MsS0FBUCxlQUNFLG9CQUFDLGVBQUQ7SUFDRSxLQUFLLEVBQUU7TUFDTEMsV0FBVyxFQUFFQyxDQUFDLElBQUk7UUFDaEJDLE1BQU0sQ0FBQ0QsQ0FBRCxDQUFOLENBQVVFLE9BQVYsQ0FBa0JSLEtBQWxCO1FBQ0EsT0FBTyxFQUFQO01BQ0QsQ0FKSTtNQUtMUyxlQUFlLEVBQUUsTUFBTSxFQUxsQjtNQU1MQyxjQUFjLEVBQUUsTUFBTTtJQU5qQjtFQURULGdCQVVFLG9CQUFDLE1BQUQsT0FWRixDQURGOztFQWNBLE1BQU1DLE9BQU8sR0FBR2hCLGVBQUEsQ0FBT1MsS0FBUCxlQUNkLG9CQUFDLGVBQUQ7SUFDRSxLQUFLLEVBQUU7TUFDTEMsV0FBVyxFQUFFLE1BQU0sS0FEZDtNQUVMSSxlQUFlLEVBQUUsTUFBTSxFQUZsQjtNQUdMQyxjQUFjLEVBQUUsTUFBTTtJQUhqQjtFQURULGdCQU9FLG9CQUFDLE1BQUQ7SUFBUSxTQUFTLEVBQUM7RUFBbEIsRUFQRixDQURjLENBQWhCOztFQVdBLE1BQU1FLElBQUksR0FBR0QsT0FBTyxDQUFDRSxJQUFSLENBQWEsS0FBYixDQUFiO0VBQ0FOLE1BQU0sQ0FBQ0ssSUFBSSxDQUFDRSxNQUFOLENBQU4sQ0FBb0JDLElBQXBCLENBQXlCLENBQXpCO0VBQ0FSLE1BQU0sQ0FBQ0ssSUFBSSxDQUFDSSxRQUFMLENBQWMsU0FBZCxDQUFELENBQU4sQ0FBaUNELElBQWpDLENBQXNDLElBQXRDO0FBQ0QsQ0EvQkcsQ0FBSjtBQWlDQWhCLElBQUksQ0FBQyxrQkFBRCxFQUFxQixNQUFNO0VBQzdCLE1BQU1HLE1BQU0sR0FBRyxJQUFBQyxhQUFBLEVBQU8sS0FBUCxFQUFlYyxLQUFELEtBQTZCO0lBQ3hEaEIsS0FBSyxFQUFFZ0IsS0FBSyxDQUFDQyxJQUFOLEdBQWEsS0FBYixHQUFxQjtFQUQ0QixDQUE3QixDQUFkLENBQWY7O0VBSUF2QixlQUFBLENBQU9TLEtBQVAsZUFDRSxvQkFBQyxlQUFEO0lBQ0UsS0FBSyxFQUFFO01BQ0xDLFdBQVcsRUFBRUMsQ0FBQyxJQUFJO1FBQ2hCQyxNQUFNLENBQUNELENBQUQsQ0FBTixDQUFVRSxPQUFWLENBQWtCO1VBQUNQLEtBQUssRUFBRTtRQUFSLENBQWxCO1FBQ0EsT0FBTyxFQUFQO01BQ0QsQ0FKSTtNQUtMUSxlQUFlLEVBQUUsTUFBTSxFQUxsQjtNQU1MQyxjQUFjLEVBQUUsTUFBTTtJQU5qQjtFQURULGdCQVVFLG9CQUFDLE1BQUQ7SUFBUSxJQUFJLEVBQUU7RUFBZCxFQVZGLENBREY7QUFjRCxDQW5CRyxDQUFKO0FBcUJBWCxJQUFJLENBQUMsb0JBQUQsRUFBdUIsTUFBTTtFQUMvQixNQUFNRyxNQUFNLEdBQUcsSUFBQUMsYUFBQSxFQUFPLEtBQVAsRUFBYztJQUMzQmdCLFdBQVcsRUFBRSxDQURjO0lBRTNCbEIsS0FBSyxFQUFFLEtBRm9CO0lBRzNCLFVBQVU7TUFBQ21CLFFBQVEsRUFBRTtJQUFYO0VBSGlCLENBQWQsQ0FBZjtFQUtBLE1BQU1DLFdBQVcsR0FBRyxJQUFBQyxnQkFBQSxFQUFVcEIsTUFBVixFQUFrQjtJQUNwQ0QsS0FBSyxFQUFFLE1BRDZCO0lBRXBDLFVBQVU7TUFBQ2tCLFdBQVcsRUFBRTtJQUFkO0VBRjBCLENBQWxCLENBQXBCOztFQUlBeEIsZUFBQSxDQUFPUyxLQUFQLGVBQ0Usb0JBQUMsZUFBRDtJQUNFLEtBQUssRUFBRTtNQUNMQyxXQUFXLEVBQUVDLENBQUMsSUFBSTtRQUNoQkMsTUFBTSxDQUFDRCxDQUFELENBQU4sQ0FBVUUsT0FBVixDQUFrQjtVQUNoQlcsV0FBVyxFQUFFLENBREc7VUFFaEJsQixLQUFLLEVBQUUsTUFGUztVQUdoQixVQUFVO1lBQUNtQixRQUFRLEVBQUUsTUFBWDtZQUFtQkQsV0FBVyxFQUFFO1VBQWhDO1FBSE0sQ0FBbEI7UUFLQSxPQUFPLEVBQVA7TUFDRCxDQVJJO01BU0xWLGVBQWUsRUFBRSxNQUFNLEVBVGxCO01BVUxDLGNBQWMsRUFBRSxNQUFNO0lBVmpCO0VBRFQsZ0JBY0Usb0JBQUMsV0FBRCxPQWRGLENBREY7QUFrQkQsQ0E1QkcsQ0FBSjtBQThCQVgsSUFBSSxDQUFDLHFCQUFELEVBQXdCLE1BQU07RUFDaEMsTUFBTUcsTUFBTSxHQUFHLElBQUFDLGFBQUEsRUFBTyxLQUFQLEVBQWM7SUFDM0JvQixVQUFVLEVBQUUsQ0FEZTtJQUUzQnRCLEtBQUssRUFBRSxLQUZvQjtJQUczQixVQUFVO01BQUNtQixRQUFRLEVBQUU7SUFBWDtFQUhpQixDQUFkLENBQWY7RUFLQSxNQUFNQyxXQUFXLEdBQUcsSUFBQUMsZ0JBQUEsRUFDbEJwQixNQURrQixFQUVsQmUsS0FBSyxLQUFLO0lBQ1JPLFVBQVUsRUFBRVAsS0FBSyxDQUFDUSxNQUFOLEdBQWUsUUFBZixHQUEwQixPQUQ5QjtJQUVSLFVBQVU7TUFBQ04sV0FBVyxFQUFFO0lBQWQ7RUFGRixDQUFMLENBRmEsQ0FBcEI7O0VBT0F4QixlQUFBLENBQU9TLEtBQVAsZUFDRSxvQkFBQyxlQUFEO0lBQ0UsS0FBSyxFQUFFO01BQ0xDLFdBQVcsRUFBRUMsQ0FBQyxJQUFJO1FBQ2hCQyxNQUFNLENBQUNELENBQUQsQ0FBTixDQUFVRSxPQUFWLENBQWtCO1VBQ2hCUCxLQUFLLEVBQUUsS0FEUztVQUVoQnVCLFVBQVUsRUFBRSxRQUZJO1VBR2hCRCxVQUFVLEVBQUUsQ0FISTtVQUloQixVQUFVO1lBQUNKLFdBQVcsRUFBRSxDQUFkO1lBQWlCQyxRQUFRLEVBQUU7VUFBM0I7UUFKTSxDQUFsQjtRQU9BLE9BQU8sRUFBUDtNQUNELENBVkk7TUFXTFgsZUFBZSxFQUFFLE1BQU0sRUFYbEI7TUFZTEMsY0FBYyxFQUFFLE1BQU07SUFaakI7RUFEVCxnQkFnQkUsb0JBQUMsV0FBRDtJQUFhLE1BQU0sRUFBRTtFQUFyQixFQWhCRixDQURGO0FBb0JELENBakNHLENBQUo7QUFtQ0FYLElBQUksQ0FBQyxzQkFBRCxFQUF5QixNQUFNO0VBQ2pDLE1BQU1HLE1BQU0sR0FBRyxJQUFBQyxhQUFBLEVBQU8sS0FBUCxFQUFjO0lBQzNCb0IsVUFBVSxFQUFFLENBRGU7SUFFM0J0QixLQUFLLEVBQUUsS0FGb0I7SUFHM0IsVUFBVTtNQUFDbUIsUUFBUSxFQUFFO0lBQVg7RUFIaUIsQ0FBZCxDQUFmOztFQU1BekIsZUFBQSxDQUFPUyxLQUFQLGVBQ0Usb0JBQUMsZUFBRDtJQUNFLEtBQUssRUFBRTtNQUNMQyxXQUFXLEVBQUVDLENBQUMsSUFBSTtRQUNoQkMsTUFBTSxDQUFDRCxDQUFELENBQU4sQ0FBVUUsT0FBVixDQUFrQjtVQUNoQlAsS0FBSyxFQUFFLE1BRFM7VUFFaEJzQixVQUFVLEVBQUUsQ0FGSTtVQUdoQixVQUFVO1lBQUNILFFBQVEsRUFBRTtVQUFYO1FBSE0sQ0FBbEI7UUFLQSxPQUFPLEVBQVA7TUFDRCxDQVJJO01BU0xYLGVBQWUsRUFBRSxNQUFNLEVBVGxCO01BVUxDLGNBQWMsRUFBRSxNQUFNO0lBVmpCO0VBRFQsZ0JBY0Usb0JBQUMsTUFBRDtJQUFRLE1BQU0sRUFBRTtNQUFDVCxLQUFLLEVBQUU7SUFBUjtFQUFoQixFQWRGLENBREY7QUFrQkQsQ0F6QkcsQ0FBSjtBQTJCQUYsSUFBSSxDQUFDLHVCQUFELEVBQTBCLE1BQU07RUFDbEMsTUFBTUcsTUFBTSxHQUFHLElBQUFDLGFBQUEsRUFBaUMsS0FBakMsRUFBd0M7SUFDckRvQixVQUFVLEVBQUUsQ0FEeUM7SUFFckR0QixLQUFLLEVBQUUsS0FGOEM7SUFHckQsVUFBVTtNQUFDbUIsUUFBUSxFQUFFO0lBQVg7RUFIMkMsQ0FBeEMsQ0FBZjs7RUFNQXpCLGVBQUEsQ0FBT1MsS0FBUCxlQUNFLG9CQUFDLGVBQUQ7SUFDRSxLQUFLLEVBQUU7TUFDTEMsV0FBVyxFQUFFQyxDQUFDLElBQUk7UUFDaEJDLE1BQU0sQ0FBQ0QsQ0FBRCxDQUFOLENBQVVFLE9BQVYsQ0FBa0I7VUFDaEJQLEtBQUssRUFBRSxNQURTO1VBRWhCdUIsVUFBVSxFQUFFLFFBRkk7VUFHaEJELFVBQVUsRUFBRSxDQUhJO1VBSWhCLFVBQVU7WUFBQ0gsUUFBUSxFQUFFLE1BQVg7WUFBbUJELFdBQVcsRUFBRTtVQUFoQztRQUpNLENBQWxCO1FBTUEsT0FBTyxFQUFQO01BQ0QsQ0FUSTtNQVVMVixlQUFlLEVBQUUsTUFBTSxFQVZsQjtNQVdMQyxjQUFjLEVBQUUsTUFBTTtJQVhqQjtFQURULGdCQWVFLG9CQUFDLE1BQUQ7SUFDRSxNQUFNLEVBQUVPLEtBQUssS0FBSztNQUNoQmhCLEtBQUssRUFBRSxNQURTO01BRWhCdUIsVUFBVSxFQUFFUCxLQUFLLENBQUNRLE1BQU4sR0FBZSxRQUFmLEdBQTBCLE9BRnRCO01BR2hCLFVBQVU7UUFBQ04sV0FBVyxFQUFFO01BQWQ7SUFITSxDQUFMLENBRGY7SUFNRSxNQUFNLEVBQUU7RUFOVixFQWZGLENBREY7QUEwQkQsQ0FqQ0csQ0FBSjtBQW1DQXBCLElBQUksQ0FBQyxtQ0FBRCxFQUFzQyxNQUFNO0VBQzlDLE1BQU1HLE1BQU0sR0FBRyxJQUFBQyxhQUFBLEVBQU8sS0FBUCxFQUFjO0lBQzNCRixLQUFLLEVBQUUsS0FEb0I7SUFFM0JtQixRQUFRLEVBQUU7RUFGaUIsQ0FBZCxDQUFmO0VBS0EsTUFBTU0sV0FBVyxHQUFHLElBQUFKLGdCQUFBLEVBQVVwQixNQUFWLEVBQWtCO0lBQUNELEtBQUssRUFBRTtFQUFSLENBQWxCLENBQXBCO0VBQ0EsTUFBTTBCLGNBQWMsR0FBRyxJQUFBTCxnQkFBQSxFQUFVSSxXQUFWLEVBQXVCO0lBQUNOLFFBQVEsRUFBRTtFQUFYLENBQXZCLENBQXZCOztFQUVBekIsZUFBQSxDQUFPUyxLQUFQLGVBQ0Usb0JBQUMsZUFBRDtJQUNFLEtBQUssRUFBRTtNQUNMQyxXQUFXLEVBQUVDLENBQUMsSUFBSTtRQUNoQkMsTUFBTSxDQUFDRCxDQUFELENBQU4sQ0FBVUUsT0FBVixDQUFrQjtVQUNoQlAsS0FBSyxFQUFFLFFBRFM7VUFFaEJtQixRQUFRLEVBQUUsTUFGTTtVQUdoQlEsT0FBTyxFQUFFO1FBSE8sQ0FBbEI7UUFLQSxPQUFPLEVBQVA7TUFDRCxDQVJJO01BU0xuQixlQUFlLEVBQUUsTUFBTSxFQVRsQjtNQVVMQyxjQUFjLEVBQUUsTUFBTTtJQVZqQjtFQURULGdCQWNFLG9CQUFDLGNBQUQ7SUFDRSxNQUFNLEVBQUU7TUFDTlQsS0FBSyxFQUFFLFFBREQ7TUFFTjJCLE9BQU8sRUFBRTtJQUZIO0VBRFYsRUFkRixDQURGO0FBdUJELENBaENHLENBQUo7QUFrQ0E3QixJQUFJLENBQUMsZUFBRCxFQUFrQixNQUFNO0VBQzFCLE1BQU1HLE1BQU0sR0FBRyxJQUFBQyxhQUFBLEVBQU8sS0FBUCxFQUFjO0lBQUNGLEtBQUssRUFBRSxLQUFSO0lBQWV1QixVQUFVLEVBQUU7RUFBM0IsQ0FBZCxDQUFmO0VBQ0EsTUFBTUgsV0FBVyxHQUFHLElBQUFRLG9CQUFBLEVBQ2xCM0IsTUFEa0IsRUFFbEIsQ0FBQ0YsS0FBRCxFQUFRaUIsS0FBUixNQUFzQyxFQUNwQyxHQUFHakIsS0FEaUM7SUFFcEN3QixVQUFVLEVBQUVQLEtBQUssQ0FBQ1EsTUFBTixHQUFlLFFBQWYsR0FBMEI7RUFGRixDQUF0QyxDQUZrQixDQUFwQjs7RUFPQTlCLGVBQUEsQ0FBT1MsS0FBUCxlQUNFLG9CQUFDLGVBQUQ7SUFDRSxLQUFLLEVBQUU7TUFDTEMsV0FBVyxFQUFFQyxDQUFDLElBQUk7UUFDaEJDLE1BQU0sQ0FBQ0QsQ0FBRCxDQUFOLENBQVVFLE9BQVYsQ0FBa0I7VUFBQ1AsS0FBSyxFQUFFLEtBQVI7VUFBZXVCLFVBQVUsRUFBRTtRQUEzQixDQUFsQjtRQUNBLE9BQU8sRUFBUDtNQUNELENBSkk7TUFLTGQsY0FBYyxFQUFFLE1BQU07UUFDcEIsT0FBTyxFQUFQO01BQ0QsQ0FQSTtNQVFMRCxlQUFlLEVBQUUsTUFBTTtRQUNyQixPQUFPLEVBQVA7TUFDRDtJQVZJO0VBRFQsZ0JBY0Usb0JBQUMsV0FBRDtJQUFhLE1BQU0sRUFBRTtFQUFyQixFQWRGLENBREY7QUFrQkQsQ0EzQkcsQ0FBSjtBQTZCQVYsSUFBSSxDQUFDLFdBQUQsRUFBYyxNQUFNO0VBQ3RCLE1BQU1HLE1BQU0sR0FBRyxJQUFBQyxhQUFBLEVBQU8sS0FBUCxFQUFjLEVBQWQsQ0FBZjs7RUFDQSxNQUFNMkIsYUFBYSxHQUFHYixLQUFLLElBQUk7SUFDN0JWLE1BQU0sQ0FBQ1UsS0FBSyxDQUFDYyxTQUFQLENBQU4sQ0FBd0JoQixJQUF4QixDQUE2QixLQUE3QjtJQUNBLG9CQUFPLGdDQUFQO0VBQ0QsQ0FIRDs7RUFJQXBCLGVBQUEsQ0FBT1MsS0FBUCxlQUNFLG9CQUFDLGVBQUQ7SUFDRSxLQUFLLEVBQUU7TUFDTEMsV0FBVyxFQUFFLE1BQU0sS0FEZDtNQUVMSSxlQUFlLEVBQUUsTUFBTSxFQUZsQjtNQUdMQyxjQUFjLEVBQUUsTUFBTTtJQUhqQjtFQURULGdCQU9FLG9CQUFDLE1BQUQ7SUFBUSxHQUFHLEVBQUVvQjtFQUFiLEVBUEYsQ0FERjs7RUFXQSxNQUFNbkIsT0FBTyxHQUFHaEIsZUFBQSxDQUFPUyxLQUFQLGVBQ2Qsb0JBQUMsZUFBRDtJQUNFLEtBQUssRUFBRTtNQUNMQyxXQUFXLEVBQUUsTUFBTSxFQURkO01BRUxJLGVBQWUsRUFBRSxNQUFNLEVBRmxCO01BR0xDLGNBQWMsRUFBRSxNQUFNO0lBSGpCO0VBRFQsZ0JBT0Usb0JBQUMsTUFBRDtJQUFRLEdBQUcsRUFBQztFQUFaLEVBUEYsQ0FEYyxDQUFoQjs7RUFXQUgsTUFBTSxDQUFDSSxPQUFPLENBQUNFLElBQVIsQ0FBYSxNQUFiLEVBQXFCQyxNQUF0QixDQUFOLENBQW9DQyxJQUFwQyxDQUF5QyxDQUF6QztBQUNELENBN0JHLENBQUo7QUErQkFoQixJQUFJLENBQUMsNkJBQUQsRUFBZ0MsTUFBTTtFQUN4QyxNQUFNaUMsY0FBTixTQUE2QkMsS0FBSyxDQUFDQyxTQUFuQyxDQUVHO0lBQ0RDLE1BQU0sR0FBRztNQUNQNUIsTUFBTSxDQUFDLEtBQUtVLEtBQU4sQ0FBTixDQUFtQlQsT0FBbkIsQ0FBMkI7UUFDekJ1QixTQUFTLEVBQUUsWUFEYztRQUV6QixZQUFZO01BRmEsQ0FBM0I7TUFJQSxvQkFBTyxxREFBUDtJQUNEOztFQVBBOztFQVVILE1BQU03QixNQUFNLEdBQUcsSUFBQUMsYUFBQSxFQUNiNkIsY0FEYSxFQUViO0lBQUMvQixLQUFLLEVBQUU7RUFBUixDQUZhLENBQWY7O0VBS0FOLGVBQUEsQ0FBT1MsS0FBUCxlQUNFLG9CQUFDLGVBQUQ7SUFDRSxLQUFLLEVBQUU7TUFDTEMsV0FBVyxFQUFFLE1BQU0sWUFEZDtNQUVMSSxlQUFlLEVBQUUsTUFBTSxFQUZsQjtNQUdMQyxjQUFjLEVBQUUsTUFBTTtJQUhqQjtFQURULGdCQU9FLG9CQUFDLE1BQUQ7SUFBUSxJQUFJLEVBQUMsS0FBYjtJQUFtQixJQUFJLEVBQUMsS0FBeEI7SUFBOEIsWUFBUztFQUF2QyxFQVBGLENBREY7QUFXRCxDQTdCRyxDQUFKO0FBK0JBWCxJQUFJLENBQUMseUJBQUQsRUFBNEIsTUFBTTtFQUNwQyxNQUFNRyxNQUFNLEdBQUcsSUFBQUMsYUFBQSxFQUFPLFFBQVAsRUFBaUI7SUFBQ0YsS0FBSyxFQUFFO0VBQVIsQ0FBakIsQ0FBZjs7RUFDQSxNQUFNbUMsYUFBTixTQUE0QkgsS0FBSyxDQUFDQyxTQUFsQyxDQUFnRDtJQUU5Q0csaUJBQWlCLEdBQUc7TUFDbEI5QixNQUFNLENBQUMsS0FBSytCLFdBQUwsWUFBNEJDLGlCQUE3QixDQUFOLENBQXNEeEIsSUFBdEQsQ0FBMkQsSUFBM0Q7SUFDRDs7SUFFRG9CLE1BQU0sR0FBRztNQUNQLG9CQUNFLG9CQUFDLGVBQUQ7UUFDRSxLQUFLLEVBQUU7VUFDTDlCLFdBQVcsRUFBRSxNQUFNLEVBRGQ7VUFFTEksZUFBZSxFQUFFLE1BQU0sRUFGbEI7VUFHTEMsY0FBYyxFQUFFLE1BQU07UUFIakI7TUFEVCxnQkFPRSxvQkFBQyxNQUFEO1FBQ0UsR0FBRyxFQUFFOEIsQ0FBQyxJQUFJO1VBQ1IsS0FBS0YsV0FBTCxHQUFtQkUsQ0FBbkI7UUFDRDtNQUhILEVBUEYsQ0FERjtJQWVEOztFQXRCNkM7O0VBd0JoRDdDLGVBQUEsQ0FBT1MsS0FBUCxlQUFhLG9CQUFDLGFBQUQsT0FBYjtBQUNELENBM0JHLENBQUo7QUE2QkFMLElBQUksQ0FBQyxrQ0FBRCxFQUFxQyxNQUFNO0VBQzdDLE1BQU1HLE1BQU0sR0FBRyxJQUFBQyxhQUFBLEVBQU8sUUFBUCxFQUFpQjtJQUFDRixLQUFLLEVBQUU7RUFBUixDQUFqQixDQUFmOztFQUNBLE1BQU1tQyxhQUFOLFNBQTRCSCxLQUFLLENBQUNDLFNBQWxDLENBQWdEO0lBQzlDSSxXQUFXLGdCQUFHTCxLQUFLLENBQUNRLFNBQU4sRUFBSDs7SUFFWEosaUJBQWlCLEdBQUc7TUFDbEI5QixNQUFNLENBQUMsS0FBSytCLFdBQUwsQ0FBaUJJLE9BQWpCLFlBQW9DSCxpQkFBckMsQ0FBTixDQUE4RHhCLElBQTlELENBQW1FLElBQW5FO0lBQ0Q7O0lBRURvQixNQUFNLEdBQUc7TUFDUCxvQkFDRSxvQkFBQyxlQUFEO1FBQ0UsS0FBSyxFQUFFO1VBQ0w5QixXQUFXLEVBQUUsTUFBTSxFQURkO1VBRUxJLGVBQWUsRUFBRSxNQUFNLEVBRmxCO1VBR0xDLGNBQWMsRUFBRSxNQUFNO1FBSGpCO01BRFQsZ0JBT0Usb0JBQUMsTUFBRDtRQUFRLEdBQUcsRUFBRSxLQUFLNEI7TUFBbEIsRUFQRixDQURGO0lBV0Q7O0VBbkI2Qzs7RUFxQmhEM0MsZUFBQSxDQUFPUyxLQUFQLGVBQWEsb0JBQUMsYUFBRCxPQUFiO0FBQ0QsQ0F4QkcsQ0FBSjtBQTBCQUwsSUFBSSxDQUFDLCtCQUFELEVBQWtDLE1BQU07RUFDMUMsTUFBTUcsTUFBTSxHQUFHLElBQUFDLGFBQUEsRUFBTyxRQUFQLEVBQWlCO0lBQUNGLEtBQUssRUFBRTtFQUFSLENBQWpCLENBQWY7O0VBQ0EsTUFBTW1DLGFBQWEsR0FBRyxNQUFNO0lBQzFCLE1BQU1FLFdBQVcsR0FBR0wsS0FBSyxDQUFDVSxNQUFOLENBQWdDLElBQWhDLENBQXBCO0lBQ0FWLEtBQUssQ0FBQ1csU0FBTixDQUFnQixNQUFNO01BQ3BCckMsTUFBTSxDQUFDK0IsV0FBVyxDQUFDSSxPQUFaLFlBQStCSCxpQkFBaEMsQ0FBTixDQUF5RHhCLElBQXpELENBQThELElBQTlEO0lBQ0QsQ0FGRCxFQUVHLEVBRkg7SUFHQSxvQkFDRSxvQkFBQyxlQUFEO01BQ0UsS0FBSyxFQUFFO1FBQ0xWLFdBQVcsRUFBRSxNQUFNLEVBRGQ7UUFFTEksZUFBZSxFQUFFLE1BQU0sRUFGbEI7UUFHTEMsY0FBYyxFQUFFLE1BQU07TUFIakI7SUFEVCxnQkFPRSxvQkFBQyxNQUFEO01BQVEsR0FBRyxFQUFFNEI7SUFBYixFQVBGLENBREY7RUFXRCxDQWhCRDs7RUFrQkEzQyxlQUFBLENBQU9TLEtBQVAsZUFBYSxvQkFBQyxhQUFELE9BQWI7QUFDRCxDQXJCRyxDQUFKO0FBdUJBTCxJQUFJLENBQUMsOEJBQUQsRUFBaUMsTUFBTTtFQUN6QyxNQUFNRyxNQUFNLEdBQUcsSUFBQUMsYUFBQSxFQUFPLFFBQVAsRUFBaUI7SUFBQ0YsS0FBSyxFQUFFO0VBQVIsQ0FBakIsQ0FBZjs7RUFDQSxNQUFNbUMsYUFBTixTQUE0QkgsS0FBSyxDQUFDQyxTQUFsQyxDQUFnRDtJQUM5Q0csaUJBQWlCLEdBQUc7TUFDbEI5QixNQUFNLENBQUMsS0FBS3NDLElBQUwsQ0FBVUMsUUFBVixZQUE4QlAsaUJBQS9CLENBQU4sQ0FBd0R4QixJQUF4RCxDQUE2RCxJQUE3RDtJQUNEOztJQUNEb0IsTUFBTSxHQUFHO01BQ1Asb0JBQ0Usb0JBQUMsZUFBRDtRQUNFLEtBQUssRUFBRTtVQUNMOUIsV0FBVyxFQUFFLE1BQU0sRUFEZDtVQUVMSSxlQUFlLEVBQUUsTUFBTSxFQUZsQjtVQUdMQyxjQUFjLEVBQUUsTUFBTTtRQUhqQjtNQURULGdCQU9FLG9CQUFDLE1BQUQ7UUFBUSxHQUFHLEVBQUM7TUFBWixFQVBGLENBREY7SUFXRDs7RUFoQjZDOztFQWtCaERmLGVBQUEsQ0FBT1MsS0FBUCxlQUFhLG9CQUFDLGFBQUQsT0FBYjtBQUNELENBckJHLENBQUo7QUF1QkFMLElBQUksQ0FBQyxhQUFELEVBQWdCLE1BQU07RUFDeEIsTUFBTUcsTUFBTSxHQUFHLElBQUFDLGFBQUEsRUFBaUMsUUFBakMsRUFBMkM7SUFDeERGLEtBQUssRUFBRTtFQURpRCxDQUEzQyxDQUFmO0VBR0EsTUFBTThDLGFBQWEsR0FBRyxJQUFBQyxrQkFBQSxFQUFZOUMsTUFBWixFQUFvQitDLGFBQWEsSUFBSWhDLEtBQUssSUFBSTtJQUNsRVYsTUFBTSxDQUFDVSxLQUFELENBQU4sQ0FBY1QsT0FBZCxDQUFzQjtNQUFDMEMsR0FBRyxFQUFFO0lBQU4sQ0FBdEI7SUFDQSxvQkFDRSxrREFDRSxvQkFBQyxhQUFELEVBQW1CakMsS0FBbkIsQ0FERixDQURGO0VBS0QsQ0FQcUIsQ0FBdEI7O0VBUUEsTUFBTWtDLFFBQVEsR0FBR3hELGVBQUEsQ0FBT1MsS0FBUCxlQUNmLG9CQUFDLGVBQUQ7SUFDRSxLQUFLLEVBQUU7TUFDTEMsV0FBVyxFQUFFTCxLQUFLLElBQUk7UUFDcEJPLE1BQU0sQ0FBQ1AsS0FBRCxDQUFOLENBQWNRLE9BQWQsQ0FBc0I7VUFBQ1AsS0FBSyxFQUFFO1FBQVIsQ0FBdEI7UUFDQSxPQUFPLEVBQVA7TUFDRCxDQUpJO01BS0xRLGVBQWUsRUFBRSxNQUFNLEVBTGxCO01BTUxDLGNBQWMsRUFBRSxNQUFNO0lBTmpCO0VBRFQsZ0JBVUUsb0JBQUMsYUFBRDtJQUFlLEdBQUcsRUFBQztFQUFuQixFQVZGLENBRGUsQ0FBakI7O0VBY0FILE1BQU0sQ0FBQzRDLFFBQVEsQ0FBQ3RDLElBQVQsQ0FBYyxTQUFkLEVBQXlCQyxNQUExQixDQUFOLENBQXdDQyxJQUF4QyxDQUE2QyxDQUE3QztFQUVBLE1BQU1xQyxtQkFBbUIsR0FBRyxJQUFBOUIsZ0JBQUEsRUFBVXlCLGFBQVYsRUFBeUI7SUFBQzlDLEtBQUssRUFBRTtFQUFSLENBQXpCLENBQTVCOztFQUNBLE1BQU1vRCxRQUFRLEdBQUcxRCxlQUFBLENBQU9TLEtBQVAsZUFDZixvQkFBQyxlQUFEO0lBQ0UsS0FBSyxFQUFFO01BQ0xDLFdBQVcsRUFBRUwsS0FBSyxJQUFJO1FBQ3BCTyxNQUFNLENBQUNQLEtBQUQsQ0FBTixDQUFjUSxPQUFkLENBQXNCO1VBQUNQLEtBQUssRUFBRTtRQUFSLENBQXRCO1FBQ0EsT0FBTyxFQUFQO01BQ0QsQ0FKSTtNQUtMUSxlQUFlLEVBQUUsTUFBTSxFQUxsQjtNQU1MQyxjQUFjLEVBQUUsTUFBTTtJQU5qQjtFQURULGdCQVVFLG9CQUFDLG1CQUFEO0lBQXFCLEdBQUcsRUFBQztFQUF6QixFQVZGLENBRGUsQ0FBakI7O0VBY0FILE1BQU0sQ0FBQzhDLFFBQVEsQ0FBQ3hDLElBQVQsQ0FBYyxTQUFkLEVBQXlCQyxNQUExQixDQUFOLENBQXdDQyxJQUF4QyxDQUE2QyxDQUE3QztBQUNELENBNUNHLENBQUo7QUE4Q0FoQixJQUFJLENBQUMsaUNBQUQsRUFBb0MsTUFBTTtFQUM1QyxJQUFJdUQsY0FBYyxHQUFHLENBQXJCO0VBRUEsTUFBTXRELEtBQUssR0FBRztJQUFDQyxLQUFLLEVBQUU7RUFBUixDQUFkO0VBQ0EsTUFBTUMsTUFBTSxHQUFHLElBQUFDLGFBQUEsRUFBTyxLQUFQLEVBQWNILEtBQWQsQ0FBZjs7RUFFQSxNQUFNVyxPQUFPLEdBQUdoQixlQUFBLENBQU9TLEtBQVAsZUFDZCxvQkFBQyxlQUFEO0lBQ0UsS0FBSyxFQUFFO01BQ0xDLFdBQVcsRUFBRSxNQUFNLEtBRGQ7TUFFTEksZUFBZSxFQUFFLE1BQU0sRUFGbEI7TUFHTEMsY0FBYyxFQUFFLE1BQU07SUFIakIsQ0FEVDtJQU1FLEtBQUssRUFBRTtNQUNMNkMsS0FBSyxFQUFFLENBQUM7UUFBQ0MsVUFBRDtRQUFhQztNQUFiLENBQUQsS0FBNkI7UUFDbENILGNBQWM7UUFDZC9DLE1BQU0sQ0FBQ2lELFVBQUQsQ0FBTixDQUFtQnpDLElBQW5CLENBQXdCLENBQXhCO1FBQ0FSLE1BQU0sQ0FBQyxPQUFPa0QsU0FBUixDQUFOLENBQXlCMUMsSUFBekIsQ0FBOEIsUUFBOUI7UUFDQVIsTUFBTSxDQUFDLE9BQU9rRCxTQUFTLENBQUNDLEtBQWxCLENBQU4sQ0FBK0IzQyxJQUEvQixDQUFvQyxRQUFwQztRQUNBUixNQUFNLENBQUMsT0FBT2tELFNBQVMsQ0FBQ0UsT0FBbEIsQ0FBTixDQUFpQzVDLElBQWpDLENBQXNDLFFBQXRDO1FBQ0EsT0FBTywyQkFBUDtNQUNEO0lBUkk7RUFOVCxnQkFpQkUsb0JBQUMsTUFBRDtJQUFRLFNBQVMsRUFBQztFQUFsQixFQWpCRixDQURjLENBQWhCOztFQXNCQSxNQUFNSCxJQUFJLEdBQUdELE9BQU8sQ0FBQ0UsSUFBUixDQUFhLEtBQWIsQ0FBYjtFQUNBTixNQUFNLENBQUNLLElBQUksQ0FBQ0UsTUFBTixDQUFOLENBQW9CQyxJQUFwQixDQUF5QixDQUF6QjtFQUNBUixNQUFNLENBQUNLLElBQUksQ0FBQ0ksUUFBTCxDQUFjLG1DQUFkLENBQUQsQ0FBTixDQUEyREQsSUFBM0QsQ0FBZ0UsSUFBaEU7RUFDQUosT0FBTyxDQUFDaUQsT0FBUjtFQUNBakQsT0FBTyxDQUFDUCxLQUFSO0VBQ0FPLE9BQU8sQ0FBQ2lELE9BQVI7RUFDQXJELE1BQU0sQ0FBQytDLGNBQUQsQ0FBTixDQUF1QnZDLElBQXZCLENBQTRCLENBQTVCO0FBQ0QsQ0FuQ0csQ0FBSjtBQXFDQWhCLElBQUksQ0FBQyx5QkFBRCxFQUE0QixNQUFNO0VBQ3BDLE1BQU1DLEtBQUssR0FBRztJQUFDQyxLQUFLLEVBQUU7RUFBUixDQUFkO0VBQ0EsSUFBSTRELEtBQUssR0FBRyxDQUFaO0VBQ0EsTUFBTTNELE1BQU0sR0FBRyxJQUFBQyxhQUFBLEVBQU8sS0FBUCxFQUFjSCxLQUFkLENBQWY7O0VBQ0EsTUFBTVcsT0FBTyxHQUFHaEIsZUFBQSxDQUFPUyxLQUFQLGVBQ2Qsb0JBQUMsZUFBRDtJQUNFLEtBQUssRUFBRTtNQUNMQyxXQUFXLEVBQUUsTUFBTTtRQUNqQndELEtBQUs7UUFDTCxPQUFPLEtBQVA7TUFDRCxDQUpJO01BS0xwRCxlQUFlLEVBQUUsTUFBTSxFQUxsQjtNQU1MQyxjQUFjLEVBQUUsTUFBTTtJQU5qQixDQURUO0lBU0UsS0FBSyxFQUFFO01BQ0w2QyxLQUFLLEVBQUUsTUFBTTtRQUNYaEQsTUFBTSxDQUFDc0QsS0FBRCxDQUFOLENBQWM5QyxJQUFkLENBQW1CLENBQW5CO1FBQ0EsT0FBTyxvQkFBUDtNQUNEO0lBSkksQ0FUVDtJQWVFLG1CQUFtQjtFQWZyQixnQkFpQkUsb0JBQUMsTUFBRCxPQWpCRixDQURjLENBQWhCOztFQXFCQSxNQUFNSCxJQUFJLEdBQUdELE9BQU8sQ0FBQ0UsSUFBUixDQUFhLEtBQWIsQ0FBYjtFQUNBTixNQUFNLENBQUNzRCxLQUFELENBQU4sQ0FBYzlDLElBQWQsQ0FBbUIsQ0FBbkI7RUFDQVIsTUFBTSxDQUFDSyxJQUFJLENBQUNJLFFBQUwsQ0FBYyx3QkFBZCxDQUFELENBQU4sQ0FBZ0RELElBQWhELENBQXFELElBQXJEO0FBQ0QsQ0E1QkcsQ0FBSjtBQThCQWhCLElBQUksQ0FBQyxxQkFBRCxFQUF3QixNQUFNO0VBQ2hDLE1BQU0rRCxRQUFRLEdBQUc7SUFDZkMsR0FBRyxFQUFFO0VBRFUsQ0FBakI7RUFHQSxNQUFNL0QsS0FBSyxHQUFHO0lBQUNnRSxVQUFVLEVBQUVGO0VBQWIsQ0FBZDtFQUNBLE1BQU01RCxNQUFNLEdBQUcsSUFBQUMsYUFBQSxFQUFPLEtBQVAsRUFBY0gsS0FBZCxDQUFmOztFQUNBTCxlQUFBLENBQU9TLEtBQVAsZUFDRSxvQkFBQyxlQUFEO0lBQ0UsS0FBSyxFQUFFO01BQ0xDLFdBQVcsRUFBRUMsQ0FBQyxJQUFJO1FBQ2hCQyxNQUFNLENBQUNELENBQUQsQ0FBTixDQUFVRSxPQUFWLENBQWtCO1VBQ2hCd0QsVUFBVSxFQUFFO1FBREksQ0FBbEI7UUFHQSxPQUFPLEVBQVA7TUFDRCxDQU5JO01BT0x0RCxjQUFjLEVBQUVKLENBQUMsSUFBSTtRQUNuQkMsTUFBTSxDQUFDRCxDQUFELENBQU4sQ0FBVUUsT0FBVixDQUFrQnNELFFBQWxCO1FBQ0EsT0FBTyxLQUFQO01BQ0QsQ0FWSTtNQVdMckQsZUFBZSxFQUFFLE1BQU07SUFYbEI7RUFEVCxnQkFlRSxvQkFBQyxNQUFELE9BZkYsQ0FERjtBQW1CRCxDQXpCRyxDQUFKO0FBMkJBVixJQUFJLENBQUMscUJBQUQsRUFBd0IsTUFBTTtFQUNoQyxNQUFNa0UsU0FBUyxHQUFHO0lBQ2hCQyxJQUFJLEVBQUU7TUFBQ2pFLEtBQUssRUFBRTtJQUFSLENBRFU7SUFFaEJrRSxFQUFFLEVBQUU7TUFBQ2xFLEtBQUssRUFBRTtJQUFSO0VBRlksQ0FBbEI7RUFJQSxNQUFNRCxLQUFLLEdBQUc7SUFBQ29FLGFBQWEsRUFBRUg7RUFBaEIsQ0FBZDtFQUNBLE1BQU0vRCxNQUFNLEdBQUcsSUFBQUMsYUFBQSxFQUFPLEtBQVAsRUFBY0gsS0FBZCxDQUFmOztFQUNBTCxlQUFBLENBQU9TLEtBQVAsZUFDRSxvQkFBQyxlQUFEO0lBQ0UsS0FBSyxFQUFFO01BQ0xDLFdBQVcsRUFBRUMsQ0FBQyxJQUFJO1FBQ2hCQyxNQUFNLENBQUNELENBQUQsQ0FBTixDQUFVRSxPQUFWLENBQWtCO1VBQUM0RCxhQUFhLEVBQUU7UUFBaEIsQ0FBbEI7UUFDQSxPQUFPLEVBQVA7TUFDRCxDQUpJO01BS0wzRCxlQUFlLEVBQUVILENBQUMsSUFBSTtRQUNwQkMsTUFBTSxDQUFDRCxDQUFELENBQU4sQ0FBVUUsT0FBVixDQUFrQnlELFNBQWxCO1FBQ0EsT0FBTyxLQUFQO01BQ0QsQ0FSSTtNQVNMdkQsY0FBYyxFQUFFLE1BQU07SUFUakI7RUFEVCxnQkFhRSxvQkFBQyxNQUFELE9BYkYsQ0FERjtBQWlCRCxDQXhCRyxDQUFKO0FBMEJBWCxJQUFJLENBQUMsc0JBQUQsRUFBeUIsTUFBTTtFQUNqQyxNQUFNc0UsWUFBWSxHQUFHLElBQUFDLG1CQUFBLEVBQWE7SUFDaENDLE1BQU0sRUFBTkEseUJBRGdDO0lBRWhDQyxlQUFlLEVBQWZBLGtDQUZnQztJQUdoQzdELE9BQU8sRUFBRThELFVBQVUsSUFBSXhELEtBQUssSUFBSTtNQUM5QlYsTUFBTSxDQUFDVSxLQUFLLENBQUNpQyxHQUFQLENBQU4sQ0FBa0JuQyxJQUFsQixDQUF1QixLQUF2QjtNQUNBLG9CQUFPLCtDQUFQO0lBQ0Q7RUFOK0IsQ0FBYixDQUFyQjtFQVFBLE1BQU1iLE1BQU0sR0FBR21FLFlBQVksQ0FBdUIsS0FBdkIsRUFBOEI7SUFDdkRwRSxLQUFLLEVBQUU7RUFEZ0QsQ0FBOUIsQ0FBM0I7O0VBR0FOLGVBQUEsQ0FBT1MsS0FBUCxlQUNFLG9CQUFDLGVBQUQ7SUFDRSxLQUFLLEVBQUU7TUFDTEMsV0FBVyxFQUFFLE1BQU0sRUFEZDtNQUVMSSxlQUFlLEVBQUUsTUFBTSxFQUZsQjtNQUdMQyxjQUFjLEVBQUUsTUFBTTtJQUhqQjtFQURULGdCQU9FLG9CQUFDLE1BQUQ7SUFBUSxHQUFHLEVBQUM7RUFBWixFQVBGLENBREY7QUFXRCxDQXZCRyxDQUFKO0FBeUJBWCxJQUFJLENBQUMsa0JBQUQsRUFBcUIsTUFBTTtFQUM3QixTQUFTMkUsSUFBVCxHQUFnQjtJQUNkLE1BQU0sQ0FBQ0MsR0FBRCxJQUFRLElBQUFDLG1CQUFBLEdBQWQ7SUFDQSxNQUFNN0MsU0FBUyxHQUFHNEMsR0FBRyxDQUFDO01BQUMxRSxLQUFLLEVBQUU7SUFBUixDQUFELENBQXJCO0lBQ0FNLE1BQU0sQ0FBQ3dCLFNBQUQsQ0FBTixDQUFrQmhCLElBQWxCLENBQXVCLE1BQXZCO0lBQ0Esb0JBQU87TUFBRyxTQUFTLEVBQUVnQjtJQUFkLFNBQVA7RUFDRDs7RUFFRHBDLGVBQUEsQ0FBT1MsS0FBUCxlQUNFLG9CQUFDLGVBQUQ7SUFDRSxLQUFLLEVBQUU7TUFDTEMsV0FBVyxFQUFFQyxDQUFDLElBQUk7UUFDaEJDLE1BQU0sQ0FBQ0QsQ0FBRCxDQUFOLENBQVVFLE9BQVYsQ0FBa0I7VUFDaEJQLEtBQUssRUFBRTtRQURTLENBQWxCO1FBR0EsT0FBTyxNQUFQO01BQ0QsQ0FOSTtNQU9MUSxlQUFlLEVBQUUsTUFBTSxFQVBsQjtNQVFMQyxjQUFjLEVBQUUsTUFBTTtJQVJqQjtFQURULGdCQVlFLG9CQUFDLElBQUQsT0FaRixDQURGO0FBZ0JELENBeEJHLENBQUo7QUEwQkFYLElBQUksQ0FBQyx5QkFBRCxFQUE0QixNQUFNO0VBQ3BDLFNBQVNHLE1BQVQsR0FBa0I7SUFDaEIsTUFBTSxDQUFDeUUsR0FBRCxJQUFRLElBQUFDLG1CQUFBLEdBQWQ7SUFDQSxNQUFNLENBQUNDLEVBQUQsRUFBS0MsS0FBTCxJQUFjN0MsS0FBSyxDQUFDOEMsUUFBTixDQUFlLEtBQWYsQ0FBcEI7SUFDQSxNQUFNaEQsU0FBUyxHQUFHNEMsR0FBRyxDQUFDO01BQUMxRSxLQUFLLEVBQUU7SUFBUixDQUFELENBQXJCO0lBQ0Esb0JBQ0U7TUFBUSxPQUFPLEVBQUUsTUFBTTZFLEtBQUssQ0FBQyxDQUFDRCxFQUFGLENBQTVCO01BQW1DLFNBQVMsRUFBRTlDO0lBQTlDLFVBREY7RUFLRDs7RUFFRCxJQUFJdUIsY0FBYyxHQUFHLENBQXJCOztFQUNBLE1BQU0zQyxPQUFPLEdBQUdoQixlQUFBLENBQU9TLEtBQVAsZUFDZCxvQkFBQyxlQUFEO0lBQ0UsS0FBSyxFQUFFO01BQ0xDLFdBQVcsRUFBRSxNQUFNLEtBRGQ7TUFFTEksZUFBZSxFQUFFLE1BQU0sRUFGbEI7TUFHTEMsY0FBYyxFQUFFLE1BQU07SUFIakIsQ0FEVDtJQU1FLEtBQUssRUFBRTtNQUNMNkMsS0FBSyxFQUFFLE1BQU07UUFDWEQsY0FBYztRQUNkLE9BQVEsV0FBVUEsY0FBZSxFQUFqQztNQUNEO0lBSkk7RUFOVCxnQkFhRSxvQkFBQyxNQUFELE9BYkYsQ0FEYyxDQUFoQjs7RUFrQkEsTUFBTTBCLE1BQU0sR0FBR3JFLE9BQU8sQ0FBQ0UsSUFBUixDQUFhLFFBQWIsQ0FBZjtFQUNBTixNQUFNLENBQUN5RSxNQUFNLENBQUNoRSxRQUFQLENBQWdCLGVBQWhCLENBQUQsQ0FBTixDQUF5Q0QsSUFBekMsQ0FBOEMsSUFBOUM7RUFDQWlFLE1BQU0sQ0FBQ0MsUUFBUCxDQUFnQixPQUFoQjtFQUNBMUUsTUFBTSxDQUFDeUUsTUFBTSxDQUFDaEUsUUFBUCxDQUFnQixlQUFoQixDQUFELENBQU4sQ0FBeUNELElBQXpDLENBQThDLElBQTlDO0VBQ0FSLE1BQU0sQ0FBQytDLGNBQUQsQ0FBTixDQUF1QnZDLElBQXZCLENBQTRCLENBQTVCO0FBQ0QsQ0FwQ0csQ0FBSjtBQXNDQWhCLElBQUksQ0FBQyxjQUFELEVBQWlCLE1BQU07RUFDekIsTUFBTW1GLFdBQVcsR0FBR0MsT0FBTyxDQUFDQyxJQUE1QixDQUR5QixDQUNTOztFQUVqQ0QsT0FBRCxDQUFpQkMsSUFBakIsR0FBd0J6QixPQUFPLElBQUk7SUFDakNwRCxNQUFNLENBQUNvRCxPQUFPLENBQUMwQixLQUFSLENBQWMsSUFBZCxFQUFvQixDQUFwQixDQUFELENBQU4sQ0FBK0J0RSxJQUEvQixDQUNFLHFEQURGO0VBR0QsQ0FKRDs7RUFLQSxNQUFNYixNQUFNLEdBQUcsSUFBQUMsYUFBQSxFQUFPLEtBQVAsRUFBYztJQUMzQkYsS0FBSyxFQUFFO0VBRG9CLENBQWQsQ0FBZjs7RUFHQU4sZUFBQSxDQUFPUyxLQUFQLGVBQWEsb0JBQUMsTUFBRCxPQUFiOztFQUVDK0UsT0FBRCxDQUFpQkMsSUFBakIsR0FBd0JGLFdBQXhCO0FBQ0QsQ0FkRyxDQUFKIn0=