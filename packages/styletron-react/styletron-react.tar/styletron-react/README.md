# styletron-react

[![npm version][npm-badge]][npm-href] [![dependencies status][deps-badge]][deps-href]

React bindings for Styletron.

## Installation

```
yarn add styletron-react
```

## [Documentation](https://www.styletron.org/react/)

## [API](https://www.styletron.org/api-reference#styletron-react)

[deps-badge]: https://david-dm.org/rtsao/styletron-react.svg
[deps-href]: https://david-dm.org/rtsao/styletron-react
[npm-badge]: https://badge.fury.io/js/styletron-react.svg
[npm-href]: https://www.npmjs.com/package/styletron-react
