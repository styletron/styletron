import Enzyme from "enzyme";
import Adapter from "enzyme-adapter-react-16";
import * as React from "react";
import { styled, createStyled, withWrapper, withStyle, withTransform, Provider, useStyletron } from "../index";
import { getInitialStyle, driver } from "styletron-standard";
Enzyme.configure({
  adapter: new Adapter()
});
test("styled (static)", () => {
  const style = {
    color: "red"
  };
  const Widget = styled("div", style);
  Enzyme.mount( /*#__PURE__*/React.createElement(Provider, {
    value: {
      renderStyle: x => {
        expect(x).toEqual(style);
        return "";
      },
      renderKeyframes: () => "",
      renderFontFace: () => ""
    }
  }, /*#__PURE__*/React.createElement(Widget, null)));
  const wrapper = Enzyme.mount( /*#__PURE__*/React.createElement(Provider, {
    value: {
      renderStyle: () => "bar",
      renderKeyframes: () => "",
      renderFontFace: () => ""
    }
  }, /*#__PURE__*/React.createElement(Widget, {
    className: "foo"
  })));
  const divs = wrapper.find("div");
  expect(divs.length).toBe(1);
  expect(divs.hasClass("foo bar")).toBe(true);
});
test("styled (dynamic)", () => {
  const Widget = styled("div", props => ({
    color: props.$foo ? "red" : "blue"
  }));
  Enzyme.mount( /*#__PURE__*/React.createElement(Provider, {
    value: {
      renderStyle: x => {
        expect(x).toEqual({
          color: "red"
        });
        return "";
      },
      renderKeyframes: () => "",
      renderFontFace: () => ""
    }
  }, /*#__PURE__*/React.createElement(Widget, {
    $foo: true
  })));
});
test("withStyle (static)", () => {
  const Widget = styled("div", {
    borderWidth: 0,
    color: "red",
    ":hover": {
      fontSize: "12px"
    }
  });
  const SuperWidget = withStyle(Widget, {
    color: "blue",
    ":hover": {
      borderWidth: "10px"
    }
  });
  Enzyme.mount( /*#__PURE__*/React.createElement(Provider, {
    value: {
      renderStyle: x => {
        expect(x).toEqual({
          borderWidth: 0,
          color: "blue",
          ":hover": {
            fontSize: "12px",
            borderWidth: "10px"
          }
        });
        return "";
      },
      renderKeyframes: () => "",
      renderFontFace: () => ""
    }
  }, /*#__PURE__*/React.createElement(SuperWidget, null)));
});
test("withStyle (dynamic)", () => {
  const Widget = styled("div", {
    lineHeight: 1,
    color: "red",
    ":hover": {
      fontSize: "12px"
    }
  });
  const SuperWidget = withStyle(Widget, props => ({
    background: props.$round ? "yellow" : "green",
    ":hover": {
      borderWidth: 0
    }
  }));
  Enzyme.mount( /*#__PURE__*/React.createElement(Provider, {
    value: {
      renderStyle: x => {
        expect(x).toEqual({
          color: "red",
          background: "yellow",
          lineHeight: 1,
          ":hover": {
            borderWidth: 0,
            fontSize: "12px"
          }
        });
        return "";
      },
      renderKeyframes: () => "",
      renderFontFace: () => ""
    }
  }, /*#__PURE__*/React.createElement(SuperWidget, {
    $round: true
  })));
});
test("$style prop (static)", () => {
  const Widget = styled("div", {
    lineHeight: 1,
    color: "red",
    ":hover": {
      fontSize: "12px"
    }
  });
  Enzyme.mount( /*#__PURE__*/React.createElement(Provider, {
    value: {
      renderStyle: x => {
        expect(x).toEqual({
          color: "blue",
          lineHeight: 1,
          ":hover": {
            fontSize: "12px"
          }
        });
        return "";
      },
      renderKeyframes: () => "",
      renderFontFace: () => ""
    }
  }, /*#__PURE__*/React.createElement(Widget, {
    $style: {
      color: "blue"
    }
  })));
});
test("$style prop (dynamic)", () => {
  const Widget = styled("div", {
    lineHeight: 1,
    color: "red",
    ":hover": {
      fontSize: "12px"
    }
  });
  Enzyme.mount( /*#__PURE__*/React.createElement(Provider, {
    value: {
      renderStyle: x => {
        expect(x).toEqual({
          color: "blue",
          background: "yellow",
          lineHeight: 1,
          ":hover": {
            fontSize: "12px",
            borderWidth: 0
          }
        });
        return "";
      },
      renderKeyframes: () => "",
      renderFontFace: () => ""
    }
  }, /*#__PURE__*/React.createElement(Widget, {
    $style: props => ({
      color: "blue",
      background: props.$round ? "yellow" : "green",
      ":hover": {
        borderWidth: 0
      }
    }),
    $round: true
  })));
});
test("$style overrides nested withStyle", () => {
  const Widget = styled("div", {
    color: "red",
    fontSize: "12px"
  });
  const WidgetColor = withStyle(Widget, {
    color: "blue"
  });
  const WidgetFontSize = withStyle(WidgetColor, {
    fontSize: "14px"
  });
  Enzyme.mount( /*#__PURE__*/React.createElement(Provider, {
    value: {
      renderStyle: x => {
        expect(x).toEqual({
          color: "yellow",
          fontSize: "14px",
          padding: "10px"
        });
        return "";
      },
      renderKeyframes: () => "",
      renderFontFace: () => ""
    }
  }, /*#__PURE__*/React.createElement(WidgetFontSize, {
    $style: {
      color: "yellow",
      padding: "10px"
    }
  })));
});
test("withTransform", () => {
  const Widget = styled("div", {
    color: "red",
    background: "green"
  });
  const SuperWidget = withTransform(Widget, (style, props) => ({ ...style,
    background: props.$round ? "yellow" : "green"
  }));
  Enzyme.mount( /*#__PURE__*/React.createElement(Provider, {
    value: {
      renderStyle: x => {
        expect(x).toEqual({
          color: "red",
          background: "yellow"
        });
        return "";
      },
      renderFontFace: () => {
        return "";
      },
      renderKeyframes: () => {
        return "";
      }
    }
  }, /*#__PURE__*/React.createElement(SuperWidget, {
    $round: true
  })));
});
test("$as works", () => {
  const Widget = styled("div", {});

  const MockComponent = props => {
    expect(props.className).toBe("foo");
    return /*#__PURE__*/React.createElement("div", null);
  };

  Enzyme.mount( /*#__PURE__*/React.createElement(Provider, {
    value: {
      renderStyle: () => "foo",
      renderKeyframes: () => "",
      renderFontFace: () => ""
    }
  }, /*#__PURE__*/React.createElement(Widget, {
    $as: MockComponent
  })));
  const wrapper = Enzyme.mount( /*#__PURE__*/React.createElement(Provider, {
    value: {
      renderStyle: () => "",
      renderKeyframes: () => "",
      renderFontFace: () => ""
    }
  }, /*#__PURE__*/React.createElement(Widget, {
    $as: "span"
  })));
  expect(wrapper.find("span").length).toBe(1);
});
test("$-prefixed props not passed", () => {
  class InnerComponent extends React.Component {
    render() {
      expect(this.props).toEqual({
        className: "styleclass",
        "data-bar": "bar"
      });
      return /*#__PURE__*/React.createElement("button", null, "InnerComponent");
    }

  }

  const Widget = styled(InnerComponent, {
    color: "red"
  });
  Enzyme.mount( /*#__PURE__*/React.createElement(Provider, {
    value: {
      renderStyle: () => "styleclass",
      renderKeyframes: () => "",
      renderFontFace: () => ""
    }
  }, /*#__PURE__*/React.createElement(Widget, {
    $foo: "foo",
    $baz: "baz",
    "data-bar": "bar"
  })));
});
test("callback ref forwarding", () => {
  const Widget = styled("button", {
    color: "red"
  });

  class TestComponent extends React.Component {
    componentDidMount() {
      expect(this.widgetInner instanceof HTMLButtonElement).toBe(true);
    }

    render() {
      return /*#__PURE__*/React.createElement(Provider, {
        value: {
          renderStyle: () => "",
          renderKeyframes: () => "",
          renderFontFace: () => ""
        }
      }, /*#__PURE__*/React.createElement(Widget, {
        ref: c => {
          this.widgetInner = c;
        }
      }));
    }

  }

  Enzyme.mount( /*#__PURE__*/React.createElement(TestComponent, null));
});
test("React.createRef() ref forwarding", () => {
  const Widget = styled("button", {
    color: "red"
  });

  class TestComponent extends React.Component {
    widgetInner = /*#__PURE__*/React.createRef();

    componentDidMount() {
      expect(this.widgetInner.current instanceof HTMLButtonElement).toBe(true);
    }

    render() {
      return /*#__PURE__*/React.createElement(Provider, {
        value: {
          renderStyle: () => "",
          renderKeyframes: () => "",
          renderFontFace: () => ""
        }
      }, /*#__PURE__*/React.createElement(Widget, {
        ref: this.widgetInner
      }));
    }

  }

  Enzyme.mount( /*#__PURE__*/React.createElement(TestComponent, null));
});
test("React.useRef() ref forwarding", () => {
  const Widget = styled("button", {
    color: "red"
  });

  const TestComponent = () => {
    const widgetInner = React.useRef(null);
    React.useEffect(() => {
      expect(widgetInner.current instanceof HTMLButtonElement).toBe(true);
    }, []);
    return /*#__PURE__*/React.createElement(Provider, {
      value: {
        renderStyle: () => "",
        renderKeyframes: () => "",
        renderFontFace: () => ""
      }
    }, /*#__PURE__*/React.createElement(Widget, {
      ref: widgetInner
    }));
  };

  Enzyme.mount( /*#__PURE__*/React.createElement(TestComponent, null));
});
test("legacy string ref forwarding", () => {
  const Widget = styled("button", {
    color: "red"
  });

  class TestComponent extends React.Component {
    componentDidMount() {
      expect(this.refs.myButton instanceof HTMLButtonElement).toBe(true);
    }

    render() {
      return /*#__PURE__*/React.createElement(Provider, {
        value: {
          renderStyle: () => "",
          renderKeyframes: () => "",
          renderFontFace: () => ""
        }
      }, /*#__PURE__*/React.createElement(Widget, {
        ref: "myButton"
      }));
    }

  }

  Enzyme.mount( /*#__PURE__*/React.createElement(TestComponent, null));
});
test("withWrapper", () => {
  const Widget = styled("button", {
    color: "red"
  });
  const WrappedWidget = withWrapper(Widget, StyledElement => props => {
    expect(props).toEqual({
      foo: "bar"
    });
    return /*#__PURE__*/React.createElement("section", null, /*#__PURE__*/React.createElement(StyledElement, props));
  });
  const wrapper1 = Enzyme.mount( /*#__PURE__*/React.createElement(Provider, {
    value: {
      renderStyle: style => {
        expect(style).toEqual({
          color: "red"
        });
        return "";
      },
      renderKeyframes: () => "",
      renderFontFace: () => ""
    }
  }, /*#__PURE__*/React.createElement(WrappedWidget, {
    foo: "bar"
  })));
  expect(wrapper1.find("section").length).toBe(1);
  const DeluxeWrappedWidget = withStyle(WrappedWidget, {
    color: "blue"
  });
  const wrapper2 = Enzyme.mount( /*#__PURE__*/React.createElement(Provider, {
    value: {
      renderStyle: style => {
        expect(style).toEqual({
          color: "blue"
        });
        return "";
      },
      renderKeyframes: () => "",
      renderFontFace: () => ""
    }
  }, /*#__PURE__*/React.createElement(DeluxeWrappedWidget, {
    foo: "bar"
  })));
  expect(wrapper2.find("section").length).toBe(1);
});
test("styled debug mode (client only)", () => {
  let debugCallCount = 0;
  const style = {
    color: "red"
  };
  const Widget = styled("div", style);
  const wrapper = Enzyme.mount( /*#__PURE__*/React.createElement(Provider, {
    value: {
      renderStyle: () => "bar",
      renderKeyframes: () => "",
      renderFontFace: () => ""
    },
    debug: {
      debug: ({
        stackIndex,
        stackInfo
      }) => {
        debugCallCount++;
        expect(stackIndex).toBe(2);
        expect(typeof stackInfo).toBe("object");
        expect(typeof stackInfo.stack).toBe("string");
        expect(typeof stackInfo.message).toBe("string");
        return "__arbitrary_debug_class__";
      }
    }
  }, /*#__PURE__*/React.createElement(Widget, {
    className: "foo"
  })));
  const divs = wrapper.find("div");
  expect(divs.length).toBe(1);
  expect(divs.hasClass("__arbitrary_debug_class__ foo bar")).toBe(true);
  wrapper.unmount();
  wrapper.mount();
  wrapper.unmount();
  expect(debugCallCount).toBe(1);
});
test("styled debug mode (ssr)", () => {
  const style = {
    color: "red"
  };
  let count = 0;
  const Widget = styled("div", style);
  const wrapper = Enzyme.mount( /*#__PURE__*/React.createElement(Provider, {
    value: {
      renderStyle: () => {
        count++;
        return "foo";
      },
      renderKeyframes: () => "",
      renderFontFace: () => ""
    },
    debug: {
      debug: () => {
        expect(count).toBe(2);
        return "__some_debug_class";
      }
    },
    debugAfterHydration: true
  }, /*#__PURE__*/React.createElement(Widget, null)));
  const divs = wrapper.find("div");
  expect(count).toBe(2);
  expect(divs.hasClass("__some_debug_class foo")).toBe(true);
});
test("font-face injection", () => {
  const fontFace = {
    src: "foo"
  };
  const style = {
    fontFamily: fontFace
  };
  const Widget = styled("div", style);
  Enzyme.mount( /*#__PURE__*/React.createElement(Provider, {
    value: {
      renderStyle: x => {
        expect(x).toEqual({
          fontFamily: "foo"
        });
        return "";
      },
      renderFontFace: x => {
        expect(x).toEqual(fontFace);
        return "foo";
      },
      renderKeyframes: () => ""
    }
  }, /*#__PURE__*/React.createElement(Widget, null)));
});
test("keyframes injection", () => {
  const keyframes = {
    from: {
      color: "red"
    },
    to: {
      color: "green"
    }
  };
  const style = {
    animationName: keyframes
  };
  const Widget = styled("div", style);
  Enzyme.mount( /*#__PURE__*/React.createElement(Provider, {
    value: {
      renderStyle: x => {
        expect(x).toEqual({
          animationName: "foo"
        });
        return "";
      },
      renderKeyframes: x => {
        expect(x).toEqual(keyframes);
        return "foo";
      },
      renderFontFace: () => ""
    }
  }, /*#__PURE__*/React.createElement(Widget, null)));
});
test("createStyled wrapper", () => {
  const customStyled = createStyled({
    driver,
    getInitialStyle,
    wrapper: _Component => props => {
      expect(props.foo).toBe("foo");
      return /*#__PURE__*/React.createElement("div", null, "hello world");
    }
  });
  const Widget = customStyled("div", {
    color: "red"
  });
  Enzyme.mount( /*#__PURE__*/React.createElement(Provider, {
    value: {
      renderStyle: () => "",
      renderKeyframes: () => "",
      renderFontFace: () => ""
    }
  }, /*#__PURE__*/React.createElement(Widget, {
    foo: "foo"
  })));
});
test("useStyletron css", () => {
  function Link() {
    const [css] = useStyletron();
    const className = css({
      color: "blue"
    });
    expect(className).toBe(".abc");
    return /*#__PURE__*/React.createElement("a", {
      className: className
    }, "Foo");
  }

  Enzyme.mount( /*#__PURE__*/React.createElement(Provider, {
    value: {
      renderStyle: x => {
        expect(x).toEqual({
          color: "blue"
        });
        return ".abc";
      },
      renderKeyframes: () => "",
      renderFontFace: () => ""
    }
  }, /*#__PURE__*/React.createElement(Link, null)));
});
test("useStyletron debug mode", () => {
  function Widget() {
    const [css] = useStyletron();
    const [on, setOn] = React.useState(false);
    const className = css({
      color: "red"
    });
    return /*#__PURE__*/React.createElement("button", {
      onClick: () => setOn(!on),
      className: className
    }, "test");
  }

  let debugCallCount = 0;
  const wrapper = Enzyme.mount( /*#__PURE__*/React.createElement(Provider, {
    value: {
      renderStyle: () => "bar",
      renderKeyframes: () => "",
      renderFontFace: () => ""
    },
    debug: {
      debug: () => {
        debugCallCount++;
        return `__debug-${debugCallCount}`;
      }
    }
  }, /*#__PURE__*/React.createElement(Widget, null)));
  const button = wrapper.find("button");
  expect(button.hasClass("__debug-1 bar")).toBe(true);
  button.simulate("click");
  expect(button.hasClass("__debug-1 bar")).toBe(true);
  expect(debugCallCount).toBe(1);
});
test("no-op engine", () => {
  const consoleWarn = console.warn; // eslint-disable-line

  console.warn = message => {
    expect(message.split("\n")[1]).toBe("Styletron has been switched to a no-op (test) mode.");
  };

  const Widget = styled("div", {
    color: "red"
  });
  Enzyme.mount( /*#__PURE__*/React.createElement(Widget, null));
  console.warn = consoleWarn;
});
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJFbnp5bWUiLCJBZGFwdGVyIiwiUmVhY3QiLCJzdHlsZWQiLCJjcmVhdGVTdHlsZWQiLCJ3aXRoV3JhcHBlciIsIndpdGhTdHlsZSIsIndpdGhUcmFuc2Zvcm0iLCJQcm92aWRlciIsInVzZVN0eWxldHJvbiIsImdldEluaXRpYWxTdHlsZSIsImRyaXZlciIsImNvbmZpZ3VyZSIsImFkYXB0ZXIiLCJ0ZXN0Iiwic3R5bGUiLCJjb2xvciIsIldpZGdldCIsIm1vdW50IiwicmVuZGVyU3R5bGUiLCJ4IiwiZXhwZWN0IiwidG9FcXVhbCIsInJlbmRlcktleWZyYW1lcyIsInJlbmRlckZvbnRGYWNlIiwid3JhcHBlciIsImRpdnMiLCJmaW5kIiwibGVuZ3RoIiwidG9CZSIsImhhc0NsYXNzIiwicHJvcHMiLCIkZm9vIiwiYm9yZGVyV2lkdGgiLCJmb250U2l6ZSIsIlN1cGVyV2lkZ2V0IiwibGluZUhlaWdodCIsImJhY2tncm91bmQiLCIkcm91bmQiLCJXaWRnZXRDb2xvciIsIldpZGdldEZvbnRTaXplIiwicGFkZGluZyIsIk1vY2tDb21wb25lbnQiLCJjbGFzc05hbWUiLCJJbm5lckNvbXBvbmVudCIsIkNvbXBvbmVudCIsInJlbmRlciIsIlRlc3RDb21wb25lbnQiLCJjb21wb25lbnREaWRNb3VudCIsIndpZGdldElubmVyIiwiSFRNTEJ1dHRvbkVsZW1lbnQiLCJjIiwiY3JlYXRlUmVmIiwiY3VycmVudCIsInVzZVJlZiIsInVzZUVmZmVjdCIsInJlZnMiLCJteUJ1dHRvbiIsIldyYXBwZWRXaWRnZXQiLCJTdHlsZWRFbGVtZW50IiwiZm9vIiwid3JhcHBlcjEiLCJEZWx1eGVXcmFwcGVkV2lkZ2V0Iiwid3JhcHBlcjIiLCJkZWJ1Z0NhbGxDb3VudCIsImRlYnVnIiwic3RhY2tJbmRleCIsInN0YWNrSW5mbyIsInN0YWNrIiwibWVzc2FnZSIsInVubW91bnQiLCJjb3VudCIsImZvbnRGYWNlIiwic3JjIiwiZm9udEZhbWlseSIsImtleWZyYW1lcyIsImZyb20iLCJ0byIsImFuaW1hdGlvbk5hbWUiLCJjdXN0b21TdHlsZWQiLCJfQ29tcG9uZW50IiwiTGluayIsImNzcyIsIm9uIiwic2V0T24iLCJ1c2VTdGF0ZSIsImJ1dHRvbiIsInNpbXVsYXRlIiwiY29uc29sZVdhcm4iLCJjb25zb2xlIiwid2FybiIsInNwbGl0Il0sInNvdXJjZXMiOlsic3JjL19fdGVzdHNfXy90ZXN0cy5icm93c2VyLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgRW56eW1lIGZyb20gXCJlbnp5bWVcIjtcbmltcG9ydCBBZGFwdGVyIGZyb20gXCJlbnp5bWUtYWRhcHRlci1yZWFjdC0xNlwiO1xuaW1wb3J0ICogYXMgUmVhY3QgZnJvbSBcInJlYWN0XCI7XG5cbmltcG9ydCB7XG4gIHN0eWxlZCxcbiAgY3JlYXRlU3R5bGVkLFxuICB3aXRoV3JhcHBlcixcbiAgd2l0aFN0eWxlLFxuICB3aXRoVHJhbnNmb3JtLFxuICBQcm92aWRlcixcbiAgdXNlU3R5bGV0cm9uLFxufSBmcm9tIFwiLi4vaW5kZXhcIjtcblxuaW1wb3J0IHtnZXRJbml0aWFsU3R5bGUsIGRyaXZlcn0gZnJvbSBcInN0eWxldHJvbi1zdGFuZGFyZFwiO1xuaW1wb3J0IHR5cGUge1N0eWxlT2JqZWN0fSBmcm9tIFwic3R5bGV0cm9uLXN0YW5kYXJkXCI7XG5cbkVuenltZS5jb25maWd1cmUoe2FkYXB0ZXI6IG5ldyBBZGFwdGVyKCl9KTtcblxudGVzdChcInN0eWxlZCAoc3RhdGljKVwiLCAoKSA9PiB7XG4gIGNvbnN0IHN0eWxlID0ge2NvbG9yOiBcInJlZFwifTtcbiAgY29uc3QgV2lkZ2V0ID0gc3R5bGVkKFwiZGl2XCIsIHN0eWxlKTtcbiAgRW56eW1lLm1vdW50KFxuICAgIDxQcm92aWRlclxuICAgICAgdmFsdWU9e3tcbiAgICAgICAgcmVuZGVyU3R5bGU6IHggPT4ge1xuICAgICAgICAgIGV4cGVjdCh4KS50b0VxdWFsKHN0eWxlKTtcbiAgICAgICAgICByZXR1cm4gXCJcIjtcbiAgICAgICAgfSxcbiAgICAgICAgcmVuZGVyS2V5ZnJhbWVzOiAoKSA9PiBcIlwiLFxuICAgICAgICByZW5kZXJGb250RmFjZTogKCkgPT4gXCJcIixcbiAgICAgIH19XG4gICAgPlxuICAgICAgPFdpZGdldCAvPlxuICAgIDwvUHJvdmlkZXI+LFxuICApO1xuICBjb25zdCB3cmFwcGVyID0gRW56eW1lLm1vdW50KFxuICAgIDxQcm92aWRlclxuICAgICAgdmFsdWU9e3tcbiAgICAgICAgcmVuZGVyU3R5bGU6ICgpID0+IFwiYmFyXCIsXG4gICAgICAgIHJlbmRlcktleWZyYW1lczogKCkgPT4gXCJcIixcbiAgICAgICAgcmVuZGVyRm9udEZhY2U6ICgpID0+IFwiXCIsXG4gICAgICB9fVxuICAgID5cbiAgICAgIDxXaWRnZXQgY2xhc3NOYW1lPVwiZm9vXCIgLz5cbiAgICA8L1Byb3ZpZGVyPixcbiAgKTtcbiAgY29uc3QgZGl2cyA9IHdyYXBwZXIuZmluZChcImRpdlwiKTtcbiAgZXhwZWN0KGRpdnMubGVuZ3RoKS50b0JlKDEpO1xuICBleHBlY3QoZGl2cy5oYXNDbGFzcyhcImZvbyBiYXJcIikpLnRvQmUodHJ1ZSk7XG59KTtcblxudGVzdChcInN0eWxlZCAoZHluYW1pYylcIiwgKCkgPT4ge1xuICBjb25zdCBXaWRnZXQgPSBzdHlsZWQoXCJkaXZcIiwgKHByb3BzOiB7JGZvbzogYm9vbGVhbn0pID0+ICh7XG4gICAgY29sb3I6IHByb3BzLiRmb28gPyBcInJlZFwiIDogXCJibHVlXCIsXG4gIH0pKTtcblxuICBFbnp5bWUubW91bnQoXG4gICAgPFByb3ZpZGVyXG4gICAgICB2YWx1ZT17e1xuICAgICAgICByZW5kZXJTdHlsZTogeCA9PiB7XG4gICAgICAgICAgZXhwZWN0KHgpLnRvRXF1YWwoe2NvbG9yOiBcInJlZFwifSk7XG4gICAgICAgICAgcmV0dXJuIFwiXCI7XG4gICAgICAgIH0sXG4gICAgICAgIHJlbmRlcktleWZyYW1lczogKCkgPT4gXCJcIixcbiAgICAgICAgcmVuZGVyRm9udEZhY2U6ICgpID0+IFwiXCIsXG4gICAgICB9fVxuICAgID5cbiAgICAgIDxXaWRnZXQgJGZvbz17dHJ1ZX0gLz5cbiAgICA8L1Byb3ZpZGVyPixcbiAgKTtcbn0pO1xuXG50ZXN0KFwid2l0aFN0eWxlIChzdGF0aWMpXCIsICgpID0+IHtcbiAgY29uc3QgV2lkZ2V0ID0gc3R5bGVkKFwiZGl2XCIsIHtcbiAgICBib3JkZXJXaWR0aDogMCxcbiAgICBjb2xvcjogXCJyZWRcIixcbiAgICBcIjpob3ZlclwiOiB7Zm9udFNpemU6IFwiMTJweFwifSxcbiAgfSk7XG4gIGNvbnN0IFN1cGVyV2lkZ2V0ID0gd2l0aFN0eWxlKFdpZGdldCwge1xuICAgIGNvbG9yOiBcImJsdWVcIixcbiAgICBcIjpob3ZlclwiOiB7Ym9yZGVyV2lkdGg6IFwiMTBweFwifSxcbiAgfSk7XG4gIEVuenltZS5tb3VudChcbiAgICA8UHJvdmlkZXJcbiAgICAgIHZhbHVlPXt7XG4gICAgICAgIHJlbmRlclN0eWxlOiB4ID0+IHtcbiAgICAgICAgICBleHBlY3QoeCkudG9FcXVhbCh7XG4gICAgICAgICAgICBib3JkZXJXaWR0aDogMCxcbiAgICAgICAgICAgIGNvbG9yOiBcImJsdWVcIixcbiAgICAgICAgICAgIFwiOmhvdmVyXCI6IHtmb250U2l6ZTogXCIxMnB4XCIsIGJvcmRlcldpZHRoOiBcIjEwcHhcIn0sXG4gICAgICAgICAgfSk7XG4gICAgICAgICAgcmV0dXJuIFwiXCI7XG4gICAgICAgIH0sXG4gICAgICAgIHJlbmRlcktleWZyYW1lczogKCkgPT4gXCJcIixcbiAgICAgICAgcmVuZGVyRm9udEZhY2U6ICgpID0+IFwiXCIsXG4gICAgICB9fVxuICAgID5cbiAgICAgIDxTdXBlcldpZGdldCAvPlxuICAgIDwvUHJvdmlkZXI+LFxuICApO1xufSk7XG5cbnRlc3QoXCJ3aXRoU3R5bGUgKGR5bmFtaWMpXCIsICgpID0+IHtcbiAgY29uc3QgV2lkZ2V0ID0gc3R5bGVkKFwiZGl2XCIsIHtcbiAgICBsaW5lSGVpZ2h0OiAxLFxuICAgIGNvbG9yOiBcInJlZFwiLFxuICAgIFwiOmhvdmVyXCI6IHtmb250U2l6ZTogXCIxMnB4XCJ9LFxuICB9KTtcbiAgY29uc3QgU3VwZXJXaWRnZXQgPSB3aXRoU3R5bGU8dHlwZW9mIFdpZGdldCwgeyRyb3VuZDogYm9vbGVhbn0+KFxuICAgIFdpZGdldCxcbiAgICBwcm9wcyA9PiAoe1xuICAgICAgYmFja2dyb3VuZDogcHJvcHMuJHJvdW5kID8gXCJ5ZWxsb3dcIiA6IFwiZ3JlZW5cIixcbiAgICAgIFwiOmhvdmVyXCI6IHtib3JkZXJXaWR0aDogMH0sXG4gICAgfSksXG4gICk7XG4gIEVuenltZS5tb3VudChcbiAgICA8UHJvdmlkZXJcbiAgICAgIHZhbHVlPXt7XG4gICAgICAgIHJlbmRlclN0eWxlOiB4ID0+IHtcbiAgICAgICAgICBleHBlY3QoeCkudG9FcXVhbCh7XG4gICAgICAgICAgICBjb2xvcjogXCJyZWRcIixcbiAgICAgICAgICAgIGJhY2tncm91bmQ6IFwieWVsbG93XCIsXG4gICAgICAgICAgICBsaW5lSGVpZ2h0OiAxLFxuICAgICAgICAgICAgXCI6aG92ZXJcIjoge2JvcmRlcldpZHRoOiAwLCBmb250U2l6ZTogXCIxMnB4XCJ9LFxuICAgICAgICAgIH0pO1xuXG4gICAgICAgICAgcmV0dXJuIFwiXCI7XG4gICAgICAgIH0sXG4gICAgICAgIHJlbmRlcktleWZyYW1lczogKCkgPT4gXCJcIixcbiAgICAgICAgcmVuZGVyRm9udEZhY2U6ICgpID0+IFwiXCIsXG4gICAgICB9fVxuICAgID5cbiAgICAgIDxTdXBlcldpZGdldCAkcm91bmQ9e3RydWV9IC8+XG4gICAgPC9Qcm92aWRlcj4sXG4gICk7XG59KTtcblxudGVzdChcIiRzdHlsZSBwcm9wIChzdGF0aWMpXCIsICgpID0+IHtcbiAgY29uc3QgV2lkZ2V0ID0gc3R5bGVkKFwiZGl2XCIsIHtcbiAgICBsaW5lSGVpZ2h0OiAxLFxuICAgIGNvbG9yOiBcInJlZFwiLFxuICAgIFwiOmhvdmVyXCI6IHtmb250U2l6ZTogXCIxMnB4XCJ9LFxuICB9KTtcblxuICBFbnp5bWUubW91bnQoXG4gICAgPFByb3ZpZGVyXG4gICAgICB2YWx1ZT17e1xuICAgICAgICByZW5kZXJTdHlsZTogeCA9PiB7XG4gICAgICAgICAgZXhwZWN0KHgpLnRvRXF1YWwoe1xuICAgICAgICAgICAgY29sb3I6IFwiYmx1ZVwiLFxuICAgICAgICAgICAgbGluZUhlaWdodDogMSxcbiAgICAgICAgICAgIFwiOmhvdmVyXCI6IHtmb250U2l6ZTogXCIxMnB4XCJ9LFxuICAgICAgICAgIH0pO1xuICAgICAgICAgIHJldHVybiBcIlwiO1xuICAgICAgICB9LFxuICAgICAgICByZW5kZXJLZXlmcmFtZXM6ICgpID0+IFwiXCIsXG4gICAgICAgIHJlbmRlckZvbnRGYWNlOiAoKSA9PiBcIlwiLFxuICAgICAgfX1cbiAgICA+XG4gICAgICA8V2lkZ2V0ICRzdHlsZT17e2NvbG9yOiBcImJsdWVcIn19IC8+XG4gICAgPC9Qcm92aWRlcj4sXG4gICk7XG59KTtcblxudGVzdChcIiRzdHlsZSBwcm9wIChkeW5hbWljKVwiLCAoKSA9PiB7XG4gIGNvbnN0IFdpZGdldCA9IHN0eWxlZDxcImRpdlwiLCB7JHJvdW5kOiBib29sZWFufT4oXCJkaXZcIiwge1xuICAgIGxpbmVIZWlnaHQ6IDEsXG4gICAgY29sb3I6IFwicmVkXCIsXG4gICAgXCI6aG92ZXJcIjoge2ZvbnRTaXplOiBcIjEycHhcIn0sXG4gIH0pO1xuXG4gIEVuenltZS5tb3VudChcbiAgICA8UHJvdmlkZXJcbiAgICAgIHZhbHVlPXt7XG4gICAgICAgIHJlbmRlclN0eWxlOiB4ID0+IHtcbiAgICAgICAgICBleHBlY3QoeCkudG9FcXVhbCh7XG4gICAgICAgICAgICBjb2xvcjogXCJibHVlXCIsXG4gICAgICAgICAgICBiYWNrZ3JvdW5kOiBcInllbGxvd1wiLFxuICAgICAgICAgICAgbGluZUhlaWdodDogMSxcbiAgICAgICAgICAgIFwiOmhvdmVyXCI6IHtmb250U2l6ZTogXCIxMnB4XCIsIGJvcmRlcldpZHRoOiAwfSxcbiAgICAgICAgICB9KTtcbiAgICAgICAgICByZXR1cm4gXCJcIjtcbiAgICAgICAgfSxcbiAgICAgICAgcmVuZGVyS2V5ZnJhbWVzOiAoKSA9PiBcIlwiLFxuICAgICAgICByZW5kZXJGb250RmFjZTogKCkgPT4gXCJcIixcbiAgICAgIH19XG4gICAgPlxuICAgICAgPFdpZGdldFxuICAgICAgICAkc3R5bGU9e3Byb3BzID0+ICh7XG4gICAgICAgICAgY29sb3I6IFwiYmx1ZVwiLFxuICAgICAgICAgIGJhY2tncm91bmQ6IHByb3BzLiRyb3VuZCA/IFwieWVsbG93XCIgOiBcImdyZWVuXCIsXG4gICAgICAgICAgXCI6aG92ZXJcIjoge2JvcmRlcldpZHRoOiAwfSxcbiAgICAgICAgfSl9XG4gICAgICAgICRyb3VuZD17dHJ1ZX1cbiAgICAgIC8+XG4gICAgPC9Qcm92aWRlcj4sXG4gICk7XG59KTtcblxudGVzdChcIiRzdHlsZSBvdmVycmlkZXMgbmVzdGVkIHdpdGhTdHlsZVwiLCAoKSA9PiB7XG4gIGNvbnN0IFdpZGdldCA9IHN0eWxlZChcImRpdlwiLCB7XG4gICAgY29sb3I6IFwicmVkXCIsXG4gICAgZm9udFNpemU6IFwiMTJweFwiLFxuICB9KTtcblxuICBjb25zdCBXaWRnZXRDb2xvciA9IHdpdGhTdHlsZShXaWRnZXQsIHtjb2xvcjogXCJibHVlXCJ9KTtcbiAgY29uc3QgV2lkZ2V0Rm9udFNpemUgPSB3aXRoU3R5bGUoV2lkZ2V0Q29sb3IsIHtmb250U2l6ZTogXCIxNHB4XCJ9KTtcblxuICBFbnp5bWUubW91bnQoXG4gICAgPFByb3ZpZGVyXG4gICAgICB2YWx1ZT17e1xuICAgICAgICByZW5kZXJTdHlsZTogeCA9PiB7XG4gICAgICAgICAgZXhwZWN0KHgpLnRvRXF1YWwoe1xuICAgICAgICAgICAgY29sb3I6IFwieWVsbG93XCIsXG4gICAgICAgICAgICBmb250U2l6ZTogXCIxNHB4XCIsXG4gICAgICAgICAgICBwYWRkaW5nOiBcIjEwcHhcIixcbiAgICAgICAgICB9KTtcbiAgICAgICAgICByZXR1cm4gXCJcIjtcbiAgICAgICAgfSxcbiAgICAgICAgcmVuZGVyS2V5ZnJhbWVzOiAoKSA9PiBcIlwiLFxuICAgICAgICByZW5kZXJGb250RmFjZTogKCkgPT4gXCJcIixcbiAgICAgIH19XG4gICAgPlxuICAgICAgPFdpZGdldEZvbnRTaXplXG4gICAgICAgICRzdHlsZT17e1xuICAgICAgICAgIGNvbG9yOiBcInllbGxvd1wiLFxuICAgICAgICAgIHBhZGRpbmc6IFwiMTBweFwiLFxuICAgICAgICB9fVxuICAgICAgLz5cbiAgICA8L1Byb3ZpZGVyPixcbiAgKTtcbn0pO1xuXG50ZXN0KFwid2l0aFRyYW5zZm9ybVwiLCAoKSA9PiB7XG4gIGNvbnN0IFdpZGdldCA9IHN0eWxlZChcImRpdlwiLCB7Y29sb3I6IFwicmVkXCIsIGJhY2tncm91bmQ6IFwiZ3JlZW5cIn0pO1xuICBjb25zdCBTdXBlcldpZGdldCA9IHdpdGhUcmFuc2Zvcm0oXG4gICAgV2lkZ2V0LFxuICAgIChzdHlsZSwgcHJvcHM6IHskcm91bmQ6IGJvb2xlYW59KSA9PiAoe1xuICAgICAgLi4uc3R5bGUsXG4gICAgICBiYWNrZ3JvdW5kOiBwcm9wcy4kcm91bmQgPyBcInllbGxvd1wiIDogXCJncmVlblwiLFxuICAgIH0pLFxuICApO1xuICBFbnp5bWUubW91bnQoXG4gICAgPFByb3ZpZGVyXG4gICAgICB2YWx1ZT17e1xuICAgICAgICByZW5kZXJTdHlsZTogeCA9PiB7XG4gICAgICAgICAgZXhwZWN0KHgpLnRvRXF1YWwoe2NvbG9yOiBcInJlZFwiLCBiYWNrZ3JvdW5kOiBcInllbGxvd1wifSk7XG4gICAgICAgICAgcmV0dXJuIFwiXCI7XG4gICAgICAgIH0sXG4gICAgICAgIHJlbmRlckZvbnRGYWNlOiAoKSA9PiB7XG4gICAgICAgICAgcmV0dXJuIFwiXCI7XG4gICAgICAgIH0sXG4gICAgICAgIHJlbmRlcktleWZyYW1lczogKCkgPT4ge1xuICAgICAgICAgIHJldHVybiBcIlwiO1xuICAgICAgICB9LFxuICAgICAgfX1cbiAgICA+XG4gICAgICA8U3VwZXJXaWRnZXQgJHJvdW5kPXt0cnVlfSAvPlxuICAgIDwvUHJvdmlkZXI+LFxuICApO1xufSk7XG5cbnRlc3QoXCIkYXMgd29ya3NcIiwgKCkgPT4ge1xuICBjb25zdCBXaWRnZXQgPSBzdHlsZWQoXCJkaXZcIiwge30pO1xuICBjb25zdCBNb2NrQ29tcG9uZW50ID0gcHJvcHMgPT4ge1xuICAgIGV4cGVjdChwcm9wcy5jbGFzc05hbWUpLnRvQmUoXCJmb29cIik7XG4gICAgcmV0dXJuIDxkaXYgLz47XG4gIH07XG4gIEVuenltZS5tb3VudChcbiAgICA8UHJvdmlkZXJcbiAgICAgIHZhbHVlPXt7XG4gICAgICAgIHJlbmRlclN0eWxlOiAoKSA9PiBcImZvb1wiLFxuICAgICAgICByZW5kZXJLZXlmcmFtZXM6ICgpID0+IFwiXCIsXG4gICAgICAgIHJlbmRlckZvbnRGYWNlOiAoKSA9PiBcIlwiLFxuICAgICAgfX1cbiAgICA+XG4gICAgICA8V2lkZ2V0ICRhcz17TW9ja0NvbXBvbmVudH0gLz5cbiAgICA8L1Byb3ZpZGVyPixcbiAgKTtcbiAgY29uc3Qgd3JhcHBlciA9IEVuenltZS5tb3VudChcbiAgICA8UHJvdmlkZXJcbiAgICAgIHZhbHVlPXt7XG4gICAgICAgIHJlbmRlclN0eWxlOiAoKSA9PiBcIlwiLFxuICAgICAgICByZW5kZXJLZXlmcmFtZXM6ICgpID0+IFwiXCIsXG4gICAgICAgIHJlbmRlckZvbnRGYWNlOiAoKSA9PiBcIlwiLFxuICAgICAgfX1cbiAgICA+XG4gICAgICA8V2lkZ2V0ICRhcz1cInNwYW5cIiAvPlxuICAgIDwvUHJvdmlkZXI+LFxuICApO1xuICBleHBlY3Qod3JhcHBlci5maW5kKFwic3BhblwiKS5sZW5ndGgpLnRvQmUoMSk7XG59KTtcblxudGVzdChcIiQtcHJlZml4ZWQgcHJvcHMgbm90IHBhc3NlZFwiLCAoKSA9PiB7XG4gIGNsYXNzIElubmVyQ29tcG9uZW50IGV4dGVuZHMgUmVhY3QuQ29tcG9uZW50PHtcbiAgICBjbGFzc05hbWU/OiBzdHJpbmc7XG4gIH0+IHtcbiAgICByZW5kZXIoKSB7XG4gICAgICBleHBlY3QodGhpcy5wcm9wcykudG9FcXVhbCh7XG4gICAgICAgIGNsYXNzTmFtZTogXCJzdHlsZWNsYXNzXCIsXG4gICAgICAgIFwiZGF0YS1iYXJcIjogXCJiYXJcIixcbiAgICAgIH0pO1xuICAgICAgcmV0dXJuIDxidXR0b24+SW5uZXJDb21wb25lbnQ8L2J1dHRvbj47XG4gICAgfVxuICB9XG5cbiAgY29uc3QgV2lkZ2V0ID0gc3R5bGVkPHR5cGVvZiBJbm5lckNvbXBvbmVudCwgeyRmb286IGFueTsgJGJhejogYW55fT4oXG4gICAgSW5uZXJDb21wb25lbnQsXG4gICAge2NvbG9yOiBcInJlZFwifSxcbiAgKTtcblxuICBFbnp5bWUubW91bnQoXG4gICAgPFByb3ZpZGVyXG4gICAgICB2YWx1ZT17e1xuICAgICAgICByZW5kZXJTdHlsZTogKCkgPT4gXCJzdHlsZWNsYXNzXCIsXG4gICAgICAgIHJlbmRlcktleWZyYW1lczogKCkgPT4gXCJcIixcbiAgICAgICAgcmVuZGVyRm9udEZhY2U6ICgpID0+IFwiXCIsXG4gICAgICB9fVxuICAgID5cbiAgICAgIDxXaWRnZXQgJGZvbz1cImZvb1wiICRiYXo9XCJiYXpcIiBkYXRhLWJhcj1cImJhclwiIC8+XG4gICAgPC9Qcm92aWRlcj4sXG4gICk7XG59KTtcblxudGVzdChcImNhbGxiYWNrIHJlZiBmb3J3YXJkaW5nXCIsICgpID0+IHtcbiAgY29uc3QgV2lkZ2V0ID0gc3R5bGVkKFwiYnV0dG9uXCIsIHtjb2xvcjogXCJyZWRcIn0pO1xuICBjbGFzcyBUZXN0Q29tcG9uZW50IGV4dGVuZHMgUmVhY3QuQ29tcG9uZW50PHt9PiB7XG4gICAgd2lkZ2V0SW5uZXI6IEhUTUxCdXR0b25FbGVtZW50IHwgdW5kZWZpbmVkIHwgbnVsbDtcbiAgICBjb21wb25lbnREaWRNb3VudCgpIHtcbiAgICAgIGV4cGVjdCh0aGlzLndpZGdldElubmVyIGluc3RhbmNlb2YgSFRNTEJ1dHRvbkVsZW1lbnQpLnRvQmUodHJ1ZSk7XG4gICAgfVxuXG4gICAgcmVuZGVyKCkge1xuICAgICAgcmV0dXJuIChcbiAgICAgICAgPFByb3ZpZGVyXG4gICAgICAgICAgdmFsdWU9e3tcbiAgICAgICAgICAgIHJlbmRlclN0eWxlOiAoKSA9PiBcIlwiLFxuICAgICAgICAgICAgcmVuZGVyS2V5ZnJhbWVzOiAoKSA9PiBcIlwiLFxuICAgICAgICAgICAgcmVuZGVyRm9udEZhY2U6ICgpID0+IFwiXCIsXG4gICAgICAgICAgfX1cbiAgICAgICAgPlxuICAgICAgICAgIDxXaWRnZXRcbiAgICAgICAgICAgIHJlZj17YyA9PiB7XG4gICAgICAgICAgICAgIHRoaXMud2lkZ2V0SW5uZXIgPSBjO1xuICAgICAgICAgICAgfX1cbiAgICAgICAgICAvPlxuICAgICAgICA8L1Byb3ZpZGVyPlxuICAgICAgKTtcbiAgICB9XG4gIH1cbiAgRW56eW1lLm1vdW50KDxUZXN0Q29tcG9uZW50IC8+KTtcbn0pO1xuXG50ZXN0KFwiUmVhY3QuY3JlYXRlUmVmKCkgcmVmIGZvcndhcmRpbmdcIiwgKCkgPT4ge1xuICBjb25zdCBXaWRnZXQgPSBzdHlsZWQoXCJidXR0b25cIiwge2NvbG9yOiBcInJlZFwifSk7XG4gIGNsYXNzIFRlc3RDb21wb25lbnQgZXh0ZW5kcyBSZWFjdC5Db21wb25lbnQ8e30+IHtcbiAgICB3aWRnZXRJbm5lciA9IFJlYWN0LmNyZWF0ZVJlZjxhbnk+KCk7XG5cbiAgICBjb21wb25lbnREaWRNb3VudCgpIHtcbiAgICAgIGV4cGVjdCh0aGlzLndpZGdldElubmVyLmN1cnJlbnQgaW5zdGFuY2VvZiBIVE1MQnV0dG9uRWxlbWVudCkudG9CZSh0cnVlKTtcbiAgICB9XG5cbiAgICByZW5kZXIoKSB7XG4gICAgICByZXR1cm4gKFxuICAgICAgICA8UHJvdmlkZXJcbiAgICAgICAgICB2YWx1ZT17e1xuICAgICAgICAgICAgcmVuZGVyU3R5bGU6ICgpID0+IFwiXCIsXG4gICAgICAgICAgICByZW5kZXJLZXlmcmFtZXM6ICgpID0+IFwiXCIsXG4gICAgICAgICAgICByZW5kZXJGb250RmFjZTogKCkgPT4gXCJcIixcbiAgICAgICAgICB9fVxuICAgICAgICA+XG4gICAgICAgICAgPFdpZGdldCByZWY9e3RoaXMud2lkZ2V0SW5uZXJ9IC8+XG4gICAgICAgIDwvUHJvdmlkZXI+XG4gICAgICApO1xuICAgIH1cbiAgfVxuICBFbnp5bWUubW91bnQoPFRlc3RDb21wb25lbnQgLz4pO1xufSk7XG5cbnRlc3QoXCJSZWFjdC51c2VSZWYoKSByZWYgZm9yd2FyZGluZ1wiLCAoKSA9PiB7XG4gIGNvbnN0IFdpZGdldCA9IHN0eWxlZChcImJ1dHRvblwiLCB7Y29sb3I6IFwicmVkXCJ9KTtcbiAgY29uc3QgVGVzdENvbXBvbmVudCA9ICgpID0+IHtcbiAgICBjb25zdCB3aWRnZXRJbm5lciA9IFJlYWN0LnVzZVJlZjxIVE1MQnV0dG9uRWxlbWVudD4obnVsbCk7XG4gICAgUmVhY3QudXNlRWZmZWN0KCgpID0+IHtcbiAgICAgIGV4cGVjdCh3aWRnZXRJbm5lci5jdXJyZW50IGluc3RhbmNlb2YgSFRNTEJ1dHRvbkVsZW1lbnQpLnRvQmUodHJ1ZSk7XG4gICAgfSwgW10pO1xuICAgIHJldHVybiAoXG4gICAgICA8UHJvdmlkZXJcbiAgICAgICAgdmFsdWU9e3tcbiAgICAgICAgICByZW5kZXJTdHlsZTogKCkgPT4gXCJcIixcbiAgICAgICAgICByZW5kZXJLZXlmcmFtZXM6ICgpID0+IFwiXCIsXG4gICAgICAgICAgcmVuZGVyRm9udEZhY2U6ICgpID0+IFwiXCIsXG4gICAgICAgIH19XG4gICAgICA+XG4gICAgICAgIDxXaWRnZXQgcmVmPXt3aWRnZXRJbm5lcn0gLz5cbiAgICAgIDwvUHJvdmlkZXI+XG4gICAgKTtcbiAgfTtcblxuICBFbnp5bWUubW91bnQoPFRlc3RDb21wb25lbnQgLz4pO1xufSk7XG5cbnRlc3QoXCJsZWdhY3kgc3RyaW5nIHJlZiBmb3J3YXJkaW5nXCIsICgpID0+IHtcbiAgY29uc3QgV2lkZ2V0ID0gc3R5bGVkKFwiYnV0dG9uXCIsIHtjb2xvcjogXCJyZWRcIn0pO1xuICBjbGFzcyBUZXN0Q29tcG9uZW50IGV4dGVuZHMgUmVhY3QuQ29tcG9uZW50PHt9PiB7XG4gICAgY29tcG9uZW50RGlkTW91bnQoKSB7XG4gICAgICBleHBlY3QodGhpcy5yZWZzLm15QnV0dG9uIGluc3RhbmNlb2YgSFRNTEJ1dHRvbkVsZW1lbnQpLnRvQmUodHJ1ZSk7XG4gICAgfVxuICAgIHJlbmRlcigpIHtcbiAgICAgIHJldHVybiAoXG4gICAgICAgIDxQcm92aWRlclxuICAgICAgICAgIHZhbHVlPXt7XG4gICAgICAgICAgICByZW5kZXJTdHlsZTogKCkgPT4gXCJcIixcbiAgICAgICAgICAgIHJlbmRlcktleWZyYW1lczogKCkgPT4gXCJcIixcbiAgICAgICAgICAgIHJlbmRlckZvbnRGYWNlOiAoKSA9PiBcIlwiLFxuICAgICAgICAgIH19XG4gICAgICAgID5cbiAgICAgICAgICA8V2lkZ2V0IHJlZj1cIm15QnV0dG9uXCIgLz5cbiAgICAgICAgPC9Qcm92aWRlcj5cbiAgICAgICk7XG4gICAgfVxuICB9XG4gIEVuenltZS5tb3VudCg8VGVzdENvbXBvbmVudCAvPik7XG59KTtcblxudGVzdChcIndpdGhXcmFwcGVyXCIsICgpID0+IHtcbiAgY29uc3QgV2lkZ2V0ID0gc3R5bGVkPFwiYnV0dG9uXCIsIHtmb28/OiBzdHJpbmd9PihcImJ1dHRvblwiLCB7XG4gICAgY29sb3I6IFwicmVkXCIsXG4gIH0pO1xuICBjb25zdCBXcmFwcGVkV2lkZ2V0ID0gd2l0aFdyYXBwZXIoV2lkZ2V0LCBTdHlsZWRFbGVtZW50ID0+IHByb3BzID0+IHtcbiAgICBleHBlY3QocHJvcHMpLnRvRXF1YWwoe2ZvbzogXCJiYXJcIn0pO1xuICAgIHJldHVybiAoXG4gICAgICA8c2VjdGlvbj5cbiAgICAgICAgPFN0eWxlZEVsZW1lbnQgey4uLnByb3BzfSAvPlxuICAgICAgPC9zZWN0aW9uPlxuICAgICk7XG4gIH0pO1xuICBjb25zdCB3cmFwcGVyMSA9IEVuenltZS5tb3VudChcbiAgICA8UHJvdmlkZXJcbiAgICAgIHZhbHVlPXt7XG4gICAgICAgIHJlbmRlclN0eWxlOiBzdHlsZSA9PiB7XG4gICAgICAgICAgZXhwZWN0KHN0eWxlKS50b0VxdWFsKHtjb2xvcjogXCJyZWRcIn0pO1xuICAgICAgICAgIHJldHVybiBcIlwiO1xuICAgICAgICB9LFxuICAgICAgICByZW5kZXJLZXlmcmFtZXM6ICgpID0+IFwiXCIsXG4gICAgICAgIHJlbmRlckZvbnRGYWNlOiAoKSA9PiBcIlwiLFxuICAgICAgfX1cbiAgICA+XG4gICAgICA8V3JhcHBlZFdpZGdldCBmb289XCJiYXJcIiAvPlxuICAgIDwvUHJvdmlkZXI+LFxuICApO1xuICBleHBlY3Qod3JhcHBlcjEuZmluZChcInNlY3Rpb25cIikubGVuZ3RoKS50b0JlKDEpO1xuXG4gIGNvbnN0IERlbHV4ZVdyYXBwZWRXaWRnZXQgPSB3aXRoU3R5bGUoV3JhcHBlZFdpZGdldCwge2NvbG9yOiBcImJsdWVcIn0pO1xuICBjb25zdCB3cmFwcGVyMiA9IEVuenltZS5tb3VudChcbiAgICA8UHJvdmlkZXJcbiAgICAgIHZhbHVlPXt7XG4gICAgICAgIHJlbmRlclN0eWxlOiBzdHlsZSA9PiB7XG4gICAgICAgICAgZXhwZWN0KHN0eWxlKS50b0VxdWFsKHtjb2xvcjogXCJibHVlXCJ9KTtcbiAgICAgICAgICByZXR1cm4gXCJcIjtcbiAgICAgICAgfSxcbiAgICAgICAgcmVuZGVyS2V5ZnJhbWVzOiAoKSA9PiBcIlwiLFxuICAgICAgICByZW5kZXJGb250RmFjZTogKCkgPT4gXCJcIixcbiAgICAgIH19XG4gICAgPlxuICAgICAgPERlbHV4ZVdyYXBwZWRXaWRnZXQgZm9vPVwiYmFyXCIgLz5cbiAgICA8L1Byb3ZpZGVyPixcbiAgKTtcbiAgZXhwZWN0KHdyYXBwZXIyLmZpbmQoXCJzZWN0aW9uXCIpLmxlbmd0aCkudG9CZSgxKTtcbn0pO1xuXG50ZXN0KFwic3R5bGVkIGRlYnVnIG1vZGUgKGNsaWVudCBvbmx5KVwiLCAoKSA9PiB7XG4gIGxldCBkZWJ1Z0NhbGxDb3VudCA9IDA7XG5cbiAgY29uc3Qgc3R5bGUgPSB7Y29sb3I6IFwicmVkXCJ9O1xuICBjb25zdCBXaWRnZXQgPSBzdHlsZWQoXCJkaXZcIiwgc3R5bGUpO1xuXG4gIGNvbnN0IHdyYXBwZXIgPSBFbnp5bWUubW91bnQoXG4gICAgPFByb3ZpZGVyXG4gICAgICB2YWx1ZT17e1xuICAgICAgICByZW5kZXJTdHlsZTogKCkgPT4gXCJiYXJcIixcbiAgICAgICAgcmVuZGVyS2V5ZnJhbWVzOiAoKSA9PiBcIlwiLFxuICAgICAgICByZW5kZXJGb250RmFjZTogKCkgPT4gXCJcIixcbiAgICAgIH19XG4gICAgICBkZWJ1Zz17e1xuICAgICAgICBkZWJ1ZzogKHtzdGFja0luZGV4LCBzdGFja0luZm99KSA9PiB7XG4gICAgICAgICAgZGVidWdDYWxsQ291bnQrKztcbiAgICAgICAgICBleHBlY3Qoc3RhY2tJbmRleCkudG9CZSgyKTtcbiAgICAgICAgICBleHBlY3QodHlwZW9mIHN0YWNrSW5mbykudG9CZShcIm9iamVjdFwiKTtcbiAgICAgICAgICBleHBlY3QodHlwZW9mIHN0YWNrSW5mby5zdGFjaykudG9CZShcInN0cmluZ1wiKTtcbiAgICAgICAgICBleHBlY3QodHlwZW9mIHN0YWNrSW5mby5tZXNzYWdlKS50b0JlKFwic3RyaW5nXCIpO1xuICAgICAgICAgIHJldHVybiBcIl9fYXJiaXRyYXJ5X2RlYnVnX2NsYXNzX19cIjtcbiAgICAgICAgfSxcbiAgICAgIH19XG4gICAgPlxuICAgICAgPFdpZGdldCBjbGFzc05hbWU9XCJmb29cIiAvPlxuICAgIDwvUHJvdmlkZXI+LFxuICApO1xuXG4gIGNvbnN0IGRpdnMgPSB3cmFwcGVyLmZpbmQoXCJkaXZcIik7XG4gIGV4cGVjdChkaXZzLmxlbmd0aCkudG9CZSgxKTtcbiAgZXhwZWN0KGRpdnMuaGFzQ2xhc3MoXCJfX2FyYml0cmFyeV9kZWJ1Z19jbGFzc19fIGZvbyBiYXJcIikpLnRvQmUodHJ1ZSk7XG4gIHdyYXBwZXIudW5tb3VudCgpO1xuICB3cmFwcGVyLm1vdW50KCk7XG4gIHdyYXBwZXIudW5tb3VudCgpO1xuICBleHBlY3QoZGVidWdDYWxsQ291bnQpLnRvQmUoMSk7XG59KTtcblxudGVzdChcInN0eWxlZCBkZWJ1ZyBtb2RlIChzc3IpXCIsICgpID0+IHtcbiAgY29uc3Qgc3R5bGUgPSB7Y29sb3I6IFwicmVkXCJ9O1xuICBsZXQgY291bnQgPSAwO1xuICBjb25zdCBXaWRnZXQgPSBzdHlsZWQoXCJkaXZcIiwgc3R5bGUpO1xuICBjb25zdCB3cmFwcGVyID0gRW56eW1lLm1vdW50KFxuICAgIDxQcm92aWRlclxuICAgICAgdmFsdWU9e3tcbiAgICAgICAgcmVuZGVyU3R5bGU6ICgpID0+IHtcbiAgICAgICAgICBjb3VudCsrO1xuICAgICAgICAgIHJldHVybiBcImZvb1wiO1xuICAgICAgICB9LFxuICAgICAgICByZW5kZXJLZXlmcmFtZXM6ICgpID0+IFwiXCIsXG4gICAgICAgIHJlbmRlckZvbnRGYWNlOiAoKSA9PiBcIlwiLFxuICAgICAgfX1cbiAgICAgIGRlYnVnPXt7XG4gICAgICAgIGRlYnVnOiAoKSA9PiB7XG4gICAgICAgICAgZXhwZWN0KGNvdW50KS50b0JlKDIpO1xuICAgICAgICAgIHJldHVybiBcIl9fc29tZV9kZWJ1Z19jbGFzc1wiO1xuICAgICAgICB9LFxuICAgICAgfX1cbiAgICAgIGRlYnVnQWZ0ZXJIeWRyYXRpb25cbiAgICA+XG4gICAgICA8V2lkZ2V0IC8+XG4gICAgPC9Qcm92aWRlcj4sXG4gICk7XG4gIGNvbnN0IGRpdnMgPSB3cmFwcGVyLmZpbmQoXCJkaXZcIik7XG4gIGV4cGVjdChjb3VudCkudG9CZSgyKTtcbiAgZXhwZWN0KGRpdnMuaGFzQ2xhc3MoXCJfX3NvbWVfZGVidWdfY2xhc3MgZm9vXCIpKS50b0JlKHRydWUpO1xufSk7XG5cbnRlc3QoXCJmb250LWZhY2UgaW5qZWN0aW9uXCIsICgpID0+IHtcbiAgY29uc3QgZm9udEZhY2UgPSB7XG4gICAgc3JjOiBcImZvb1wiLFxuICB9O1xuICBjb25zdCBzdHlsZSA9IHtmb250RmFtaWx5OiBmb250RmFjZX0gYXMgU3R5bGVPYmplY3Q7XG4gIGNvbnN0IFdpZGdldCA9IHN0eWxlZChcImRpdlwiLCBzdHlsZSk7XG4gIEVuenltZS5tb3VudChcbiAgICA8UHJvdmlkZXJcbiAgICAgIHZhbHVlPXt7XG4gICAgICAgIHJlbmRlclN0eWxlOiB4ID0+IHtcbiAgICAgICAgICBleHBlY3QoeCkudG9FcXVhbCh7XG4gICAgICAgICAgICBmb250RmFtaWx5OiBcImZvb1wiLFxuICAgICAgICAgIH0pO1xuICAgICAgICAgIHJldHVybiBcIlwiO1xuICAgICAgICB9LFxuICAgICAgICByZW5kZXJGb250RmFjZTogeCA9PiB7XG4gICAgICAgICAgZXhwZWN0KHgpLnRvRXF1YWwoZm9udEZhY2UpO1xuICAgICAgICAgIHJldHVybiBcImZvb1wiO1xuICAgICAgICB9LFxuICAgICAgICByZW5kZXJLZXlmcmFtZXM6ICgpID0+IFwiXCIsXG4gICAgICB9fVxuICAgID5cbiAgICAgIDxXaWRnZXQgLz5cbiAgICA8L1Byb3ZpZGVyPixcbiAgKTtcbn0pO1xuXG50ZXN0KFwia2V5ZnJhbWVzIGluamVjdGlvblwiLCAoKSA9PiB7XG4gIGNvbnN0IGtleWZyYW1lcyA9IHtcbiAgICBmcm9tOiB7Y29sb3I6IFwicmVkXCJ9LFxuICAgIHRvOiB7Y29sb3I6IFwiZ3JlZW5cIn0sXG4gIH07XG4gIGNvbnN0IHN0eWxlID0ge2FuaW1hdGlvbk5hbWU6IGtleWZyYW1lc307XG4gIGNvbnN0IFdpZGdldCA9IHN0eWxlZChcImRpdlwiLCBzdHlsZSk7XG4gIEVuenltZS5tb3VudChcbiAgICA8UHJvdmlkZXJcbiAgICAgIHZhbHVlPXt7XG4gICAgICAgIHJlbmRlclN0eWxlOiB4ID0+IHtcbiAgICAgICAgICBleHBlY3QoeCkudG9FcXVhbCh7YW5pbWF0aW9uTmFtZTogXCJmb29cIn0pO1xuICAgICAgICAgIHJldHVybiBcIlwiO1xuICAgICAgICB9LFxuICAgICAgICByZW5kZXJLZXlmcmFtZXM6IHggPT4ge1xuICAgICAgICAgIGV4cGVjdCh4KS50b0VxdWFsKGtleWZyYW1lcyk7XG4gICAgICAgICAgcmV0dXJuIFwiZm9vXCI7XG4gICAgICAgIH0sXG4gICAgICAgIHJlbmRlckZvbnRGYWNlOiAoKSA9PiBcIlwiLFxuICAgICAgfX1cbiAgICA+XG4gICAgICA8V2lkZ2V0IC8+XG4gICAgPC9Qcm92aWRlcj4sXG4gICk7XG59KTtcblxudGVzdChcImNyZWF0ZVN0eWxlZCB3cmFwcGVyXCIsICgpID0+IHtcbiAgY29uc3QgY3VzdG9tU3R5bGVkID0gY3JlYXRlU3R5bGVkKHtcbiAgICBkcml2ZXIsXG4gICAgZ2V0SW5pdGlhbFN0eWxlLFxuICAgIHdyYXBwZXI6IF9Db21wb25lbnQgPT4gcHJvcHMgPT4ge1xuICAgICAgZXhwZWN0KHByb3BzLmZvbykudG9CZShcImZvb1wiKTtcbiAgICAgIHJldHVybiA8ZGl2PmhlbGxvIHdvcmxkPC9kaXY+O1xuICAgIH0sXG4gIH0pO1xuICBjb25zdCBXaWRnZXQgPSBjdXN0b21TdHlsZWQ8XCJkaXZcIiwge2Zvbzogc3RyaW5nfT4oXCJkaXZcIiwge1xuICAgIGNvbG9yOiBcInJlZFwiLFxuICB9KTtcbiAgRW56eW1lLm1vdW50KFxuICAgIDxQcm92aWRlclxuICAgICAgdmFsdWU9e3tcbiAgICAgICAgcmVuZGVyU3R5bGU6ICgpID0+IFwiXCIsXG4gICAgICAgIHJlbmRlcktleWZyYW1lczogKCkgPT4gXCJcIixcbiAgICAgICAgcmVuZGVyRm9udEZhY2U6ICgpID0+IFwiXCIsXG4gICAgICB9fVxuICAgID5cbiAgICAgIDxXaWRnZXQgZm9vPVwiZm9vXCIgLz5cbiAgICA8L1Byb3ZpZGVyPixcbiAgKTtcbn0pO1xuXG50ZXN0KFwidXNlU3R5bGV0cm9uIGNzc1wiLCAoKSA9PiB7XG4gIGZ1bmN0aW9uIExpbmsoKSB7XG4gICAgY29uc3QgW2Nzc10gPSB1c2VTdHlsZXRyb24oKTtcbiAgICBjb25zdCBjbGFzc05hbWUgPSBjc3Moe2NvbG9yOiBcImJsdWVcIn0pO1xuICAgIGV4cGVjdChjbGFzc05hbWUpLnRvQmUoXCIuYWJjXCIpO1xuICAgIHJldHVybiA8YSBjbGFzc05hbWU9e2NsYXNzTmFtZX0+Rm9vPC9hPjtcbiAgfVxuXG4gIEVuenltZS5tb3VudChcbiAgICA8UHJvdmlkZXJcbiAgICAgIHZhbHVlPXt7XG4gICAgICAgIHJlbmRlclN0eWxlOiB4ID0+IHtcbiAgICAgICAgICBleHBlY3QoeCkudG9FcXVhbCh7XG4gICAgICAgICAgICBjb2xvcjogXCJibHVlXCIsXG4gICAgICAgICAgfSk7XG4gICAgICAgICAgcmV0dXJuIFwiLmFiY1wiO1xuICAgICAgICB9LFxuICAgICAgICByZW5kZXJLZXlmcmFtZXM6ICgpID0+IFwiXCIsXG4gICAgICAgIHJlbmRlckZvbnRGYWNlOiAoKSA9PiBcIlwiLFxuICAgICAgfX1cbiAgICA+XG4gICAgICA8TGluayAvPlxuICAgIDwvUHJvdmlkZXI+LFxuICApO1xufSk7XG5cbnRlc3QoXCJ1c2VTdHlsZXRyb24gZGVidWcgbW9kZVwiLCAoKSA9PiB7XG4gIGZ1bmN0aW9uIFdpZGdldCgpIHtcbiAgICBjb25zdCBbY3NzXSA9IHVzZVN0eWxldHJvbigpO1xuICAgIGNvbnN0IFtvbiwgc2V0T25dID0gUmVhY3QudXNlU3RhdGUoZmFsc2UpO1xuICAgIGNvbnN0IGNsYXNzTmFtZSA9IGNzcyh7Y29sb3I6IFwicmVkXCJ9KTtcbiAgICByZXR1cm4gKFxuICAgICAgPGJ1dHRvbiBvbkNsaWNrPXsoKSA9PiBzZXRPbighb24pfSBjbGFzc05hbWU9e2NsYXNzTmFtZX0+XG4gICAgICAgIHRlc3RcbiAgICAgIDwvYnV0dG9uPlxuICAgICk7XG4gIH1cblxuICBsZXQgZGVidWdDYWxsQ291bnQgPSAwO1xuICBjb25zdCB3cmFwcGVyID0gRW56eW1lLm1vdW50KFxuICAgIDxQcm92aWRlclxuICAgICAgdmFsdWU9e3tcbiAgICAgICAgcmVuZGVyU3R5bGU6ICgpID0+IFwiYmFyXCIsXG4gICAgICAgIHJlbmRlcktleWZyYW1lczogKCkgPT4gXCJcIixcbiAgICAgICAgcmVuZGVyRm9udEZhY2U6ICgpID0+IFwiXCIsXG4gICAgICB9fVxuICAgICAgZGVidWc9e3tcbiAgICAgICAgZGVidWc6ICgpID0+IHtcbiAgICAgICAgICBkZWJ1Z0NhbGxDb3VudCsrO1xuICAgICAgICAgIHJldHVybiBgX19kZWJ1Zy0ke2RlYnVnQ2FsbENvdW50fWA7XG4gICAgICAgIH0sXG4gICAgICB9fVxuICAgID5cbiAgICAgIDxXaWRnZXQgLz5cbiAgICA8L1Byb3ZpZGVyPixcbiAgKTtcblxuICBjb25zdCBidXR0b24gPSB3cmFwcGVyLmZpbmQoXCJidXR0b25cIik7XG4gIGV4cGVjdChidXR0b24uaGFzQ2xhc3MoXCJfX2RlYnVnLTEgYmFyXCIpKS50b0JlKHRydWUpO1xuICBidXR0b24uc2ltdWxhdGUoXCJjbGlja1wiKTtcbiAgZXhwZWN0KGJ1dHRvbi5oYXNDbGFzcyhcIl9fZGVidWctMSBiYXJcIikpLnRvQmUodHJ1ZSk7XG4gIGV4cGVjdChkZWJ1Z0NhbGxDb3VudCkudG9CZSgxKTtcbn0pO1xuXG50ZXN0KFwibm8tb3AgZW5naW5lXCIsICgpID0+IHtcbiAgY29uc3QgY29uc29sZVdhcm4gPSBjb25zb2xlLndhcm47IC8vIGVzbGludC1kaXNhYmxlLWxpbmVcblxuICAoY29uc29sZSBhcyBhbnkpLndhcm4gPSBtZXNzYWdlID0+IHtcbiAgICBleHBlY3QobWVzc2FnZS5zcGxpdChcIlxcblwiKVsxXSkudG9CZShcbiAgICAgIFwiU3R5bGV0cm9uIGhhcyBiZWVuIHN3aXRjaGVkIHRvIGEgbm8tb3AgKHRlc3QpIG1vZGUuXCIsXG4gICAgKTtcbiAgfTtcbiAgY29uc3QgV2lkZ2V0ID0gc3R5bGVkKFwiZGl2XCIsIHtcbiAgICBjb2xvcjogXCJyZWRcIixcbiAgfSk7XG4gIEVuenltZS5tb3VudCg8V2lkZ2V0IC8+KTtcblxuICAoY29uc29sZSBhcyBhbnkpLndhcm4gPSBjb25zb2xlV2Fybjtcbn0pO1xuIl0sIm1hcHBpbmdzIjoiQUFBQSxPQUFPQSxNQUFQLE1BQW1CLFFBQW5CO0FBQ0EsT0FBT0MsT0FBUCxNQUFvQix5QkFBcEI7QUFDQSxPQUFPLEtBQUtDLEtBQVosTUFBdUIsT0FBdkI7QUFFQSxTQUNFQyxNQURGLEVBRUVDLFlBRkYsRUFHRUMsV0FIRixFQUlFQyxTQUpGLEVBS0VDLGFBTEYsRUFNRUMsUUFORixFQU9FQyxZQVBGLFFBUU8sVUFSUDtBQVVBLFNBQVFDLGVBQVIsRUFBeUJDLE1BQXpCLFFBQXNDLG9CQUF0QztBQUdBWCxNQUFNLENBQUNZLFNBQVAsQ0FBaUI7RUFBQ0MsT0FBTyxFQUFFLElBQUlaLE9BQUo7QUFBVixDQUFqQjtBQUVBYSxJQUFJLENBQUMsaUJBQUQsRUFBb0IsTUFBTTtFQUM1QixNQUFNQyxLQUFLLEdBQUc7SUFBQ0MsS0FBSyxFQUFFO0VBQVIsQ0FBZDtFQUNBLE1BQU1DLE1BQU0sR0FBR2QsTUFBTSxDQUFDLEtBQUQsRUFBUVksS0FBUixDQUFyQjtFQUNBZixNQUFNLENBQUNrQixLQUFQLGVBQ0Usb0JBQUMsUUFBRDtJQUNFLEtBQUssRUFBRTtNQUNMQyxXQUFXLEVBQUVDLENBQUMsSUFBSTtRQUNoQkMsTUFBTSxDQUFDRCxDQUFELENBQU4sQ0FBVUUsT0FBVixDQUFrQlAsS0FBbEI7UUFDQSxPQUFPLEVBQVA7TUFDRCxDQUpJO01BS0xRLGVBQWUsRUFBRSxNQUFNLEVBTGxCO01BTUxDLGNBQWMsRUFBRSxNQUFNO0lBTmpCO0VBRFQsZ0JBVUUsb0JBQUMsTUFBRCxPQVZGLENBREY7RUFjQSxNQUFNQyxPQUFPLEdBQUd6QixNQUFNLENBQUNrQixLQUFQLGVBQ2Qsb0JBQUMsUUFBRDtJQUNFLEtBQUssRUFBRTtNQUNMQyxXQUFXLEVBQUUsTUFBTSxLQURkO01BRUxJLGVBQWUsRUFBRSxNQUFNLEVBRmxCO01BR0xDLGNBQWMsRUFBRSxNQUFNO0lBSGpCO0VBRFQsZ0JBT0Usb0JBQUMsTUFBRDtJQUFRLFNBQVMsRUFBQztFQUFsQixFQVBGLENBRGMsQ0FBaEI7RUFXQSxNQUFNRSxJQUFJLEdBQUdELE9BQU8sQ0FBQ0UsSUFBUixDQUFhLEtBQWIsQ0FBYjtFQUNBTixNQUFNLENBQUNLLElBQUksQ0FBQ0UsTUFBTixDQUFOLENBQW9CQyxJQUFwQixDQUF5QixDQUF6QjtFQUNBUixNQUFNLENBQUNLLElBQUksQ0FBQ0ksUUFBTCxDQUFjLFNBQWQsQ0FBRCxDQUFOLENBQWlDRCxJQUFqQyxDQUFzQyxJQUF0QztBQUNELENBL0JHLENBQUo7QUFpQ0FmLElBQUksQ0FBQyxrQkFBRCxFQUFxQixNQUFNO0VBQzdCLE1BQU1HLE1BQU0sR0FBR2QsTUFBTSxDQUFDLEtBQUQsRUFBUzRCLEtBQUQsS0FBNkI7SUFDeERmLEtBQUssRUFBRWUsS0FBSyxDQUFDQyxJQUFOLEdBQWEsS0FBYixHQUFxQjtFQUQ0QixDQUE3QixDQUFSLENBQXJCO0VBSUFoQyxNQUFNLENBQUNrQixLQUFQLGVBQ0Usb0JBQUMsUUFBRDtJQUNFLEtBQUssRUFBRTtNQUNMQyxXQUFXLEVBQUVDLENBQUMsSUFBSTtRQUNoQkMsTUFBTSxDQUFDRCxDQUFELENBQU4sQ0FBVUUsT0FBVixDQUFrQjtVQUFDTixLQUFLLEVBQUU7UUFBUixDQUFsQjtRQUNBLE9BQU8sRUFBUDtNQUNELENBSkk7TUFLTE8sZUFBZSxFQUFFLE1BQU0sRUFMbEI7TUFNTEMsY0FBYyxFQUFFLE1BQU07SUFOakI7RUFEVCxnQkFVRSxvQkFBQyxNQUFEO0lBQVEsSUFBSSxFQUFFO0VBQWQsRUFWRixDQURGO0FBY0QsQ0FuQkcsQ0FBSjtBQXFCQVYsSUFBSSxDQUFDLG9CQUFELEVBQXVCLE1BQU07RUFDL0IsTUFBTUcsTUFBTSxHQUFHZCxNQUFNLENBQUMsS0FBRCxFQUFRO0lBQzNCOEIsV0FBVyxFQUFFLENBRGM7SUFFM0JqQixLQUFLLEVBQUUsS0FGb0I7SUFHM0IsVUFBVTtNQUFDa0IsUUFBUSxFQUFFO0lBQVg7RUFIaUIsQ0FBUixDQUFyQjtFQUtBLE1BQU1DLFdBQVcsR0FBRzdCLFNBQVMsQ0FBQ1csTUFBRCxFQUFTO0lBQ3BDRCxLQUFLLEVBQUUsTUFENkI7SUFFcEMsVUFBVTtNQUFDaUIsV0FBVyxFQUFFO0lBQWQ7RUFGMEIsQ0FBVCxDQUE3QjtFQUlBakMsTUFBTSxDQUFDa0IsS0FBUCxlQUNFLG9CQUFDLFFBQUQ7SUFDRSxLQUFLLEVBQUU7TUFDTEMsV0FBVyxFQUFFQyxDQUFDLElBQUk7UUFDaEJDLE1BQU0sQ0FBQ0QsQ0FBRCxDQUFOLENBQVVFLE9BQVYsQ0FBa0I7VUFDaEJXLFdBQVcsRUFBRSxDQURHO1VBRWhCakIsS0FBSyxFQUFFLE1BRlM7VUFHaEIsVUFBVTtZQUFDa0IsUUFBUSxFQUFFLE1BQVg7WUFBbUJELFdBQVcsRUFBRTtVQUFoQztRQUhNLENBQWxCO1FBS0EsT0FBTyxFQUFQO01BQ0QsQ0FSSTtNQVNMVixlQUFlLEVBQUUsTUFBTSxFQVRsQjtNQVVMQyxjQUFjLEVBQUUsTUFBTTtJQVZqQjtFQURULGdCQWNFLG9CQUFDLFdBQUQsT0FkRixDQURGO0FBa0JELENBNUJHLENBQUo7QUE4QkFWLElBQUksQ0FBQyxxQkFBRCxFQUF3QixNQUFNO0VBQ2hDLE1BQU1HLE1BQU0sR0FBR2QsTUFBTSxDQUFDLEtBQUQsRUFBUTtJQUMzQmlDLFVBQVUsRUFBRSxDQURlO0lBRTNCcEIsS0FBSyxFQUFFLEtBRm9CO0lBRzNCLFVBQVU7TUFBQ2tCLFFBQVEsRUFBRTtJQUFYO0VBSGlCLENBQVIsQ0FBckI7RUFLQSxNQUFNQyxXQUFXLEdBQUc3QixTQUFTLENBQzNCVyxNQUQyQixFQUUzQmMsS0FBSyxLQUFLO0lBQ1JNLFVBQVUsRUFBRU4sS0FBSyxDQUFDTyxNQUFOLEdBQWUsUUFBZixHQUEwQixPQUQ5QjtJQUVSLFVBQVU7TUFBQ0wsV0FBVyxFQUFFO0lBQWQ7RUFGRixDQUFMLENBRnNCLENBQTdCO0VBT0FqQyxNQUFNLENBQUNrQixLQUFQLGVBQ0Usb0JBQUMsUUFBRDtJQUNFLEtBQUssRUFBRTtNQUNMQyxXQUFXLEVBQUVDLENBQUMsSUFBSTtRQUNoQkMsTUFBTSxDQUFDRCxDQUFELENBQU4sQ0FBVUUsT0FBVixDQUFrQjtVQUNoQk4sS0FBSyxFQUFFLEtBRFM7VUFFaEJxQixVQUFVLEVBQUUsUUFGSTtVQUdoQkQsVUFBVSxFQUFFLENBSEk7VUFJaEIsVUFBVTtZQUFDSCxXQUFXLEVBQUUsQ0FBZDtZQUFpQkMsUUFBUSxFQUFFO1VBQTNCO1FBSk0sQ0FBbEI7UUFPQSxPQUFPLEVBQVA7TUFDRCxDQVZJO01BV0xYLGVBQWUsRUFBRSxNQUFNLEVBWGxCO01BWUxDLGNBQWMsRUFBRSxNQUFNO0lBWmpCO0VBRFQsZ0JBZ0JFLG9CQUFDLFdBQUQ7SUFBYSxNQUFNLEVBQUU7RUFBckIsRUFoQkYsQ0FERjtBQW9CRCxDQWpDRyxDQUFKO0FBbUNBVixJQUFJLENBQUMsc0JBQUQsRUFBeUIsTUFBTTtFQUNqQyxNQUFNRyxNQUFNLEdBQUdkLE1BQU0sQ0FBQyxLQUFELEVBQVE7SUFDM0JpQyxVQUFVLEVBQUUsQ0FEZTtJQUUzQnBCLEtBQUssRUFBRSxLQUZvQjtJQUczQixVQUFVO01BQUNrQixRQUFRLEVBQUU7SUFBWDtFQUhpQixDQUFSLENBQXJCO0VBTUFsQyxNQUFNLENBQUNrQixLQUFQLGVBQ0Usb0JBQUMsUUFBRDtJQUNFLEtBQUssRUFBRTtNQUNMQyxXQUFXLEVBQUVDLENBQUMsSUFBSTtRQUNoQkMsTUFBTSxDQUFDRCxDQUFELENBQU4sQ0FBVUUsT0FBVixDQUFrQjtVQUNoQk4sS0FBSyxFQUFFLE1BRFM7VUFFaEJvQixVQUFVLEVBQUUsQ0FGSTtVQUdoQixVQUFVO1lBQUNGLFFBQVEsRUFBRTtVQUFYO1FBSE0sQ0FBbEI7UUFLQSxPQUFPLEVBQVA7TUFDRCxDQVJJO01BU0xYLGVBQWUsRUFBRSxNQUFNLEVBVGxCO01BVUxDLGNBQWMsRUFBRSxNQUFNO0lBVmpCO0VBRFQsZ0JBY0Usb0JBQUMsTUFBRDtJQUFRLE1BQU0sRUFBRTtNQUFDUixLQUFLLEVBQUU7SUFBUjtFQUFoQixFQWRGLENBREY7QUFrQkQsQ0F6QkcsQ0FBSjtBQTJCQUYsSUFBSSxDQUFDLHVCQUFELEVBQTBCLE1BQU07RUFDbEMsTUFBTUcsTUFBTSxHQUFHZCxNQUFNLENBQTJCLEtBQTNCLEVBQWtDO0lBQ3JEaUMsVUFBVSxFQUFFLENBRHlDO0lBRXJEcEIsS0FBSyxFQUFFLEtBRjhDO0lBR3JELFVBQVU7TUFBQ2tCLFFBQVEsRUFBRTtJQUFYO0VBSDJDLENBQWxDLENBQXJCO0VBTUFsQyxNQUFNLENBQUNrQixLQUFQLGVBQ0Usb0JBQUMsUUFBRDtJQUNFLEtBQUssRUFBRTtNQUNMQyxXQUFXLEVBQUVDLENBQUMsSUFBSTtRQUNoQkMsTUFBTSxDQUFDRCxDQUFELENBQU4sQ0FBVUUsT0FBVixDQUFrQjtVQUNoQk4sS0FBSyxFQUFFLE1BRFM7VUFFaEJxQixVQUFVLEVBQUUsUUFGSTtVQUdoQkQsVUFBVSxFQUFFLENBSEk7VUFJaEIsVUFBVTtZQUFDRixRQUFRLEVBQUUsTUFBWDtZQUFtQkQsV0FBVyxFQUFFO1VBQWhDO1FBSk0sQ0FBbEI7UUFNQSxPQUFPLEVBQVA7TUFDRCxDQVRJO01BVUxWLGVBQWUsRUFBRSxNQUFNLEVBVmxCO01BV0xDLGNBQWMsRUFBRSxNQUFNO0lBWGpCO0VBRFQsZ0JBZUUsb0JBQUMsTUFBRDtJQUNFLE1BQU0sRUFBRU8sS0FBSyxLQUFLO01BQ2hCZixLQUFLLEVBQUUsTUFEUztNQUVoQnFCLFVBQVUsRUFBRU4sS0FBSyxDQUFDTyxNQUFOLEdBQWUsUUFBZixHQUEwQixPQUZ0QjtNQUdoQixVQUFVO1FBQUNMLFdBQVcsRUFBRTtNQUFkO0lBSE0sQ0FBTCxDQURmO0lBTUUsTUFBTSxFQUFFO0VBTlYsRUFmRixDQURGO0FBMEJELENBakNHLENBQUo7QUFtQ0FuQixJQUFJLENBQUMsbUNBQUQsRUFBc0MsTUFBTTtFQUM5QyxNQUFNRyxNQUFNLEdBQUdkLE1BQU0sQ0FBQyxLQUFELEVBQVE7SUFDM0JhLEtBQUssRUFBRSxLQURvQjtJQUUzQmtCLFFBQVEsRUFBRTtFQUZpQixDQUFSLENBQXJCO0VBS0EsTUFBTUssV0FBVyxHQUFHakMsU0FBUyxDQUFDVyxNQUFELEVBQVM7SUFBQ0QsS0FBSyxFQUFFO0VBQVIsQ0FBVCxDQUE3QjtFQUNBLE1BQU13QixjQUFjLEdBQUdsQyxTQUFTLENBQUNpQyxXQUFELEVBQWM7SUFBQ0wsUUFBUSxFQUFFO0VBQVgsQ0FBZCxDQUFoQztFQUVBbEMsTUFBTSxDQUFDa0IsS0FBUCxlQUNFLG9CQUFDLFFBQUQ7SUFDRSxLQUFLLEVBQUU7TUFDTEMsV0FBVyxFQUFFQyxDQUFDLElBQUk7UUFDaEJDLE1BQU0sQ0FBQ0QsQ0FBRCxDQUFOLENBQVVFLE9BQVYsQ0FBa0I7VUFDaEJOLEtBQUssRUFBRSxRQURTO1VBRWhCa0IsUUFBUSxFQUFFLE1BRk07VUFHaEJPLE9BQU8sRUFBRTtRQUhPLENBQWxCO1FBS0EsT0FBTyxFQUFQO01BQ0QsQ0FSSTtNQVNMbEIsZUFBZSxFQUFFLE1BQU0sRUFUbEI7TUFVTEMsY0FBYyxFQUFFLE1BQU07SUFWakI7RUFEVCxnQkFjRSxvQkFBQyxjQUFEO0lBQ0UsTUFBTSxFQUFFO01BQ05SLEtBQUssRUFBRSxRQUREO01BRU55QixPQUFPLEVBQUU7SUFGSDtFQURWLEVBZEYsQ0FERjtBQXVCRCxDQWhDRyxDQUFKO0FBa0NBM0IsSUFBSSxDQUFDLGVBQUQsRUFBa0IsTUFBTTtFQUMxQixNQUFNRyxNQUFNLEdBQUdkLE1BQU0sQ0FBQyxLQUFELEVBQVE7SUFBQ2EsS0FBSyxFQUFFLEtBQVI7SUFBZXFCLFVBQVUsRUFBRTtFQUEzQixDQUFSLENBQXJCO0VBQ0EsTUFBTUYsV0FBVyxHQUFHNUIsYUFBYSxDQUMvQlUsTUFEK0IsRUFFL0IsQ0FBQ0YsS0FBRCxFQUFRZ0IsS0FBUixNQUFzQyxFQUNwQyxHQUFHaEIsS0FEaUM7SUFFcENzQixVQUFVLEVBQUVOLEtBQUssQ0FBQ08sTUFBTixHQUFlLFFBQWYsR0FBMEI7RUFGRixDQUF0QyxDQUYrQixDQUFqQztFQU9BdEMsTUFBTSxDQUFDa0IsS0FBUCxlQUNFLG9CQUFDLFFBQUQ7SUFDRSxLQUFLLEVBQUU7TUFDTEMsV0FBVyxFQUFFQyxDQUFDLElBQUk7UUFDaEJDLE1BQU0sQ0FBQ0QsQ0FBRCxDQUFOLENBQVVFLE9BQVYsQ0FBa0I7VUFBQ04sS0FBSyxFQUFFLEtBQVI7VUFBZXFCLFVBQVUsRUFBRTtRQUEzQixDQUFsQjtRQUNBLE9BQU8sRUFBUDtNQUNELENBSkk7TUFLTGIsY0FBYyxFQUFFLE1BQU07UUFDcEIsT0FBTyxFQUFQO01BQ0QsQ0FQSTtNQVFMRCxlQUFlLEVBQUUsTUFBTTtRQUNyQixPQUFPLEVBQVA7TUFDRDtJQVZJO0VBRFQsZ0JBY0Usb0JBQUMsV0FBRDtJQUFhLE1BQU0sRUFBRTtFQUFyQixFQWRGLENBREY7QUFrQkQsQ0EzQkcsQ0FBSjtBQTZCQVQsSUFBSSxDQUFDLFdBQUQsRUFBYyxNQUFNO0VBQ3RCLE1BQU1HLE1BQU0sR0FBR2QsTUFBTSxDQUFDLEtBQUQsRUFBUSxFQUFSLENBQXJCOztFQUNBLE1BQU11QyxhQUFhLEdBQUdYLEtBQUssSUFBSTtJQUM3QlYsTUFBTSxDQUFDVSxLQUFLLENBQUNZLFNBQVAsQ0FBTixDQUF3QmQsSUFBeEIsQ0FBNkIsS0FBN0I7SUFDQSxvQkFBTyxnQ0FBUDtFQUNELENBSEQ7O0VBSUE3QixNQUFNLENBQUNrQixLQUFQLGVBQ0Usb0JBQUMsUUFBRDtJQUNFLEtBQUssRUFBRTtNQUNMQyxXQUFXLEVBQUUsTUFBTSxLQURkO01BRUxJLGVBQWUsRUFBRSxNQUFNLEVBRmxCO01BR0xDLGNBQWMsRUFBRSxNQUFNO0lBSGpCO0VBRFQsZ0JBT0Usb0JBQUMsTUFBRDtJQUFRLEdBQUcsRUFBRWtCO0VBQWIsRUFQRixDQURGO0VBV0EsTUFBTWpCLE9BQU8sR0FBR3pCLE1BQU0sQ0FBQ2tCLEtBQVAsZUFDZCxvQkFBQyxRQUFEO0lBQ0UsS0FBSyxFQUFFO01BQ0xDLFdBQVcsRUFBRSxNQUFNLEVBRGQ7TUFFTEksZUFBZSxFQUFFLE1BQU0sRUFGbEI7TUFHTEMsY0FBYyxFQUFFLE1BQU07SUFIakI7RUFEVCxnQkFPRSxvQkFBQyxNQUFEO0lBQVEsR0FBRyxFQUFDO0VBQVosRUFQRixDQURjLENBQWhCO0VBV0FILE1BQU0sQ0FBQ0ksT0FBTyxDQUFDRSxJQUFSLENBQWEsTUFBYixFQUFxQkMsTUFBdEIsQ0FBTixDQUFvQ0MsSUFBcEMsQ0FBeUMsQ0FBekM7QUFDRCxDQTdCRyxDQUFKO0FBK0JBZixJQUFJLENBQUMsNkJBQUQsRUFBZ0MsTUFBTTtFQUN4QyxNQUFNOEIsY0FBTixTQUE2QjFDLEtBQUssQ0FBQzJDLFNBQW5DLENBRUc7SUFDREMsTUFBTSxHQUFHO01BQ1B6QixNQUFNLENBQUMsS0FBS1UsS0FBTixDQUFOLENBQW1CVCxPQUFuQixDQUEyQjtRQUN6QnFCLFNBQVMsRUFBRSxZQURjO1FBRXpCLFlBQVk7TUFGYSxDQUEzQjtNQUlBLG9CQUFPLHFEQUFQO0lBQ0Q7O0VBUEE7O0VBVUgsTUFBTTFCLE1BQU0sR0FBR2QsTUFBTSxDQUNuQnlDLGNBRG1CLEVBRW5CO0lBQUM1QixLQUFLLEVBQUU7RUFBUixDQUZtQixDQUFyQjtFQUtBaEIsTUFBTSxDQUFDa0IsS0FBUCxlQUNFLG9CQUFDLFFBQUQ7SUFDRSxLQUFLLEVBQUU7TUFDTEMsV0FBVyxFQUFFLE1BQU0sWUFEZDtNQUVMSSxlQUFlLEVBQUUsTUFBTSxFQUZsQjtNQUdMQyxjQUFjLEVBQUUsTUFBTTtJQUhqQjtFQURULGdCQU9FLG9CQUFDLE1BQUQ7SUFBUSxJQUFJLEVBQUMsS0FBYjtJQUFtQixJQUFJLEVBQUMsS0FBeEI7SUFBOEIsWUFBUztFQUF2QyxFQVBGLENBREY7QUFXRCxDQTdCRyxDQUFKO0FBK0JBVixJQUFJLENBQUMseUJBQUQsRUFBNEIsTUFBTTtFQUNwQyxNQUFNRyxNQUFNLEdBQUdkLE1BQU0sQ0FBQyxRQUFELEVBQVc7SUFBQ2EsS0FBSyxFQUFFO0VBQVIsQ0FBWCxDQUFyQjs7RUFDQSxNQUFNK0IsYUFBTixTQUE0QjdDLEtBQUssQ0FBQzJDLFNBQWxDLENBQWdEO0lBRTlDRyxpQkFBaUIsR0FBRztNQUNsQjNCLE1BQU0sQ0FBQyxLQUFLNEIsV0FBTCxZQUE0QkMsaUJBQTdCLENBQU4sQ0FBc0RyQixJQUF0RCxDQUEyRCxJQUEzRDtJQUNEOztJQUVEaUIsTUFBTSxHQUFHO01BQ1Asb0JBQ0Usb0JBQUMsUUFBRDtRQUNFLEtBQUssRUFBRTtVQUNMM0IsV0FBVyxFQUFFLE1BQU0sRUFEZDtVQUVMSSxlQUFlLEVBQUUsTUFBTSxFQUZsQjtVQUdMQyxjQUFjLEVBQUUsTUFBTTtRQUhqQjtNQURULGdCQU9FLG9CQUFDLE1BQUQ7UUFDRSxHQUFHLEVBQUUyQixDQUFDLElBQUk7VUFDUixLQUFLRixXQUFMLEdBQW1CRSxDQUFuQjtRQUNEO01BSEgsRUFQRixDQURGO0lBZUQ7O0VBdEI2Qzs7RUF3QmhEbkQsTUFBTSxDQUFDa0IsS0FBUCxlQUFhLG9CQUFDLGFBQUQsT0FBYjtBQUNELENBM0JHLENBQUo7QUE2QkFKLElBQUksQ0FBQyxrQ0FBRCxFQUFxQyxNQUFNO0VBQzdDLE1BQU1HLE1BQU0sR0FBR2QsTUFBTSxDQUFDLFFBQUQsRUFBVztJQUFDYSxLQUFLLEVBQUU7RUFBUixDQUFYLENBQXJCOztFQUNBLE1BQU0rQixhQUFOLFNBQTRCN0MsS0FBSyxDQUFDMkMsU0FBbEMsQ0FBZ0Q7SUFDOUNJLFdBQVcsZ0JBQUcvQyxLQUFLLENBQUNrRCxTQUFOLEVBQUg7O0lBRVhKLGlCQUFpQixHQUFHO01BQ2xCM0IsTUFBTSxDQUFDLEtBQUs0QixXQUFMLENBQWlCSSxPQUFqQixZQUFvQ0gsaUJBQXJDLENBQU4sQ0FBOERyQixJQUE5RCxDQUFtRSxJQUFuRTtJQUNEOztJQUVEaUIsTUFBTSxHQUFHO01BQ1Asb0JBQ0Usb0JBQUMsUUFBRDtRQUNFLEtBQUssRUFBRTtVQUNMM0IsV0FBVyxFQUFFLE1BQU0sRUFEZDtVQUVMSSxlQUFlLEVBQUUsTUFBTSxFQUZsQjtVQUdMQyxjQUFjLEVBQUUsTUFBTTtRQUhqQjtNQURULGdCQU9FLG9CQUFDLE1BQUQ7UUFBUSxHQUFHLEVBQUUsS0FBS3lCO01BQWxCLEVBUEYsQ0FERjtJQVdEOztFQW5CNkM7O0VBcUJoRGpELE1BQU0sQ0FBQ2tCLEtBQVAsZUFBYSxvQkFBQyxhQUFELE9BQWI7QUFDRCxDQXhCRyxDQUFKO0FBMEJBSixJQUFJLENBQUMsK0JBQUQsRUFBa0MsTUFBTTtFQUMxQyxNQUFNRyxNQUFNLEdBQUdkLE1BQU0sQ0FBQyxRQUFELEVBQVc7SUFBQ2EsS0FBSyxFQUFFO0VBQVIsQ0FBWCxDQUFyQjs7RUFDQSxNQUFNK0IsYUFBYSxHQUFHLE1BQU07SUFDMUIsTUFBTUUsV0FBVyxHQUFHL0MsS0FBSyxDQUFDb0QsTUFBTixDQUFnQyxJQUFoQyxDQUFwQjtJQUNBcEQsS0FBSyxDQUFDcUQsU0FBTixDQUFnQixNQUFNO01BQ3BCbEMsTUFBTSxDQUFDNEIsV0FBVyxDQUFDSSxPQUFaLFlBQStCSCxpQkFBaEMsQ0FBTixDQUF5RHJCLElBQXpELENBQThELElBQTlEO0lBQ0QsQ0FGRCxFQUVHLEVBRkg7SUFHQSxvQkFDRSxvQkFBQyxRQUFEO01BQ0UsS0FBSyxFQUFFO1FBQ0xWLFdBQVcsRUFBRSxNQUFNLEVBRGQ7UUFFTEksZUFBZSxFQUFFLE1BQU0sRUFGbEI7UUFHTEMsY0FBYyxFQUFFLE1BQU07TUFIakI7SUFEVCxnQkFPRSxvQkFBQyxNQUFEO01BQVEsR0FBRyxFQUFFeUI7SUFBYixFQVBGLENBREY7RUFXRCxDQWhCRDs7RUFrQkFqRCxNQUFNLENBQUNrQixLQUFQLGVBQWEsb0JBQUMsYUFBRCxPQUFiO0FBQ0QsQ0FyQkcsQ0FBSjtBQXVCQUosSUFBSSxDQUFDLDhCQUFELEVBQWlDLE1BQU07RUFDekMsTUFBTUcsTUFBTSxHQUFHZCxNQUFNLENBQUMsUUFBRCxFQUFXO0lBQUNhLEtBQUssRUFBRTtFQUFSLENBQVgsQ0FBckI7O0VBQ0EsTUFBTStCLGFBQU4sU0FBNEI3QyxLQUFLLENBQUMyQyxTQUFsQyxDQUFnRDtJQUM5Q0csaUJBQWlCLEdBQUc7TUFDbEIzQixNQUFNLENBQUMsS0FBS21DLElBQUwsQ0FBVUMsUUFBVixZQUE4QlAsaUJBQS9CLENBQU4sQ0FBd0RyQixJQUF4RCxDQUE2RCxJQUE3RDtJQUNEOztJQUNEaUIsTUFBTSxHQUFHO01BQ1Asb0JBQ0Usb0JBQUMsUUFBRDtRQUNFLEtBQUssRUFBRTtVQUNMM0IsV0FBVyxFQUFFLE1BQU0sRUFEZDtVQUVMSSxlQUFlLEVBQUUsTUFBTSxFQUZsQjtVQUdMQyxjQUFjLEVBQUUsTUFBTTtRQUhqQjtNQURULGdCQU9FLG9CQUFDLE1BQUQ7UUFBUSxHQUFHLEVBQUM7TUFBWixFQVBGLENBREY7SUFXRDs7RUFoQjZDOztFQWtCaER4QixNQUFNLENBQUNrQixLQUFQLGVBQWEsb0JBQUMsYUFBRCxPQUFiO0FBQ0QsQ0FyQkcsQ0FBSjtBQXVCQUosSUFBSSxDQUFDLGFBQUQsRUFBZ0IsTUFBTTtFQUN4QixNQUFNRyxNQUFNLEdBQUdkLE1BQU0sQ0FBMkIsUUFBM0IsRUFBcUM7SUFDeERhLEtBQUssRUFBRTtFQURpRCxDQUFyQyxDQUFyQjtFQUdBLE1BQU0wQyxhQUFhLEdBQUdyRCxXQUFXLENBQUNZLE1BQUQsRUFBUzBDLGFBQWEsSUFBSTVCLEtBQUssSUFBSTtJQUNsRVYsTUFBTSxDQUFDVSxLQUFELENBQU4sQ0FBY1QsT0FBZCxDQUFzQjtNQUFDc0MsR0FBRyxFQUFFO0lBQU4sQ0FBdEI7SUFDQSxvQkFDRSxrREFDRSxvQkFBQyxhQUFELEVBQW1CN0IsS0FBbkIsQ0FERixDQURGO0VBS0QsQ0FQZ0MsQ0FBakM7RUFRQSxNQUFNOEIsUUFBUSxHQUFHN0QsTUFBTSxDQUFDa0IsS0FBUCxlQUNmLG9CQUFDLFFBQUQ7SUFDRSxLQUFLLEVBQUU7TUFDTEMsV0FBVyxFQUFFSixLQUFLLElBQUk7UUFDcEJNLE1BQU0sQ0FBQ04sS0FBRCxDQUFOLENBQWNPLE9BQWQsQ0FBc0I7VUFBQ04sS0FBSyxFQUFFO1FBQVIsQ0FBdEI7UUFDQSxPQUFPLEVBQVA7TUFDRCxDQUpJO01BS0xPLGVBQWUsRUFBRSxNQUFNLEVBTGxCO01BTUxDLGNBQWMsRUFBRSxNQUFNO0lBTmpCO0VBRFQsZ0JBVUUsb0JBQUMsYUFBRDtJQUFlLEdBQUcsRUFBQztFQUFuQixFQVZGLENBRGUsQ0FBakI7RUFjQUgsTUFBTSxDQUFDd0MsUUFBUSxDQUFDbEMsSUFBVCxDQUFjLFNBQWQsRUFBeUJDLE1BQTFCLENBQU4sQ0FBd0NDLElBQXhDLENBQTZDLENBQTdDO0VBRUEsTUFBTWlDLG1CQUFtQixHQUFHeEQsU0FBUyxDQUFDb0QsYUFBRCxFQUFnQjtJQUFDMUMsS0FBSyxFQUFFO0VBQVIsQ0FBaEIsQ0FBckM7RUFDQSxNQUFNK0MsUUFBUSxHQUFHL0QsTUFBTSxDQUFDa0IsS0FBUCxlQUNmLG9CQUFDLFFBQUQ7SUFDRSxLQUFLLEVBQUU7TUFDTEMsV0FBVyxFQUFFSixLQUFLLElBQUk7UUFDcEJNLE1BQU0sQ0FBQ04sS0FBRCxDQUFOLENBQWNPLE9BQWQsQ0FBc0I7VUFBQ04sS0FBSyxFQUFFO1FBQVIsQ0FBdEI7UUFDQSxPQUFPLEVBQVA7TUFDRCxDQUpJO01BS0xPLGVBQWUsRUFBRSxNQUFNLEVBTGxCO01BTUxDLGNBQWMsRUFBRSxNQUFNO0lBTmpCO0VBRFQsZ0JBVUUsb0JBQUMsbUJBQUQ7SUFBcUIsR0FBRyxFQUFDO0VBQXpCLEVBVkYsQ0FEZSxDQUFqQjtFQWNBSCxNQUFNLENBQUMwQyxRQUFRLENBQUNwQyxJQUFULENBQWMsU0FBZCxFQUF5QkMsTUFBMUIsQ0FBTixDQUF3Q0MsSUFBeEMsQ0FBNkMsQ0FBN0M7QUFDRCxDQTVDRyxDQUFKO0FBOENBZixJQUFJLENBQUMsaUNBQUQsRUFBb0MsTUFBTTtFQUM1QyxJQUFJa0QsY0FBYyxHQUFHLENBQXJCO0VBRUEsTUFBTWpELEtBQUssR0FBRztJQUFDQyxLQUFLLEVBQUU7RUFBUixDQUFkO0VBQ0EsTUFBTUMsTUFBTSxHQUFHZCxNQUFNLENBQUMsS0FBRCxFQUFRWSxLQUFSLENBQXJCO0VBRUEsTUFBTVUsT0FBTyxHQUFHekIsTUFBTSxDQUFDa0IsS0FBUCxlQUNkLG9CQUFDLFFBQUQ7SUFDRSxLQUFLLEVBQUU7TUFDTEMsV0FBVyxFQUFFLE1BQU0sS0FEZDtNQUVMSSxlQUFlLEVBQUUsTUFBTSxFQUZsQjtNQUdMQyxjQUFjLEVBQUUsTUFBTTtJQUhqQixDQURUO0lBTUUsS0FBSyxFQUFFO01BQ0x5QyxLQUFLLEVBQUUsQ0FBQztRQUFDQyxVQUFEO1FBQWFDO01BQWIsQ0FBRCxLQUE2QjtRQUNsQ0gsY0FBYztRQUNkM0MsTUFBTSxDQUFDNkMsVUFBRCxDQUFOLENBQW1CckMsSUFBbkIsQ0FBd0IsQ0FBeEI7UUFDQVIsTUFBTSxDQUFDLE9BQU84QyxTQUFSLENBQU4sQ0FBeUJ0QyxJQUF6QixDQUE4QixRQUE5QjtRQUNBUixNQUFNLENBQUMsT0FBTzhDLFNBQVMsQ0FBQ0MsS0FBbEIsQ0FBTixDQUErQnZDLElBQS9CLENBQW9DLFFBQXBDO1FBQ0FSLE1BQU0sQ0FBQyxPQUFPOEMsU0FBUyxDQUFDRSxPQUFsQixDQUFOLENBQWlDeEMsSUFBakMsQ0FBc0MsUUFBdEM7UUFDQSxPQUFPLDJCQUFQO01BQ0Q7SUFSSTtFQU5ULGdCQWlCRSxvQkFBQyxNQUFEO0lBQVEsU0FBUyxFQUFDO0VBQWxCLEVBakJGLENBRGMsQ0FBaEI7RUFzQkEsTUFBTUgsSUFBSSxHQUFHRCxPQUFPLENBQUNFLElBQVIsQ0FBYSxLQUFiLENBQWI7RUFDQU4sTUFBTSxDQUFDSyxJQUFJLENBQUNFLE1BQU4sQ0FBTixDQUFvQkMsSUFBcEIsQ0FBeUIsQ0FBekI7RUFDQVIsTUFBTSxDQUFDSyxJQUFJLENBQUNJLFFBQUwsQ0FBYyxtQ0FBZCxDQUFELENBQU4sQ0FBMkRELElBQTNELENBQWdFLElBQWhFO0VBQ0FKLE9BQU8sQ0FBQzZDLE9BQVI7RUFDQTdDLE9BQU8sQ0FBQ1AsS0FBUjtFQUNBTyxPQUFPLENBQUM2QyxPQUFSO0VBQ0FqRCxNQUFNLENBQUMyQyxjQUFELENBQU4sQ0FBdUJuQyxJQUF2QixDQUE0QixDQUE1QjtBQUNELENBbkNHLENBQUo7QUFxQ0FmLElBQUksQ0FBQyx5QkFBRCxFQUE0QixNQUFNO0VBQ3BDLE1BQU1DLEtBQUssR0FBRztJQUFDQyxLQUFLLEVBQUU7RUFBUixDQUFkO0VBQ0EsSUFBSXVELEtBQUssR0FBRyxDQUFaO0VBQ0EsTUFBTXRELE1BQU0sR0FBR2QsTUFBTSxDQUFDLEtBQUQsRUFBUVksS0FBUixDQUFyQjtFQUNBLE1BQU1VLE9BQU8sR0FBR3pCLE1BQU0sQ0FBQ2tCLEtBQVAsZUFDZCxvQkFBQyxRQUFEO0lBQ0UsS0FBSyxFQUFFO01BQ0xDLFdBQVcsRUFBRSxNQUFNO1FBQ2pCb0QsS0FBSztRQUNMLE9BQU8sS0FBUDtNQUNELENBSkk7TUFLTGhELGVBQWUsRUFBRSxNQUFNLEVBTGxCO01BTUxDLGNBQWMsRUFBRSxNQUFNO0lBTmpCLENBRFQ7SUFTRSxLQUFLLEVBQUU7TUFDTHlDLEtBQUssRUFBRSxNQUFNO1FBQ1g1QyxNQUFNLENBQUNrRCxLQUFELENBQU4sQ0FBYzFDLElBQWQsQ0FBbUIsQ0FBbkI7UUFDQSxPQUFPLG9CQUFQO01BQ0Q7SUFKSSxDQVRUO0lBZUUsbUJBQW1CO0VBZnJCLGdCQWlCRSxvQkFBQyxNQUFELE9BakJGLENBRGMsQ0FBaEI7RUFxQkEsTUFBTUgsSUFBSSxHQUFHRCxPQUFPLENBQUNFLElBQVIsQ0FBYSxLQUFiLENBQWI7RUFDQU4sTUFBTSxDQUFDa0QsS0FBRCxDQUFOLENBQWMxQyxJQUFkLENBQW1CLENBQW5CO0VBQ0FSLE1BQU0sQ0FBQ0ssSUFBSSxDQUFDSSxRQUFMLENBQWMsd0JBQWQsQ0FBRCxDQUFOLENBQWdERCxJQUFoRCxDQUFxRCxJQUFyRDtBQUNELENBNUJHLENBQUo7QUE4QkFmLElBQUksQ0FBQyxxQkFBRCxFQUF3QixNQUFNO0VBQ2hDLE1BQU0wRCxRQUFRLEdBQUc7SUFDZkMsR0FBRyxFQUFFO0VBRFUsQ0FBakI7RUFHQSxNQUFNMUQsS0FBSyxHQUFHO0lBQUMyRCxVQUFVLEVBQUVGO0VBQWIsQ0FBZDtFQUNBLE1BQU12RCxNQUFNLEdBQUdkLE1BQU0sQ0FBQyxLQUFELEVBQVFZLEtBQVIsQ0FBckI7RUFDQWYsTUFBTSxDQUFDa0IsS0FBUCxlQUNFLG9CQUFDLFFBQUQ7SUFDRSxLQUFLLEVBQUU7TUFDTEMsV0FBVyxFQUFFQyxDQUFDLElBQUk7UUFDaEJDLE1BQU0sQ0FBQ0QsQ0FBRCxDQUFOLENBQVVFLE9BQVYsQ0FBa0I7VUFDaEJvRCxVQUFVLEVBQUU7UUFESSxDQUFsQjtRQUdBLE9BQU8sRUFBUDtNQUNELENBTkk7TUFPTGxELGNBQWMsRUFBRUosQ0FBQyxJQUFJO1FBQ25CQyxNQUFNLENBQUNELENBQUQsQ0FBTixDQUFVRSxPQUFWLENBQWtCa0QsUUFBbEI7UUFDQSxPQUFPLEtBQVA7TUFDRCxDQVZJO01BV0xqRCxlQUFlLEVBQUUsTUFBTTtJQVhsQjtFQURULGdCQWVFLG9CQUFDLE1BQUQsT0FmRixDQURGO0FBbUJELENBekJHLENBQUo7QUEyQkFULElBQUksQ0FBQyxxQkFBRCxFQUF3QixNQUFNO0VBQ2hDLE1BQU02RCxTQUFTLEdBQUc7SUFDaEJDLElBQUksRUFBRTtNQUFDNUQsS0FBSyxFQUFFO0lBQVIsQ0FEVTtJQUVoQjZELEVBQUUsRUFBRTtNQUFDN0QsS0FBSyxFQUFFO0lBQVI7RUFGWSxDQUFsQjtFQUlBLE1BQU1ELEtBQUssR0FBRztJQUFDK0QsYUFBYSxFQUFFSDtFQUFoQixDQUFkO0VBQ0EsTUFBTTFELE1BQU0sR0FBR2QsTUFBTSxDQUFDLEtBQUQsRUFBUVksS0FBUixDQUFyQjtFQUNBZixNQUFNLENBQUNrQixLQUFQLGVBQ0Usb0JBQUMsUUFBRDtJQUNFLEtBQUssRUFBRTtNQUNMQyxXQUFXLEVBQUVDLENBQUMsSUFBSTtRQUNoQkMsTUFBTSxDQUFDRCxDQUFELENBQU4sQ0FBVUUsT0FBVixDQUFrQjtVQUFDd0QsYUFBYSxFQUFFO1FBQWhCLENBQWxCO1FBQ0EsT0FBTyxFQUFQO01BQ0QsQ0FKSTtNQUtMdkQsZUFBZSxFQUFFSCxDQUFDLElBQUk7UUFDcEJDLE1BQU0sQ0FBQ0QsQ0FBRCxDQUFOLENBQVVFLE9BQVYsQ0FBa0JxRCxTQUFsQjtRQUNBLE9BQU8sS0FBUDtNQUNELENBUkk7TUFTTG5ELGNBQWMsRUFBRSxNQUFNO0lBVGpCO0VBRFQsZ0JBYUUsb0JBQUMsTUFBRCxPQWJGLENBREY7QUFpQkQsQ0F4QkcsQ0FBSjtBQTBCQVYsSUFBSSxDQUFDLHNCQUFELEVBQXlCLE1BQU07RUFDakMsTUFBTWlFLFlBQVksR0FBRzNFLFlBQVksQ0FBQztJQUNoQ08sTUFEZ0M7SUFFaENELGVBRmdDO0lBR2hDZSxPQUFPLEVBQUV1RCxVQUFVLElBQUlqRCxLQUFLLElBQUk7TUFDOUJWLE1BQU0sQ0FBQ1UsS0FBSyxDQUFDNkIsR0FBUCxDQUFOLENBQWtCL0IsSUFBbEIsQ0FBdUIsS0FBdkI7TUFDQSxvQkFBTywrQ0FBUDtJQUNEO0VBTitCLENBQUQsQ0FBakM7RUFRQSxNQUFNWixNQUFNLEdBQUc4RCxZQUFZLENBQXVCLEtBQXZCLEVBQThCO0lBQ3ZEL0QsS0FBSyxFQUFFO0VBRGdELENBQTlCLENBQTNCO0VBR0FoQixNQUFNLENBQUNrQixLQUFQLGVBQ0Usb0JBQUMsUUFBRDtJQUNFLEtBQUssRUFBRTtNQUNMQyxXQUFXLEVBQUUsTUFBTSxFQURkO01BRUxJLGVBQWUsRUFBRSxNQUFNLEVBRmxCO01BR0xDLGNBQWMsRUFBRSxNQUFNO0lBSGpCO0VBRFQsZ0JBT0Usb0JBQUMsTUFBRDtJQUFRLEdBQUcsRUFBQztFQUFaLEVBUEYsQ0FERjtBQVdELENBdkJHLENBQUo7QUF5QkFWLElBQUksQ0FBQyxrQkFBRCxFQUFxQixNQUFNO0VBQzdCLFNBQVNtRSxJQUFULEdBQWdCO0lBQ2QsTUFBTSxDQUFDQyxHQUFELElBQVF6RSxZQUFZLEVBQTFCO0lBQ0EsTUFBTWtDLFNBQVMsR0FBR3VDLEdBQUcsQ0FBQztNQUFDbEUsS0FBSyxFQUFFO0lBQVIsQ0FBRCxDQUFyQjtJQUNBSyxNQUFNLENBQUNzQixTQUFELENBQU4sQ0FBa0JkLElBQWxCLENBQXVCLE1BQXZCO0lBQ0Esb0JBQU87TUFBRyxTQUFTLEVBQUVjO0lBQWQsU0FBUDtFQUNEOztFQUVEM0MsTUFBTSxDQUFDa0IsS0FBUCxlQUNFLG9CQUFDLFFBQUQ7SUFDRSxLQUFLLEVBQUU7TUFDTEMsV0FBVyxFQUFFQyxDQUFDLElBQUk7UUFDaEJDLE1BQU0sQ0FBQ0QsQ0FBRCxDQUFOLENBQVVFLE9BQVYsQ0FBa0I7VUFDaEJOLEtBQUssRUFBRTtRQURTLENBQWxCO1FBR0EsT0FBTyxNQUFQO01BQ0QsQ0FOSTtNQU9MTyxlQUFlLEVBQUUsTUFBTSxFQVBsQjtNQVFMQyxjQUFjLEVBQUUsTUFBTTtJQVJqQjtFQURULGdCQVlFLG9CQUFDLElBQUQsT0FaRixDQURGO0FBZ0JELENBeEJHLENBQUo7QUEwQkFWLElBQUksQ0FBQyx5QkFBRCxFQUE0QixNQUFNO0VBQ3BDLFNBQVNHLE1BQVQsR0FBa0I7SUFDaEIsTUFBTSxDQUFDaUUsR0FBRCxJQUFRekUsWUFBWSxFQUExQjtJQUNBLE1BQU0sQ0FBQzBFLEVBQUQsRUFBS0MsS0FBTCxJQUFjbEYsS0FBSyxDQUFDbUYsUUFBTixDQUFlLEtBQWYsQ0FBcEI7SUFDQSxNQUFNMUMsU0FBUyxHQUFHdUMsR0FBRyxDQUFDO01BQUNsRSxLQUFLLEVBQUU7SUFBUixDQUFELENBQXJCO0lBQ0Esb0JBQ0U7TUFBUSxPQUFPLEVBQUUsTUFBTW9FLEtBQUssQ0FBQyxDQUFDRCxFQUFGLENBQTVCO01BQW1DLFNBQVMsRUFBRXhDO0lBQTlDLFVBREY7RUFLRDs7RUFFRCxJQUFJcUIsY0FBYyxHQUFHLENBQXJCO0VBQ0EsTUFBTXZDLE9BQU8sR0FBR3pCLE1BQU0sQ0FBQ2tCLEtBQVAsZUFDZCxvQkFBQyxRQUFEO0lBQ0UsS0FBSyxFQUFFO01BQ0xDLFdBQVcsRUFBRSxNQUFNLEtBRGQ7TUFFTEksZUFBZSxFQUFFLE1BQU0sRUFGbEI7TUFHTEMsY0FBYyxFQUFFLE1BQU07SUFIakIsQ0FEVDtJQU1FLEtBQUssRUFBRTtNQUNMeUMsS0FBSyxFQUFFLE1BQU07UUFDWEQsY0FBYztRQUNkLE9BQVEsV0FBVUEsY0FBZSxFQUFqQztNQUNEO0lBSkk7RUFOVCxnQkFhRSxvQkFBQyxNQUFELE9BYkYsQ0FEYyxDQUFoQjtFQWtCQSxNQUFNc0IsTUFBTSxHQUFHN0QsT0FBTyxDQUFDRSxJQUFSLENBQWEsUUFBYixDQUFmO0VBQ0FOLE1BQU0sQ0FBQ2lFLE1BQU0sQ0FBQ3hELFFBQVAsQ0FBZ0IsZUFBaEIsQ0FBRCxDQUFOLENBQXlDRCxJQUF6QyxDQUE4QyxJQUE5QztFQUNBeUQsTUFBTSxDQUFDQyxRQUFQLENBQWdCLE9BQWhCO0VBQ0FsRSxNQUFNLENBQUNpRSxNQUFNLENBQUN4RCxRQUFQLENBQWdCLGVBQWhCLENBQUQsQ0FBTixDQUF5Q0QsSUFBekMsQ0FBOEMsSUFBOUM7RUFDQVIsTUFBTSxDQUFDMkMsY0FBRCxDQUFOLENBQXVCbkMsSUFBdkIsQ0FBNEIsQ0FBNUI7QUFDRCxDQXBDRyxDQUFKO0FBc0NBZixJQUFJLENBQUMsY0FBRCxFQUFpQixNQUFNO0VBQ3pCLE1BQU0wRSxXQUFXLEdBQUdDLE9BQU8sQ0FBQ0MsSUFBNUIsQ0FEeUIsQ0FDUzs7RUFFakNELE9BQUQsQ0FBaUJDLElBQWpCLEdBQXdCckIsT0FBTyxJQUFJO0lBQ2pDaEQsTUFBTSxDQUFDZ0QsT0FBTyxDQUFDc0IsS0FBUixDQUFjLElBQWQsRUFBb0IsQ0FBcEIsQ0FBRCxDQUFOLENBQStCOUQsSUFBL0IsQ0FDRSxxREFERjtFQUdELENBSkQ7O0VBS0EsTUFBTVosTUFBTSxHQUFHZCxNQUFNLENBQUMsS0FBRCxFQUFRO0lBQzNCYSxLQUFLLEVBQUU7RUFEb0IsQ0FBUixDQUFyQjtFQUdBaEIsTUFBTSxDQUFDa0IsS0FBUCxlQUFhLG9CQUFDLE1BQUQsT0FBYjtFQUVDdUUsT0FBRCxDQUFpQkMsSUFBakIsR0FBd0JGLFdBQXhCO0FBQ0QsQ0FkRyxDQUFKIn0=