function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

/* eslint-env browser */

/* eslint-disable no-unused-vars, no-redeclare, no-shadow */
import * as React from "react";
import { driver, getInitialStyle } from "styletron-standard";
import { DebugEngine } from "./dev-tool";
export { DebugEngine };
const noopEngine = {
  renderStyle: () => "",
  renderKeyframes: () => "",
  renderFontFace: () => ""
};
const StyletronContext = /*#__PURE__*/React.createContext(noopEngine);
const HydrationContext = /*#__PURE__*/React.createContext(false);
const DebugEngineContext = /*#__PURE__*/React.createContext(undefined); //todo: theme context removed

class DevProvider extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      hydrating: Boolean(props.debugAfterHydration)
    };
  }

  componentDidMount() {
    if (false) {
      if (this.state.hydrating === true) {
        this.setState({
          hydrating: false
        });
      }
    }
  }

  render() {
    return /*#__PURE__*/React.createElement(StyletronContext.Provider, {
      value: this.props.value
    }, /*#__PURE__*/React.createElement(DebugEngineContext.Provider, {
      value: this.props.debug
    }, /*#__PURE__*/React.createElement(HydrationContext.Provider, {
      value: this.state.hydrating
    }, this.props.children)));
  }

}

export const Provider = false && process.env.NODE_ENV !== "production" ? DevProvider : StyletronContext.Provider;

if (false && process.env.NODE_ENV !== "production" && !window.__STYLETRON_DEVTOOLS__) {
  setupDevtoolsExtension();
}

function checkNoopEngine(engine) {
  // if no engine provided, we default to no-op, handy for tests
  // however, print a warning in other envs
  if (process.env.NODE_ENV !== "test") {
    engine === noopEngine && // eslint-disable-next-line no-console
    console.warn(process.env.NODE_ENV !== "production" ? `
Styletron has been switched to a no-op (test) mode.

A Styletron styled component was rendered, but no Styletron engine instance was provided in React context.

Did you forget to provide a Styletron engine instance to React context via using the Styletron provider component?

Note: Providers and Consumers must come from the exact same React.createContext call to work.
If your app has multiple instances of the "styletron-react" package in your node_module tree,
your Provider may be coming from a different React.createContext call, which means the styled components
will not recieve the provided engine instance. This scenario can arise, for example, when using "npm link".
` : `Styletron Provider is not set up. Defaulting to no-op.`);
  }
}

export function useStyletron() {
  const styletronEngine = React.useContext(StyletronContext);
  const debugEngine = React.useContext(DebugEngineContext);
  const hydrating = React.useContext(HydrationContext);
  checkNoopEngine(styletronEngine);
  const debugClassName = React.useRef("");
  const prevDebugClassNameDeps = React.useRef([]);
  return [function css(style) {
    const className = driver(style, styletronEngine);

    if (!(false && process.env.NODE_ENV !== "production")) {
      return className;
    }

    const {
      stack,
      message
    } = new Error("stacktrace source");
    const nextDeps = [debugEngine, hydrating];

    if (prevDebugClassNameDeps.current[0] !== nextDeps[0] || prevDebugClassNameDeps.current[1] !== nextDeps[1]) {
      if (debugEngine && !hydrating) {
        debugClassName.current = debugEngine.debug({
          stackInfo: {
            stack,
            message
          },
          stackIndex: 1
        });
      }

      prevDebugClassNameDeps.current = nextDeps;
    }

    if (debugClassName.current) {
      return `${debugClassName.current} ${className}`;
    }

    return className;
  }];
}
export function createStyled({
  getInitialStyle,
  driver,
  wrapper
}) {
  function styled(base, styleArg) {
    if (process.env.NODE_ENV !== "production") {
      if (base.__STYLETRON__) {
        /* eslint-disable no-console */
        console.warn("It appears you are passing a styled component into `styled`.");
        console.warn("For composition with existing styled components, use `withStyle` or `withTransform` instead.");
        /* eslint-enable no-console */
      }
    }

    const baseStyletron = {
      reducers: [],
      base: base,
      driver,
      getInitialStyle,
      wrapper
    };

    if (false && process.env.NODE_ENV !== "production") {
      addDebugMetadata(baseStyletron, 2);
    }

    return createStyledElementComponent(autoComposeShallow(baseStyletron, styleArg));
  }

  return styled;
}
export const styled = createStyled({
  getInitialStyle,
  driver,
  wrapper: Component => Component
});
export const withTransform = (component, transformer) => {
  const styletron = component.__STYLETRON__;

  if (false && process.env.NODE_ENV !== "production") {
    addDebugMetadata(styletron, 2);
  }

  return createStyledElementComponent(composeDynamic(styletron, transformer));
};
export const withStyleDeep = (component, styleArg) => {
  // @ts-ignore
  const styletron = component.__STYLETRON__;

  if (process.env.NODE_ENV !== "production") {
    if (!styletron) {
      /* eslint-disable no-console */
      console.warn("The first parameter to `withStyle` must be a styled component (without extra wrappers).");
      /* eslint-enable no-console */
    }
  }

  if (false && process.env.NODE_ENV !== "production") {
    addDebugMetadata(styletron, 2);
    return createStyledElementComponent(addExtension(autoComposeDeep(styletron, styleArg), component, styleArg));
  } else {
    return createStyledElementComponent(autoComposeDeep(styletron, styleArg));
  }
};
export const withStyle = withStyleDeep;
export const withWrapper = (component, wrapper) => {
  const styletron = component.__STYLETRON__;

  if (process.env.NODE_ENV !== "production") {
    if (!styletron) {
      /* eslint-disable no-console */
      console.warn("The first parameter to `withWrapper` must be a styled component (without extra wrappers).");
      /* eslint-enable no-console */
    }
  }

  const composed = {
    getInitialStyle: styletron.getInitialStyle,
    base: styletron.base,
    driver: styletron.driver,
    wrapper: wrapper,
    reducers: styletron.reducers
  };

  if (false && process.env.NODE_ENV !== "production") {
    addDebugMetadata(composed, 2);
  }

  return createStyledElementComponent(composed);
};
export function autoComposeShallow(styletron, styleArg) {
  if (typeof styleArg === "function") {
    return dynamicComposeShallow(styletron, styleArg);
  }

  return staticComposeShallow(styletron, styleArg);
}

function addExtension(composed, component, styleArg) {
  return { ...composed,
    ext: {
      with: styleArg,
      name: component.displayName,
      base: component.__STYLETRON__.base,
      getInitialStyle: component.__STYLETRON__.reducers.length ? component.__STYLETRON__.reducers[0].reducer : component.__STYLETRON__.getInitialStyle
    }
  };
}

export function autoComposeDeep(styletron, styleArg) {
  if (typeof styleArg === "function") {
    return dynamicComposeDeep(styletron, styleArg);
  }

  return staticComposeDeep(styletron, styleArg);
}
export function staticComposeShallow(styletron, style) {
  return composeStatic(styletron, createShallowMergeReducer(style));
}
export function staticComposeDeep(styletron, style) {
  return composeStatic(styletron, createDeepMergeReducer(style));
}
export function dynamicComposeShallow(styletron, styleFn) {
  return composeDynamic(styletron, (style, props) => shallowMerge(style, styleFn(props)));
}
export function dynamicComposeDeep(styletron, styleFn) {
  return composeDynamic(styletron, (style, props) => deepMerge(style, styleFn(props)));
}
export function createShallowMergeReducer(style) {
  return {
    reducer: inputStyle => shallowMerge(inputStyle, style),
    assignmentCommutative: true,
    factory: createShallowMergeReducer,
    style: style
  };
}
export function createDeepMergeReducer(style) {
  return {
    reducer: inputStyle => deepMerge(inputStyle, style),
    assignmentCommutative: true,
    factory: createDeepMergeReducer,
    style: style
  };
}
export function composeStatic(styletron, reducerContainer) {
  if (styletron.reducers.length === 0) {
    const style = reducerContainer.reducer(styletron.getInitialStyle());
    const result = {
      reducers: styletron.reducers,
      base: styletron.base,
      driver: styletron.driver,
      wrapper: styletron.wrapper,
      getInitialStyle: () => style
    };

    if (false && process.env.NODE_ENV !== "production") {
      result.debug = styletron.debug;
    }

    return result;
  } else {
    const last = styletron.reducers[0];

    if (last.assignmentCommutative === true && reducerContainer.assignmentCommutative === true) {
      const composed = reducerContainer.reducer(last.style);
      const result = {
        getInitialStyle: styletron.getInitialStyle,
        base: styletron.base,
        driver: styletron.driver,
        wrapper: styletron.wrapper,
        reducers: [last.factory(composed)].concat(styletron.reducers.slice(1))
      };

      if (false && process.env.NODE_ENV !== "production") {
        result.debug = styletron.debug;
      }

      return result;
    }

    return composeDynamic(styletron, reducerContainer.reducer);
  }
}
export function composeDynamic(styletron, reducer) {
  const composed = {
    getInitialStyle: styletron.getInitialStyle,
    base: styletron.base,
    driver: styletron.driver,
    wrapper: styletron.wrapper,
    // @ts-ignore
    reducers: [{
      assignmentCommutative: false,
      reducer
    }].concat(styletron.reducers)
  };

  if (false && process.env.NODE_ENV !== "production") {
    composed.debug = styletron.debug;
  }

  return composed;
}
export function createStyledElementComponent(styletron) {
  const {
    reducers,
    base,
    driver,
    wrapper,
    getInitialStyle,
    ext
  } = styletron;

  if (false && process.env.NODE_ENV !== "production") {
    var debugStackInfo, debugStackIndex;

    if (styletron.debug) {
      debugStackInfo = styletron.debug.stackInfo;
      debugStackIndex = styletron.debug.stackIndex;
    }
  }

  if (false && process.env.NODE_ENV !== "production") {
    var debugClassName;
  }

  const StyledElement = /*#__PURE__*/React.forwardRef((props, ref) => {
    const styletron = React.useContext(StyletronContext);
    const debugEngine = React.useContext(DebugEngineContext);
    const hydrating = React.useContext(HydrationContext);
    checkNoopEngine(styletron);
    const elementProps = omitPrefixedKeys(props);
    let style = resolveStyle(getInitialStyle, reducers, props);

    if (props.$style) {
      if (typeof props.$style === "function") {
        style = deepMerge(style, props.$style(props));
      } else {
        style = deepMerge(style, props.$style);
      }
    }

    const styleClassString = driver(style, styletron);
    const Element = props.$as ? props.$as : base;
    elementProps.className = props.className ? `${props.className} ${styleClassString}` : styleClassString;

    if (false && process.env.NODE_ENV !== "production" && debugEngine && !hydrating) {
      if (!debugClassName) {
        debugClassName = debugEngine.debug({
          stackInfo: debugStackInfo,
          stackIndex: debugStackIndex
        });
      }

      const joined = `${debugClassName} ${elementProps.className}`;
      elementProps.className = joined;
    }

    if (false && process.env.NODE_ENV !== "production" && window.__STYLETRON_DEVTOOLS__) {
      window.__STYLETRON_DEVTOOLS__.stylesMap.set(elementProps.className, style);

      if (ext) {
        window.__STYLETRON_DEVTOOLS__.extensionsMap.set(elementProps.className, {
          base: ext.base,
          displayName: ext.name,
          initialStyles: ext.getInitialStyle({}, props),
          styleOverrides: typeof ext.with === "function" ? ext.with(props) : ext.with
        });
      }
    }

    if (props.$ref) {
      // eslint-disable-next-line no-console
      console.warn("The prop `$ref` has been deprecated. Use `ref` instead. Refs are now forwarded with React.forwardRef.");
    }

    return /*#__PURE__*/React.createElement(Element, _extends({}, elementProps, {
      ref: ref || props.$ref
    }));
  });
  const Wrapped = wrapper(StyledElement);
  Wrapped.__STYLETRON__ = {
    base,
    reducers,
    driver,
    wrapper,
    getInitialStyle
  };

  if (process.env.NODE_ENV !== "production") {
    let displayName;

    if (typeof base === "string") {
      displayName = base;
    } else if (base.displayName) {
      displayName = base.displayName;
    } else if (base.name) {
      displayName = base.name;
    } else {
      displayName = "Unknown";
    }

    Wrapped.displayName = `Styled(${displayName})`;
  }

  return Wrapped;
} // Utility functions

export function resolveStyle(getInitialStyle, reducers, props) {
  let result = getInitialStyle();
  let i = reducers.length;

  while (i--) {
    // Cast to allow passing unused props param in case of static reducer
    const reducer = reducers[i].reducer;
    result = reducer(result, props);
  }

  return result;
}

function isObject(x) {
  return typeof x === "object" && x !== null;
}

function omitPrefixedKeys(source) {
  const result = {};

  for (const key in source) {
    if (key[0] !== "$") {
      result[key] = source[key];
    }
  }

  return result;
}

function deepMerge(a, b) {
  const result = assign({}, a);

  for (const key in b) {
    const val = b[key];

    if (isObject(val) && isObject(a[key])) {
      result[key] = deepMerge(a[key], val);
    } else {
      result[key] = val;
    }
  }

  return result;
}

function shallowMerge(a, b) {
  return assign(assign({}, a), b);
}

function assign(target, source) {
  for (const key in source) {
    target[key] = source[key];
  }

  return target;
}
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJSZWFjdCIsImRyaXZlciIsImdldEluaXRpYWxTdHlsZSIsIkRlYnVnRW5naW5lIiwibm9vcEVuZ2luZSIsInJlbmRlclN0eWxlIiwicmVuZGVyS2V5ZnJhbWVzIiwicmVuZGVyRm9udEZhY2UiLCJTdHlsZXRyb25Db250ZXh0IiwiY3JlYXRlQ29udGV4dCIsIkh5ZHJhdGlvbkNvbnRleHQiLCJEZWJ1Z0VuZ2luZUNvbnRleHQiLCJ1bmRlZmluZWQiLCJEZXZQcm92aWRlciIsIkNvbXBvbmVudCIsImNvbnN0cnVjdG9yIiwicHJvcHMiLCJzdGF0ZSIsImh5ZHJhdGluZyIsIkJvb2xlYW4iLCJkZWJ1Z0FmdGVySHlkcmF0aW9uIiwiY29tcG9uZW50RGlkTW91bnQiLCJzZXRTdGF0ZSIsInJlbmRlciIsInZhbHVlIiwiZGVidWciLCJjaGlsZHJlbiIsIlByb3ZpZGVyIiwid2luZG93IiwiX19TVFlMRVRST05fREVWVE9PTFNfXyIsInNldHVwRGV2dG9vbHNFeHRlbnNpb24iLCJjaGVja05vb3BFbmdpbmUiLCJlbmdpbmUiLCJwcm9jZXNzIiwiZW52IiwiTk9ERV9FTlYiLCJjb25zb2xlIiwid2FybiIsInVzZVN0eWxldHJvbiIsInN0eWxldHJvbkVuZ2luZSIsInVzZUNvbnRleHQiLCJkZWJ1Z0VuZ2luZSIsImRlYnVnQ2xhc3NOYW1lIiwidXNlUmVmIiwicHJldkRlYnVnQ2xhc3NOYW1lRGVwcyIsImNzcyIsInN0eWxlIiwiY2xhc3NOYW1lIiwic3RhY2siLCJtZXNzYWdlIiwiRXJyb3IiLCJuZXh0RGVwcyIsImN1cnJlbnQiLCJzdGFja0luZm8iLCJzdGFja0luZGV4IiwiY3JlYXRlU3R5bGVkIiwid3JhcHBlciIsInN0eWxlZCIsImJhc2UiLCJzdHlsZUFyZyIsIl9fU1RZTEVUUk9OX18iLCJiYXNlU3R5bGV0cm9uIiwicmVkdWNlcnMiLCJhZGREZWJ1Z01ldGFkYXRhIiwiY3JlYXRlU3R5bGVkRWxlbWVudENvbXBvbmVudCIsImF1dG9Db21wb3NlU2hhbGxvdyIsIndpdGhUcmFuc2Zvcm0iLCJjb21wb25lbnQiLCJ0cmFuc2Zvcm1lciIsInN0eWxldHJvbiIsImNvbXBvc2VEeW5hbWljIiwid2l0aFN0eWxlRGVlcCIsImFkZEV4dGVuc2lvbiIsImF1dG9Db21wb3NlRGVlcCIsIndpdGhTdHlsZSIsIndpdGhXcmFwcGVyIiwiY29tcG9zZWQiLCJkeW5hbWljQ29tcG9zZVNoYWxsb3ciLCJzdGF0aWNDb21wb3NlU2hhbGxvdyIsImV4dCIsIndpdGgiLCJuYW1lIiwiZGlzcGxheU5hbWUiLCJsZW5ndGgiLCJyZWR1Y2VyIiwiZHluYW1pY0NvbXBvc2VEZWVwIiwic3RhdGljQ29tcG9zZURlZXAiLCJjb21wb3NlU3RhdGljIiwiY3JlYXRlU2hhbGxvd01lcmdlUmVkdWNlciIsImNyZWF0ZURlZXBNZXJnZVJlZHVjZXIiLCJzdHlsZUZuIiwic2hhbGxvd01lcmdlIiwiZGVlcE1lcmdlIiwiaW5wdXRTdHlsZSIsImFzc2lnbm1lbnRDb21tdXRhdGl2ZSIsImZhY3RvcnkiLCJyZWR1Y2VyQ29udGFpbmVyIiwicmVzdWx0IiwibGFzdCIsImNvbmNhdCIsInNsaWNlIiwiZGVidWdTdGFja0luZm8iLCJkZWJ1Z1N0YWNrSW5kZXgiLCJTdHlsZWRFbGVtZW50IiwiZm9yd2FyZFJlZiIsInJlZiIsImVsZW1lbnRQcm9wcyIsIm9taXRQcmVmaXhlZEtleXMiLCJyZXNvbHZlU3R5bGUiLCIkc3R5bGUiLCJzdHlsZUNsYXNzU3RyaW5nIiwiRWxlbWVudCIsIiRhcyIsImpvaW5lZCIsInN0eWxlc01hcCIsInNldCIsImV4dGVuc2lvbnNNYXAiLCJpbml0aWFsU3R5bGVzIiwic3R5bGVPdmVycmlkZXMiLCIkcmVmIiwiV3JhcHBlZCIsImkiLCJpc09iamVjdCIsIngiLCJzb3VyY2UiLCJrZXkiLCJhIiwiYiIsImFzc2lnbiIsInZhbCIsInRhcmdldCJdLCJzb3VyY2VzIjpbInNyYy9pbmRleC50c3giXSwic291cmNlc0NvbnRlbnQiOlsiLyogZXNsaW50LWVudiBicm93c2VyICovXG4vKiBlc2xpbnQtZGlzYWJsZSBuby11bnVzZWQtdmFycywgbm8tcmVkZWNsYXJlLCBuby1zaGFkb3cgKi9cblxuZGVjbGFyZSB2YXIgX19ERVZfXzogYm9vbGVhbjtcblxuZGVjbGFyZSB2YXIgX19CUk9XU0VSX186IGJvb2xlYW47XG5kZWNsYXJlIGdsb2JhbCB7XG4gIGludGVyZmFjZSBXaW5kb3cge1xuICAgIF9fU1RZTEVUUk9OX0RFVlRPT0xTX186IGFueTtcbiAgfVxufVxuXG5kZWNsYXJlIHZhciBwcm9jZXNzOiBhbnk7XG5cbmltcG9ydCAqIGFzIFJlYWN0IGZyb20gXCJyZWFjdFwiO1xuaW1wb3J0IHtcbiAgZHJpdmVyLFxuICBnZXRJbml0aWFsU3R5bGUsXG4gIHR5cGUgU3RhbmRhcmRFbmdpbmUsXG4gIHR5cGUgU3R5bGVPYmplY3QsXG59IGZyb20gXCJzdHlsZXRyb24tc3RhbmRhcmRcIjtcblxuaW1wb3J0IHR5cGUge1xuICBTdHlsZXRyb24sXG4gIFN0eWxldHJvbkNvbXBvbmVudCxcbiAgUmVkdWNlckNvbnRhaW5lcixcbiAgQXNzaWdubWVudENvbW11dGF0aXZlUmVkdWNlckNvbnRhaW5lcixcbiAgTm9uQXNzaWdubWVudENvbW11dGF0aXZlUmVkdWNlckNvbnRhaW5lcixcbiAgU3R5bGVkRm4sXG4gIFdpdGhTdHlsZUZuLFxuICBXaXRoVHJhbnNmb3JtRm4sXG4gIFdpdGhXcmFwcGVyRm4sXG4gIFN0eWxldHJvblByb3BzLFxufSBmcm9tIFwiLi90eXBlc1wiO1xuaW1wb3J0IHtcbiAgYWRkRGVidWdNZXRhZGF0YSxcbiAgc2V0dXBEZXZ0b29sc0V4dGVuc2lvbixcbiAgRGVidWdFbmdpbmUsXG59IGZyb20gXCIuL2Rldi10b29sXCI7XG5cbmV4cG9ydCB7RGVidWdFbmdpbmV9O1xuZXhwb3J0IHR5cGUge1N0eWxlT2JqZWN0fTtcbmV4cG9ydCB0eXBlIHtTdHlsZXRyb25Qcm9wc307XG5leHBvcnQgdHlwZSB7U3R5bGV0cm9uQ29tcG9uZW50fTtcblxuY29uc3Qgbm9vcEVuZ2luZSA9IHtcbiAgcmVuZGVyU3R5bGU6ICgpID0+IFwiXCIsXG4gIHJlbmRlcktleWZyYW1lczogKCkgPT4gXCJcIixcbiAgcmVuZGVyRm9udEZhY2U6ICgpID0+IFwiXCIsXG59O1xuXG5jb25zdCBTdHlsZXRyb25Db250ZXh0ID0gUmVhY3QuY3JlYXRlQ29udGV4dDxTdGFuZGFyZEVuZ2luZT4obm9vcEVuZ2luZSk7XG5jb25zdCBIeWRyYXRpb25Db250ZXh0ID0gUmVhY3QuY3JlYXRlQ29udGV4dChmYWxzZSk7XG5jb25zdCBEZWJ1Z0VuZ2luZUNvbnRleHQgPSBSZWFjdC5jcmVhdGVDb250ZXh0PFxuICBJbnN0YW5jZVR5cGU8dHlwZW9mIERlYnVnRW5naW5lPiB8IHVuZGVmaW5lZFxuPih1bmRlZmluZWQpO1xuLy90b2RvOiB0aGVtZSBjb250ZXh0IHJlbW92ZWRcblxudHlwZSBEZXZQcm92aWRlclByb3BzID0ge1xuICBjaGlsZHJlbjogUmVhY3QuUmVhY3ROb2RlO1xuICB2YWx1ZTogU3RhbmRhcmRFbmdpbmU7XG4gIGRlYnVnQWZ0ZXJIeWRyYXRpb24/OiBib29sZWFuO1xuICBkZWJ1Zz86IGFueTtcbn07XG5cbmNsYXNzIERldlByb3ZpZGVyIGV4dGVuZHMgUmVhY3QuQ29tcG9uZW50PFxuICBEZXZQcm92aWRlclByb3BzLFxuICB7XG4gICAgaHlkcmF0aW5nOiBib29sZWFuO1xuICB9XG4+IHtcbiAgY29uc3RydWN0b3IocHJvcHM6IERldlByb3ZpZGVyUHJvcHMpIHtcbiAgICBzdXBlcihwcm9wcyk7XG4gICAgdGhpcy5zdGF0ZSA9IHtcbiAgICAgIGh5ZHJhdGluZzogQm9vbGVhbihwcm9wcy5kZWJ1Z0FmdGVySHlkcmF0aW9uKSxcbiAgICB9O1xuICB9XG5cbiAgY29tcG9uZW50RGlkTW91bnQoKSB7XG4gICAgaWYgKF9fQlJPV1NFUl9fKSB7XG4gICAgICBpZiAodGhpcy5zdGF0ZS5oeWRyYXRpbmcgPT09IHRydWUpIHtcbiAgICAgICAgdGhpcy5zZXRTdGF0ZSh7XG4gICAgICAgICAgaHlkcmF0aW5nOiBmYWxzZSxcbiAgICAgICAgfSk7XG4gICAgICB9XG4gICAgfVxuICB9XG5cbiAgcmVuZGVyKCkge1xuICAgIHJldHVybiAoXG4gICAgICA8U3R5bGV0cm9uQ29udGV4dC5Qcm92aWRlciB2YWx1ZT17dGhpcy5wcm9wcy52YWx1ZX0+XG4gICAgICAgIDxEZWJ1Z0VuZ2luZUNvbnRleHQuUHJvdmlkZXIgdmFsdWU9e3RoaXMucHJvcHMuZGVidWd9PlxuICAgICAgICAgIDxIeWRyYXRpb25Db250ZXh0LlByb3ZpZGVyIHZhbHVlPXt0aGlzLnN0YXRlLmh5ZHJhdGluZ30+XG4gICAgICAgICAgICB7dGhpcy5wcm9wcy5jaGlsZHJlbn1cbiAgICAgICAgICA8L0h5ZHJhdGlvbkNvbnRleHQuUHJvdmlkZXI+XG4gICAgICAgIDwvRGVidWdFbmdpbmVDb250ZXh0LlByb3ZpZGVyPlxuICAgICAgPC9TdHlsZXRyb25Db250ZXh0LlByb3ZpZGVyPlxuICAgICk7XG4gIH1cbn1cblxuZXhwb3J0IGNvbnN0IFByb3ZpZGVyID1cbiAgX19CUk9XU0VSX18gJiYgX19ERVZfXyA/IERldlByb3ZpZGVyIDogU3R5bGV0cm9uQ29udGV4dC5Qcm92aWRlcjtcblxuaWYgKF9fQlJPV1NFUl9fICYmIF9fREVWX18gJiYgIXdpbmRvdy5fX1NUWUxFVFJPTl9ERVZUT09MU19fKSB7XG4gIHNldHVwRGV2dG9vbHNFeHRlbnNpb24oKTtcbn1cblxudHlwZSBjcmVhdGVTdHlsZWRPcHRzID0ge1xuICBnZXRJbml0aWFsU3R5bGU6ICgpID0+IFN0eWxlT2JqZWN0O1xuICBkcml2ZXI6IHR5cGVvZiBkcml2ZXI7XG4gIHdyYXBwZXI6IChmYzogUmVhY3QuRkM8YW55PikgPT4gUmVhY3QuQ29tcG9uZW50VHlwZTxhbnk+O1xufTtcblxuZnVuY3Rpb24gY2hlY2tOb29wRW5naW5lKGVuZ2luZTogU3RhbmRhcmRFbmdpbmUpIHtcbiAgLy8gaWYgbm8gZW5naW5lIHByb3ZpZGVkLCB3ZSBkZWZhdWx0IHRvIG5vLW9wLCBoYW5keSBmb3IgdGVzdHNcbiAgLy8gaG93ZXZlciwgcHJpbnQgYSB3YXJuaW5nIGluIG90aGVyIGVudnNcbiAgaWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInRlc3RcIikge1xuICAgIGVuZ2luZSA9PT0gbm9vcEVuZ2luZSAmJlxuICAgICAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIG5vLWNvbnNvbGVcbiAgICAgIGNvbnNvbGUud2FybihcbiAgICAgICAgX19ERVZfX1xuICAgICAgICAgID8gYFxuU3R5bGV0cm9uIGhhcyBiZWVuIHN3aXRjaGVkIHRvIGEgbm8tb3AgKHRlc3QpIG1vZGUuXG5cbkEgU3R5bGV0cm9uIHN0eWxlZCBjb21wb25lbnQgd2FzIHJlbmRlcmVkLCBidXQgbm8gU3R5bGV0cm9uIGVuZ2luZSBpbnN0YW5jZSB3YXMgcHJvdmlkZWQgaW4gUmVhY3QgY29udGV4dC5cblxuRGlkIHlvdSBmb3JnZXQgdG8gcHJvdmlkZSBhIFN0eWxldHJvbiBlbmdpbmUgaW5zdGFuY2UgdG8gUmVhY3QgY29udGV4dCB2aWEgdXNpbmcgdGhlIFN0eWxldHJvbiBwcm92aWRlciBjb21wb25lbnQ/XG5cbk5vdGU6IFByb3ZpZGVycyBhbmQgQ29uc3VtZXJzIG11c3QgY29tZSBmcm9tIHRoZSBleGFjdCBzYW1lIFJlYWN0LmNyZWF0ZUNvbnRleHQgY2FsbCB0byB3b3JrLlxuSWYgeW91ciBhcHAgaGFzIG11bHRpcGxlIGluc3RhbmNlcyBvZiB0aGUgXCJzdHlsZXRyb24tcmVhY3RcIiBwYWNrYWdlIGluIHlvdXIgbm9kZV9tb2R1bGUgdHJlZSxcbnlvdXIgUHJvdmlkZXIgbWF5IGJlIGNvbWluZyBmcm9tIGEgZGlmZmVyZW50IFJlYWN0LmNyZWF0ZUNvbnRleHQgY2FsbCwgd2hpY2ggbWVhbnMgdGhlIHN0eWxlZCBjb21wb25lbnRzXG53aWxsIG5vdCByZWNpZXZlIHRoZSBwcm92aWRlZCBlbmdpbmUgaW5zdGFuY2UuIFRoaXMgc2NlbmFyaW8gY2FuIGFyaXNlLCBmb3IgZXhhbXBsZSwgd2hlbiB1c2luZyBcIm5wbSBsaW5rXCIuXG5gXG4gICAgICAgICAgOiBgU3R5bGV0cm9uIFByb3ZpZGVyIGlzIG5vdCBzZXQgdXAuIERlZmF1bHRpbmcgdG8gbm8tb3AuYCxcbiAgICAgICk7XG4gIH1cbn1cblxuZXhwb3J0IGZ1bmN0aW9uIHVzZVN0eWxldHJvbigpOiBbKHN0eWxlOiBTdHlsZU9iamVjdCkgPT4gc3RyaW5nXSB7XG4gIGNvbnN0IHN0eWxldHJvbkVuZ2luZTogU3RhbmRhcmRFbmdpbmUgPSBSZWFjdC51c2VDb250ZXh0KFN0eWxldHJvbkNvbnRleHQpO1xuICBjb25zdCBkZWJ1Z0VuZ2luZSA9IFJlYWN0LnVzZUNvbnRleHQoRGVidWdFbmdpbmVDb250ZXh0KTtcbiAgY29uc3QgaHlkcmF0aW5nID0gUmVhY3QudXNlQ29udGV4dChIeWRyYXRpb25Db250ZXh0KTtcbiAgY2hlY2tOb29wRW5naW5lKHN0eWxldHJvbkVuZ2luZSk7XG5cbiAgY29uc3QgZGVidWdDbGFzc05hbWUgPSBSZWFjdC51c2VSZWY8c3RyaW5nIHwgdW5kZWZpbmVkPihcIlwiKTtcbiAgY29uc3QgcHJldkRlYnVnQ2xhc3NOYW1lRGVwcyA9IFJlYWN0LnVzZVJlZihbXSk7XG5cbiAgcmV0dXJuIFtcbiAgICBmdW5jdGlvbiBjc3Moc3R5bGU6IFN0eWxlT2JqZWN0KSB7XG4gICAgICBjb25zdCBjbGFzc05hbWUgPSBkcml2ZXIoc3R5bGUsIHN0eWxldHJvbkVuZ2luZSk7XG4gICAgICBpZiAoIShfX0JST1dTRVJfXyAmJiBfX0RFVl9fKSkge1xuICAgICAgICByZXR1cm4gY2xhc3NOYW1lO1xuICAgICAgfVxuICAgICAgY29uc3Qge3N0YWNrLCBtZXNzYWdlfSA9IG5ldyBFcnJvcihcInN0YWNrdHJhY2Ugc291cmNlXCIpO1xuXG4gICAgICBjb25zdCBuZXh0RGVwcyA9IFtkZWJ1Z0VuZ2luZSwgaHlkcmF0aW5nXTtcbiAgICAgIGlmIChcbiAgICAgICAgcHJldkRlYnVnQ2xhc3NOYW1lRGVwcy5jdXJyZW50WzBdICE9PSBuZXh0RGVwc1swXSB8fFxuICAgICAgICBwcmV2RGVidWdDbGFzc05hbWVEZXBzLmN1cnJlbnRbMV0gIT09IG5leHREZXBzWzFdXG4gICAgICApIHtcbiAgICAgICAgaWYgKGRlYnVnRW5naW5lICYmICFoeWRyYXRpbmcpIHtcbiAgICAgICAgICBkZWJ1Z0NsYXNzTmFtZS5jdXJyZW50ID0gZGVidWdFbmdpbmUuZGVidWcoe1xuICAgICAgICAgICAgc3RhY2tJbmZvOiB7c3RhY2ssIG1lc3NhZ2V9LFxuICAgICAgICAgICAgc3RhY2tJbmRleDogMSxcbiAgICAgICAgICB9KTtcbiAgICAgICAgfVxuICAgICAgICBwcmV2RGVidWdDbGFzc05hbWVEZXBzLmN1cnJlbnQgPSBuZXh0RGVwcztcbiAgICAgIH1cblxuICAgICAgaWYgKGRlYnVnQ2xhc3NOYW1lLmN1cnJlbnQpIHtcbiAgICAgICAgcmV0dXJuIGAke2RlYnVnQ2xhc3NOYW1lLmN1cnJlbnR9ICR7Y2xhc3NOYW1lfWA7XG4gICAgICB9XG5cbiAgICAgIHJldHVybiBjbGFzc05hbWU7XG4gICAgfSxcbiAgXTtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIGNyZWF0ZVN0eWxlZCh7XG4gIGdldEluaXRpYWxTdHlsZSxcbiAgZHJpdmVyLFxuICB3cmFwcGVyLFxufTogY3JlYXRlU3R5bGVkT3B0cyk6IFN0eWxlZEZuIHtcbiAgZnVuY3Rpb24gc3R5bGVkKGJhc2U6IGFueSwgc3R5bGVBcmcpIHtcbiAgICBpZiAoX19ERVZfXykge1xuICAgICAgaWYgKGJhc2UuX19TVFlMRVRST05fXykge1xuICAgICAgICAvKiBlc2xpbnQtZGlzYWJsZSBuby1jb25zb2xlICovXG4gICAgICAgIGNvbnNvbGUud2FybihcbiAgICAgICAgICBcIkl0IGFwcGVhcnMgeW91IGFyZSBwYXNzaW5nIGEgc3R5bGVkIGNvbXBvbmVudCBpbnRvIGBzdHlsZWRgLlwiLFxuICAgICAgICApO1xuICAgICAgICBjb25zb2xlLndhcm4oXG4gICAgICAgICAgXCJGb3IgY29tcG9zaXRpb24gd2l0aCBleGlzdGluZyBzdHlsZWQgY29tcG9uZW50cywgdXNlIGB3aXRoU3R5bGVgIG9yIGB3aXRoVHJhbnNmb3JtYCBpbnN0ZWFkLlwiLFxuICAgICAgICApO1xuICAgICAgICAvKiBlc2xpbnQtZW5hYmxlIG5vLWNvbnNvbGUgKi9cbiAgICAgIH1cbiAgICB9XG5cbiAgICBjb25zdCBiYXNlU3R5bGV0cm9uOiBTdHlsZXRyb24gPSB7XG4gICAgICByZWR1Y2VyczogW10sXG4gICAgICBiYXNlOiBiYXNlLFxuICAgICAgZHJpdmVyLFxuICAgICAgZ2V0SW5pdGlhbFN0eWxlLFxuICAgICAgd3JhcHBlcixcbiAgICB9O1xuXG4gICAgaWYgKF9fQlJPV1NFUl9fICYmIF9fREVWX18pIHtcbiAgICAgIGFkZERlYnVnTWV0YWRhdGEoYmFzZVN0eWxldHJvbiwgMik7XG4gICAgfVxuXG4gICAgcmV0dXJuIGNyZWF0ZVN0eWxlZEVsZW1lbnRDb21wb25lbnQoXG4gICAgICBhdXRvQ29tcG9zZVNoYWxsb3coYmFzZVN0eWxldHJvbiwgc3R5bGVBcmcpLFxuICAgICk7XG4gIH1cblxuICByZXR1cm4gc3R5bGVkO1xufVxuXG5leHBvcnQgY29uc3Qgc3R5bGVkOiBTdHlsZWRGbiA9IGNyZWF0ZVN0eWxlZCh7XG4gIGdldEluaXRpYWxTdHlsZSxcbiAgZHJpdmVyLFxuICB3cmFwcGVyOiBDb21wb25lbnQgPT4gQ29tcG9uZW50LFxufSk7XG5cbmV4cG9ydCBjb25zdCB3aXRoVHJhbnNmb3JtOiBXaXRoVHJhbnNmb3JtRm4gPSAoY29tcG9uZW50LCB0cmFuc2Zvcm1lcikgPT4ge1xuICBjb25zdCBzdHlsZXRyb24gPSBjb21wb25lbnQuX19TVFlMRVRST05fXztcblxuICBpZiAoX19CUk9XU0VSX18gJiYgX19ERVZfXykge1xuICAgIGFkZERlYnVnTWV0YWRhdGEoc3R5bGV0cm9uLCAyKTtcbiAgfVxuXG4gIHJldHVybiBjcmVhdGVTdHlsZWRFbGVtZW50Q29tcG9uZW50KGNvbXBvc2VEeW5hbWljKHN0eWxldHJvbiwgdHJhbnNmb3JtZXIpKTtcbn07XG5cbmV4cG9ydCBjb25zdCB3aXRoU3R5bGVEZWVwOiBXaXRoU3R5bGVGbiA9IChjb21wb25lbnQsIHN0eWxlQXJnKSA9PiB7XG4gIC8vIEB0cy1pZ25vcmVcbiAgY29uc3Qgc3R5bGV0cm9uID0gY29tcG9uZW50Ll9fU1RZTEVUUk9OX187XG5cbiAgaWYgKF9fREVWX18pIHtcbiAgICBpZiAoIXN0eWxldHJvbikge1xuICAgICAgLyogZXNsaW50LWRpc2FibGUgbm8tY29uc29sZSAqL1xuICAgICAgY29uc29sZS53YXJuKFxuICAgICAgICBcIlRoZSBmaXJzdCBwYXJhbWV0ZXIgdG8gYHdpdGhTdHlsZWAgbXVzdCBiZSBhIHN0eWxlZCBjb21wb25lbnQgKHdpdGhvdXQgZXh0cmEgd3JhcHBlcnMpLlwiLFxuICAgICAgKTtcbiAgICAgIC8qIGVzbGludC1lbmFibGUgbm8tY29uc29sZSAqL1xuICAgIH1cbiAgfVxuXG4gIGlmIChfX0JST1dTRVJfXyAmJiBfX0RFVl9fKSB7XG4gICAgYWRkRGVidWdNZXRhZGF0YShzdHlsZXRyb24sIDIpO1xuICAgIHJldHVybiBjcmVhdGVTdHlsZWRFbGVtZW50Q29tcG9uZW50KFxuICAgICAgYWRkRXh0ZW5zaW9uKGF1dG9Db21wb3NlRGVlcChzdHlsZXRyb24sIHN0eWxlQXJnKSwgY29tcG9uZW50LCBzdHlsZUFyZyksXG4gICAgKTtcbiAgfSBlbHNlIHtcbiAgICByZXR1cm4gY3JlYXRlU3R5bGVkRWxlbWVudENvbXBvbmVudChhdXRvQ29tcG9zZURlZXAoc3R5bGV0cm9uLCBzdHlsZUFyZykpO1xuICB9XG59O1xuXG5leHBvcnQgY29uc3Qgd2l0aFN0eWxlID0gd2l0aFN0eWxlRGVlcDtcblxuZXhwb3J0IGNvbnN0IHdpdGhXcmFwcGVyOiBXaXRoV3JhcHBlckZuID0gKGNvbXBvbmVudCwgd3JhcHBlcikgPT4ge1xuICBjb25zdCBzdHlsZXRyb24gPSBjb21wb25lbnQuX19TVFlMRVRST05fXztcblxuICBpZiAoX19ERVZfXykge1xuICAgIGlmICghc3R5bGV0cm9uKSB7XG4gICAgICAvKiBlc2xpbnQtZGlzYWJsZSBuby1jb25zb2xlICovXG4gICAgICBjb25zb2xlLndhcm4oXG4gICAgICAgIFwiVGhlIGZpcnN0IHBhcmFtZXRlciB0byBgd2l0aFdyYXBwZXJgIG11c3QgYmUgYSBzdHlsZWQgY29tcG9uZW50ICh3aXRob3V0IGV4dHJhIHdyYXBwZXJzKS5cIixcbiAgICAgICk7XG4gICAgICAvKiBlc2xpbnQtZW5hYmxlIG5vLWNvbnNvbGUgKi9cbiAgICB9XG4gIH1cblxuICBjb25zdCBjb21wb3NlZCA9IHtcbiAgICBnZXRJbml0aWFsU3R5bGU6IHN0eWxldHJvbi5nZXRJbml0aWFsU3R5bGUsXG4gICAgYmFzZTogc3R5bGV0cm9uLmJhc2UsXG4gICAgZHJpdmVyOiBzdHlsZXRyb24uZHJpdmVyLFxuICAgIHdyYXBwZXI6IHdyYXBwZXIsXG4gICAgcmVkdWNlcnM6IHN0eWxldHJvbi5yZWR1Y2VycyxcbiAgfTtcblxuICBpZiAoX19CUk9XU0VSX18gJiYgX19ERVZfXykge1xuICAgIGFkZERlYnVnTWV0YWRhdGEoY29tcG9zZWQsIDIpO1xuICB9XG5cbiAgcmV0dXJuIGNyZWF0ZVN0eWxlZEVsZW1lbnRDb21wb25lbnQoY29tcG9zZWQpO1xufTtcblxuZXhwb3J0IGZ1bmN0aW9uIGF1dG9Db21wb3NlU2hhbGxvdzxQcm9wcz4oXG4gIHN0eWxldHJvbjogU3R5bGV0cm9uLFxuICBzdHlsZUFyZzogU3R5bGVPYmplY3QgfCAoKGE6IFByb3BzKSA9PiBTdHlsZU9iamVjdCksXG4pIHtcbiAgaWYgKHR5cGVvZiBzdHlsZUFyZyA9PT0gXCJmdW5jdGlvblwiKSB7XG4gICAgcmV0dXJuIGR5bmFtaWNDb21wb3NlU2hhbGxvdyhzdHlsZXRyb24sIHN0eWxlQXJnKTtcbiAgfVxuXG4gIHJldHVybiBzdGF0aWNDb21wb3NlU2hhbGxvdyhzdHlsZXRyb24sIHN0eWxlQXJnKTtcbn1cblxuZnVuY3Rpb24gYWRkRXh0ZW5zaW9uKGNvbXBvc2VkLCBjb21wb25lbnQsIHN0eWxlQXJnKSB7XG4gIHJldHVybiB7XG4gICAgLi4uY29tcG9zZWQsXG4gICAgZXh0OiB7XG4gICAgICB3aXRoOiBzdHlsZUFyZyxcbiAgICAgIG5hbWU6IGNvbXBvbmVudC5kaXNwbGF5TmFtZSxcbiAgICAgIGJhc2U6IGNvbXBvbmVudC5fX1NUWUxFVFJPTl9fLmJhc2UsXG4gICAgICBnZXRJbml0aWFsU3R5bGU6IGNvbXBvbmVudC5fX1NUWUxFVFJPTl9fLnJlZHVjZXJzLmxlbmd0aFxuICAgICAgICA/IGNvbXBvbmVudC5fX1NUWUxFVFJPTl9fLnJlZHVjZXJzWzBdLnJlZHVjZXJcbiAgICAgICAgOiBjb21wb25lbnQuX19TVFlMRVRST05fXy5nZXRJbml0aWFsU3R5bGUsXG4gICAgfSxcbiAgfTtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIGF1dG9Db21wb3NlRGVlcDxQcm9wcz4oXG4gIHN0eWxldHJvbjogU3R5bGV0cm9uLFxuICBzdHlsZUFyZzogU3R5bGVPYmplY3QgfCAoKGE6IFByb3BzKSA9PiBTdHlsZU9iamVjdCksXG4pIHtcbiAgaWYgKHR5cGVvZiBzdHlsZUFyZyA9PT0gXCJmdW5jdGlvblwiKSB7XG4gICAgcmV0dXJuIGR5bmFtaWNDb21wb3NlRGVlcChzdHlsZXRyb24sIHN0eWxlQXJnKTtcbiAgfVxuXG4gIHJldHVybiBzdGF0aWNDb21wb3NlRGVlcChzdHlsZXRyb24sIHN0eWxlQXJnKTtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIHN0YXRpY0NvbXBvc2VTaGFsbG93KHN0eWxldHJvbjogU3R5bGV0cm9uLCBzdHlsZTogU3R5bGVPYmplY3QpIHtcbiAgcmV0dXJuIGNvbXBvc2VTdGF0aWMoc3R5bGV0cm9uLCBjcmVhdGVTaGFsbG93TWVyZ2VSZWR1Y2VyKHN0eWxlKSk7XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBzdGF0aWNDb21wb3NlRGVlcChzdHlsZXRyb246IFN0eWxldHJvbiwgc3R5bGU6IFN0eWxlT2JqZWN0KSB7XG4gIHJldHVybiBjb21wb3NlU3RhdGljKHN0eWxldHJvbiwgY3JlYXRlRGVlcE1lcmdlUmVkdWNlcihzdHlsZSkpO1xufVxuXG5leHBvcnQgZnVuY3Rpb24gZHluYW1pY0NvbXBvc2VTaGFsbG93PFByb3BzPihcbiAgc3R5bGV0cm9uOiBTdHlsZXRyb24sXG4gIHN0eWxlRm46IChhOiBQcm9wcykgPT4gU3R5bGVPYmplY3QsXG4pIHtcbiAgcmV0dXJuIGNvbXBvc2VEeW5hbWljPFByb3BzPihzdHlsZXRyb24sIChzdHlsZSwgcHJvcHMpID0+XG4gICAgc2hhbGxvd01lcmdlKHN0eWxlLCBzdHlsZUZuKHByb3BzKSksXG4gICk7XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBkeW5hbWljQ29tcG9zZURlZXA8UHJvcHM+KFxuICBzdHlsZXRyb246IFN0eWxldHJvbixcbiAgc3R5bGVGbjogKGE6IFByb3BzKSA9PiBTdHlsZU9iamVjdCxcbikge1xuICByZXR1cm4gY29tcG9zZUR5bmFtaWM8UHJvcHM+KHN0eWxldHJvbiwgKHN0eWxlLCBwcm9wcykgPT5cbiAgICBkZWVwTWVyZ2Uoc3R5bGUsIHN0eWxlRm4ocHJvcHMpKSxcbiAgKTtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIGNyZWF0ZVNoYWxsb3dNZXJnZVJlZHVjZXIoXG4gIHN0eWxlOiBTdHlsZU9iamVjdCxcbik6IEFzc2lnbm1lbnRDb21tdXRhdGl2ZVJlZHVjZXJDb250YWluZXIge1xuICByZXR1cm4ge1xuICAgIHJlZHVjZXI6IGlucHV0U3R5bGUgPT4gc2hhbGxvd01lcmdlKGlucHV0U3R5bGUsIHN0eWxlKSxcbiAgICBhc3NpZ25tZW50Q29tbXV0YXRpdmU6IHRydWUsXG4gICAgZmFjdG9yeTogY3JlYXRlU2hhbGxvd01lcmdlUmVkdWNlcixcbiAgICBzdHlsZTogc3R5bGUsXG4gIH07XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBjcmVhdGVEZWVwTWVyZ2VSZWR1Y2VyKFxuICBzdHlsZTogU3R5bGVPYmplY3QsXG4pOiBBc3NpZ25tZW50Q29tbXV0YXRpdmVSZWR1Y2VyQ29udGFpbmVyIHtcbiAgcmV0dXJuIHtcbiAgICByZWR1Y2VyOiBpbnB1dFN0eWxlID0+IGRlZXBNZXJnZShpbnB1dFN0eWxlLCBzdHlsZSksXG4gICAgYXNzaWdubWVudENvbW11dGF0aXZlOiB0cnVlLFxuICAgIGZhY3Rvcnk6IGNyZWF0ZURlZXBNZXJnZVJlZHVjZXIsXG4gICAgc3R5bGU6IHN0eWxlLFxuICB9O1xufVxuXG5leHBvcnQgZnVuY3Rpb24gY29tcG9zZVN0YXRpYyhcbiAgc3R5bGV0cm9uOiBTdHlsZXRyb24sXG4gIHJlZHVjZXJDb250YWluZXI6IEFzc2lnbm1lbnRDb21tdXRhdGl2ZVJlZHVjZXJDb250YWluZXIsXG4pIHtcbiAgaWYgKHN0eWxldHJvbi5yZWR1Y2Vycy5sZW5ndGggPT09IDApIHtcbiAgICBjb25zdCBzdHlsZSA9IHJlZHVjZXJDb250YWluZXIucmVkdWNlcihzdHlsZXRyb24uZ2V0SW5pdGlhbFN0eWxlKCkpO1xuICAgIGNvbnN0IHJlc3VsdDogU3R5bGV0cm9uID0ge1xuICAgICAgcmVkdWNlcnM6IHN0eWxldHJvbi5yZWR1Y2VycyxcbiAgICAgIGJhc2U6IHN0eWxldHJvbi5iYXNlLFxuICAgICAgZHJpdmVyOiBzdHlsZXRyb24uZHJpdmVyLFxuICAgICAgd3JhcHBlcjogc3R5bGV0cm9uLndyYXBwZXIsXG4gICAgICBnZXRJbml0aWFsU3R5bGU6ICgpID0+IHN0eWxlLFxuICAgIH07XG4gICAgaWYgKF9fQlJPV1NFUl9fICYmIF9fREVWX18pIHtcbiAgICAgIHJlc3VsdC5kZWJ1ZyA9IHN0eWxldHJvbi5kZWJ1ZztcbiAgICB9XG4gICAgcmV0dXJuIHJlc3VsdDtcbiAgfSBlbHNlIHtcbiAgICBjb25zdCBsYXN0ID0gc3R5bGV0cm9uLnJlZHVjZXJzWzBdO1xuXG4gICAgaWYgKFxuICAgICAgbGFzdC5hc3NpZ25tZW50Q29tbXV0YXRpdmUgPT09IHRydWUgJiZcbiAgICAgIHJlZHVjZXJDb250YWluZXIuYXNzaWdubWVudENvbW11dGF0aXZlID09PSB0cnVlXG4gICAgKSB7XG4gICAgICBjb25zdCBjb21wb3NlZCA9IHJlZHVjZXJDb250YWluZXIucmVkdWNlcihsYXN0LnN0eWxlKTtcblxuICAgICAgY29uc3QgcmVzdWx0OiBTdHlsZXRyb24gPSB7XG4gICAgICAgIGdldEluaXRpYWxTdHlsZTogc3R5bGV0cm9uLmdldEluaXRpYWxTdHlsZSxcbiAgICAgICAgYmFzZTogc3R5bGV0cm9uLmJhc2UsXG4gICAgICAgIGRyaXZlcjogc3R5bGV0cm9uLmRyaXZlcixcbiAgICAgICAgd3JhcHBlcjogc3R5bGV0cm9uLndyYXBwZXIsXG4gICAgICAgIHJlZHVjZXJzOiBbbGFzdC5mYWN0b3J5KGNvbXBvc2VkKV0uY29uY2F0KFxuICAgICAgICAgIHN0eWxldHJvbi5yZWR1Y2Vycy5zbGljZSgxKSBhcyBhbnksXG4gICAgICAgICksXG4gICAgICB9O1xuXG4gICAgICBpZiAoX19CUk9XU0VSX18gJiYgX19ERVZfXykge1xuICAgICAgICByZXN1bHQuZGVidWcgPSBzdHlsZXRyb24uZGVidWc7XG4gICAgICB9XG5cbiAgICAgIHJldHVybiByZXN1bHQ7XG4gICAgfVxuXG4gICAgcmV0dXJuIGNvbXBvc2VEeW5hbWljKHN0eWxldHJvbiwgcmVkdWNlckNvbnRhaW5lci5yZWR1Y2VyKTtcbiAgfVxufVxuXG5leHBvcnQgZnVuY3Rpb24gY29tcG9zZUR5bmFtaWM8UHJvcHM+KFxuICBzdHlsZXRyb246IFN0eWxldHJvbixcbiAgcmVkdWNlcjogKGI6IFN0eWxlT2JqZWN0LCBhOiBQcm9wcykgPT4gU3R5bGVPYmplY3QsXG4pIHtcbiAgY29uc3QgY29tcG9zZWQ6IFN0eWxldHJvbiA9IHtcbiAgICBnZXRJbml0aWFsU3R5bGU6IHN0eWxldHJvbi5nZXRJbml0aWFsU3R5bGUsXG4gICAgYmFzZTogc3R5bGV0cm9uLmJhc2UsXG4gICAgZHJpdmVyOiBzdHlsZXRyb24uZHJpdmVyLFxuICAgIHdyYXBwZXI6IHN0eWxldHJvbi53cmFwcGVyLFxuICAgIC8vIEB0cy1pZ25vcmVcbiAgICByZWR1Y2VyczogW3thc3NpZ25tZW50Q29tbXV0YXRpdmU6IGZhbHNlLCByZWR1Y2VyfV0uY29uY2F0KFxuICAgICAgc3R5bGV0cm9uLnJlZHVjZXJzLFxuICAgICksXG4gIH07XG4gIGlmIChfX0JST1dTRVJfXyAmJiBfX0RFVl9fKSB7XG4gICAgY29tcG9zZWQuZGVidWcgPSBzdHlsZXRyb24uZGVidWc7XG4gIH1cbiAgcmV0dXJuIGNvbXBvc2VkO1xufVxuXG5leHBvcnQgZnVuY3Rpb24gY3JlYXRlU3R5bGVkRWxlbWVudENvbXBvbmVudChzdHlsZXRyb246IFN0eWxldHJvbikge1xuICBjb25zdCB7cmVkdWNlcnMsIGJhc2UsIGRyaXZlciwgd3JhcHBlciwgZ2V0SW5pdGlhbFN0eWxlLCBleHR9ID0gc3R5bGV0cm9uO1xuXG4gIGlmIChfX0JST1dTRVJfXyAmJiBfX0RFVl9fKSB7XG4gICAgdmFyIGRlYnVnU3RhY2tJbmZvLCBkZWJ1Z1N0YWNrSW5kZXg7XG4gICAgaWYgKHN0eWxldHJvbi5kZWJ1Zykge1xuICAgICAgZGVidWdTdGFja0luZm8gPSBzdHlsZXRyb24uZGVidWcuc3RhY2tJbmZvO1xuICAgICAgZGVidWdTdGFja0luZGV4ID0gc3R5bGV0cm9uLmRlYnVnLnN0YWNrSW5kZXg7XG4gICAgfVxuICB9XG5cbiAgaWYgKF9fQlJPV1NFUl9fICYmIF9fREVWX18pIHtcbiAgICB2YXIgZGVidWdDbGFzc05hbWU7XG4gIH1cblxuICBjb25zdCBTdHlsZWRFbGVtZW50ID0gUmVhY3QuZm9yd2FyZFJlZjxTdHlsZXRyb25Qcm9wcywgYW55PigocHJvcHMsIHJlZikgPT4ge1xuICAgIGNvbnN0IHN0eWxldHJvbjogU3RhbmRhcmRFbmdpbmUgPSBSZWFjdC51c2VDb250ZXh0KFN0eWxldHJvbkNvbnRleHQpO1xuICAgIGNvbnN0IGRlYnVnRW5naW5lID0gUmVhY3QudXNlQ29udGV4dChEZWJ1Z0VuZ2luZUNvbnRleHQpO1xuICAgIGNvbnN0IGh5ZHJhdGluZyA9IFJlYWN0LnVzZUNvbnRleHQoSHlkcmF0aW9uQ29udGV4dCk7XG4gICAgY2hlY2tOb29wRW5naW5lKHN0eWxldHJvbik7XG5cbiAgICBjb25zdCBlbGVtZW50UHJvcHM6IGFueSA9IG9taXRQcmVmaXhlZEtleXMocHJvcHMpO1xuICAgIGxldCBzdHlsZSA9IHJlc29sdmVTdHlsZShnZXRJbml0aWFsU3R5bGUsIHJlZHVjZXJzLCBwcm9wcyk7XG5cbiAgICBpZiAocHJvcHMuJHN0eWxlKSB7XG4gICAgICBpZiAodHlwZW9mIHByb3BzLiRzdHlsZSA9PT0gXCJmdW5jdGlvblwiKSB7XG4gICAgICAgIHN0eWxlID0gZGVlcE1lcmdlKHN0eWxlLCBwcm9wcy4kc3R5bGUocHJvcHMpKTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIHN0eWxlID0gZGVlcE1lcmdlKHN0eWxlLCBwcm9wcy4kc3R5bGUpO1xuICAgICAgfVxuICAgIH1cblxuICAgIGNvbnN0IHN0eWxlQ2xhc3NTdHJpbmcgPSBkcml2ZXIoc3R5bGUsIHN0eWxldHJvbik7XG4gICAgY29uc3QgRWxlbWVudCA9IHByb3BzLiRhcyA/IHByb3BzLiRhcyA6IGJhc2U7XG4gICAgZWxlbWVudFByb3BzLmNsYXNzTmFtZSA9IHByb3BzLmNsYXNzTmFtZVxuICAgICAgPyBgJHtwcm9wcy5jbGFzc05hbWV9ICR7c3R5bGVDbGFzc1N0cmluZ31gXG4gICAgICA6IHN0eWxlQ2xhc3NTdHJpbmc7XG5cbiAgICBpZiAoX19CUk9XU0VSX18gJiYgX19ERVZfXyAmJiBkZWJ1Z0VuZ2luZSAmJiAhaHlkcmF0aW5nKSB7XG4gICAgICBpZiAoIWRlYnVnQ2xhc3NOYW1lKSB7XG4gICAgICAgIGRlYnVnQ2xhc3NOYW1lID0gZGVidWdFbmdpbmUuZGVidWcoe1xuICAgICAgICAgIHN0YWNrSW5mbzogZGVidWdTdGFja0luZm8sXG4gICAgICAgICAgc3RhY2tJbmRleDogZGVidWdTdGFja0luZGV4LFxuICAgICAgICB9KTtcbiAgICAgIH1cblxuICAgICAgY29uc3Qgam9pbmVkID0gYCR7ZGVidWdDbGFzc05hbWV9ICR7ZWxlbWVudFByb3BzLmNsYXNzTmFtZX1gO1xuICAgICAgZWxlbWVudFByb3BzLmNsYXNzTmFtZSA9IGpvaW5lZDtcbiAgICB9XG5cbiAgICBpZiAoX19CUk9XU0VSX18gJiYgX19ERVZfXyAmJiB3aW5kb3cuX19TVFlMRVRST05fREVWVE9PTFNfXykge1xuICAgICAgd2luZG93Ll9fU1RZTEVUUk9OX0RFVlRPT0xTX18uc3R5bGVzTWFwLnNldChcbiAgICAgICAgZWxlbWVudFByb3BzLmNsYXNzTmFtZSxcbiAgICAgICAgc3R5bGUsXG4gICAgICApO1xuICAgICAgaWYgKGV4dCkge1xuICAgICAgICB3aW5kb3cuX19TVFlMRVRST05fREVWVE9PTFNfXy5leHRlbnNpb25zTWFwLnNldChcbiAgICAgICAgICBlbGVtZW50UHJvcHMuY2xhc3NOYW1lLFxuICAgICAgICAgIHtcbiAgICAgICAgICAgIGJhc2U6IGV4dC5iYXNlLFxuICAgICAgICAgICAgZGlzcGxheU5hbWU6IGV4dC5uYW1lLFxuICAgICAgICAgICAgaW5pdGlhbFN0eWxlczogZXh0LmdldEluaXRpYWxTdHlsZSh7fSwgcHJvcHMpLFxuICAgICAgICAgICAgc3R5bGVPdmVycmlkZXM6XG4gICAgICAgICAgICAgIHR5cGVvZiBleHQud2l0aCA9PT0gXCJmdW5jdGlvblwiID8gZXh0LndpdGgocHJvcHMpIDogZXh0LndpdGgsXG4gICAgICAgICAgfSxcbiAgICAgICAgKTtcbiAgICAgIH1cbiAgICB9XG5cbiAgICBpZiAocHJvcHMuJHJlZikge1xuICAgICAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIG5vLWNvbnNvbGVcbiAgICAgIGNvbnNvbGUud2FybihcbiAgICAgICAgXCJUaGUgcHJvcCBgJHJlZmAgaGFzIGJlZW4gZGVwcmVjYXRlZC4gVXNlIGByZWZgIGluc3RlYWQuIFJlZnMgYXJlIG5vdyBmb3J3YXJkZWQgd2l0aCBSZWFjdC5mb3J3YXJkUmVmLlwiLFxuICAgICAgKTtcbiAgICB9XG4gICAgcmV0dXJuIDxFbGVtZW50IHsuLi5lbGVtZW50UHJvcHN9IHJlZj17cmVmIHx8IHByb3BzLiRyZWZ9IC8+O1xuICB9KTtcblxuICBjb25zdCBXcmFwcGVkID0gd3JhcHBlcihTdHlsZWRFbGVtZW50KTtcbiAgV3JhcHBlZC5fX1NUWUxFVFJPTl9fID0ge1xuICAgIGJhc2UsXG4gICAgcmVkdWNlcnMsXG4gICAgZHJpdmVyLFxuICAgIHdyYXBwZXIsXG4gICAgZ2V0SW5pdGlhbFN0eWxlLFxuICB9O1xuXG4gIGlmIChfX0RFVl9fKSB7XG4gICAgbGV0IGRpc3BsYXlOYW1lO1xuXG4gICAgaWYgKHR5cGVvZiBiYXNlID09PSBcInN0cmluZ1wiKSB7XG4gICAgICBkaXNwbGF5TmFtZSA9IGJhc2U7XG4gICAgfSBlbHNlIGlmIChiYXNlLmRpc3BsYXlOYW1lKSB7XG4gICAgICBkaXNwbGF5TmFtZSA9IGJhc2UuZGlzcGxheU5hbWU7XG4gICAgfSBlbHNlIGlmIChiYXNlLm5hbWUpIHtcbiAgICAgIGRpc3BsYXlOYW1lID0gYmFzZS5uYW1lO1xuICAgIH0gZWxzZSB7XG4gICAgICBkaXNwbGF5TmFtZSA9IFwiVW5rbm93blwiO1xuICAgIH1cblxuICAgIFdyYXBwZWQuZGlzcGxheU5hbWUgPSBgU3R5bGVkKCR7ZGlzcGxheU5hbWV9KWA7XG4gIH1cblxuICByZXR1cm4gV3JhcHBlZDtcbn1cblxuLy8gVXRpbGl0eSBmdW5jdGlvbnNcblxuZXhwb3J0IGZ1bmN0aW9uIHJlc29sdmVTdHlsZShcbiAgZ2V0SW5pdGlhbFN0eWxlOiAoYTogdm9pZCkgPT4gU3R5bGVPYmplY3QsXG4gIHJlZHVjZXJzOiBBcnJheTxSZWR1Y2VyQ29udGFpbmVyPixcbiAgcHJvcHM6IGFueSxcbik6IFN0eWxlT2JqZWN0IHtcbiAgbGV0IHJlc3VsdCA9IGdldEluaXRpYWxTdHlsZSgpO1xuICBsZXQgaSA9IHJlZHVjZXJzLmxlbmd0aDtcbiAgd2hpbGUgKGktLSkge1xuICAgIC8vIENhc3QgdG8gYWxsb3cgcGFzc2luZyB1bnVzZWQgcHJvcHMgcGFyYW0gaW4gY2FzZSBvZiBzdGF0aWMgcmVkdWNlclxuICAgIGNvbnN0IHJlZHVjZXIgPSByZWR1Y2Vyc1tpXS5yZWR1Y2VyIGFzIChcbiAgICAgIGI6IFN0eWxlT2JqZWN0LFxuICAgICAgYTogYW55LFxuICAgICkgPT4gU3R5bGVPYmplY3Q7XG4gICAgcmVzdWx0ID0gcmVkdWNlcihyZXN1bHQsIHByb3BzKTtcbiAgfVxuICByZXR1cm4gcmVzdWx0O1xufVxuXG5mdW5jdGlvbiBpc09iamVjdCh4OiBhbnkpIHtcbiAgcmV0dXJuIHR5cGVvZiB4ID09PSBcIm9iamVjdFwiICYmIHggIT09IG51bGw7XG59XG5cbmZ1bmN0aW9uIG9taXRQcmVmaXhlZEtleXMoc291cmNlKSB7XG4gIGNvbnN0IHJlc3VsdCA9IHt9O1xuXG4gIGZvciAoY29uc3Qga2V5IGluIHNvdXJjZSkge1xuICAgIGlmIChrZXlbMF0gIT09IFwiJFwiKSB7XG4gICAgICByZXN1bHRba2V5XSA9IHNvdXJjZVtrZXldO1xuICAgIH1cbiAgfVxuXG4gIHJldHVybiByZXN1bHQ7XG59XG5cbmZ1bmN0aW9uIGRlZXBNZXJnZShhLCBiKSB7XG4gIGNvbnN0IHJlc3VsdCA9IGFzc2lnbih7fSwgYSk7XG5cbiAgZm9yIChjb25zdCBrZXkgaW4gYikge1xuICAgIGNvbnN0IHZhbCA9IGJba2V5XTtcblxuICAgIGlmIChpc09iamVjdCh2YWwpICYmIGlzT2JqZWN0KGFba2V5XSkpIHtcbiAgICAgIHJlc3VsdFtrZXldID0gZGVlcE1lcmdlKGFba2V5XSwgdmFsKTtcbiAgICB9IGVsc2Uge1xuICAgICAgcmVzdWx0W2tleV0gPSB2YWw7XG4gICAgfVxuICB9XG5cbiAgcmV0dXJuIHJlc3VsdDtcbn1cblxuZnVuY3Rpb24gc2hhbGxvd01lcmdlKGEsIGIpIHtcbiAgcmV0dXJuIGFzc2lnbihhc3NpZ24oe30sIGEpLCBiKTtcbn1cblxuZnVuY3Rpb24gYXNzaWduKHRhcmdldCwgc291cmNlKSB7XG4gIGZvciAoY29uc3Qga2V5IGluIHNvdXJjZSkge1xuICAgIHRhcmdldFtrZXldID0gc291cmNlW2tleV07XG4gIH1cbiAgcmV0dXJuIHRhcmdldDtcbn1cbiJdLCJtYXBwaW5ncyI6Ijs7QUFBQTs7QUFDQTtBQWFBLE9BQU8sS0FBS0EsS0FBWixNQUF1QixPQUF2QjtBQUNBLFNBQ0VDLE1BREYsRUFFRUMsZUFGRixRQUtPLG9CQUxQO0FBbUJBLFNBR0VDLFdBSEYsUUFJTyxZQUpQO0FBTUEsU0FBUUEsV0FBUjtBQUtBLE1BQU1DLFVBQVUsR0FBRztFQUNqQkMsV0FBVyxFQUFFLE1BQU0sRUFERjtFQUVqQkMsZUFBZSxFQUFFLE1BQU0sRUFGTjtFQUdqQkMsY0FBYyxFQUFFLE1BQU07QUFITCxDQUFuQjtBQU1BLE1BQU1DLGdCQUFnQixnQkFBR1IsS0FBSyxDQUFDUyxhQUFOLENBQW9DTCxVQUFwQyxDQUF6QjtBQUNBLE1BQU1NLGdCQUFnQixnQkFBR1YsS0FBSyxDQUFDUyxhQUFOLENBQW9CLEtBQXBCLENBQXpCO0FBQ0EsTUFBTUUsa0JBQWtCLGdCQUFHWCxLQUFLLENBQUNTLGFBQU4sQ0FFekJHLFNBRnlCLENBQTNCLEMsQ0FHQTs7QUFTQSxNQUFNQyxXQUFOLFNBQTBCYixLQUFLLENBQUNjLFNBQWhDLENBS0U7RUFDQUMsV0FBVyxDQUFDQyxLQUFELEVBQTBCO0lBQ25DLE1BQU1BLEtBQU47SUFDQSxLQUFLQyxLQUFMLEdBQWE7TUFDWEMsU0FBUyxFQUFFQyxPQUFPLENBQUNILEtBQUssQ0FBQ0ksbUJBQVA7SUFEUCxDQUFiO0VBR0Q7O0VBRURDLGlCQUFpQixHQUFHO0lBQ2xCLFdBQWlCO01BQ2YsSUFBSSxLQUFLSixLQUFMLENBQVdDLFNBQVgsS0FBeUIsSUFBN0IsRUFBbUM7UUFDakMsS0FBS0ksUUFBTCxDQUFjO1VBQ1pKLFNBQVMsRUFBRTtRQURDLENBQWQ7TUFHRDtJQUNGO0VBQ0Y7O0VBRURLLE1BQU0sR0FBRztJQUNQLG9CQUNFLG9CQUFDLGdCQUFELENBQWtCLFFBQWxCO01BQTJCLEtBQUssRUFBRSxLQUFLUCxLQUFMLENBQVdRO0lBQTdDLGdCQUNFLG9CQUFDLGtCQUFELENBQW9CLFFBQXBCO01BQTZCLEtBQUssRUFBRSxLQUFLUixLQUFMLENBQVdTO0lBQS9DLGdCQUNFLG9CQUFDLGdCQUFELENBQWtCLFFBQWxCO01BQTJCLEtBQUssRUFBRSxLQUFLUixLQUFMLENBQVdDO0lBQTdDLEdBQ0csS0FBS0YsS0FBTCxDQUFXVSxRQURkLENBREYsQ0FERixDQURGO0VBU0Q7O0FBNUJEOztBQStCRixPQUFPLE1BQU1DLFFBQVEsR0FDbkIsaURBQXlCZCxXQUF6QixHQUF1Q0wsZ0JBQWdCLENBQUNtQixRQURuRDs7QUFHUCxJQUFJLGtEQUEwQixDQUFDQyxNQUFNLENBQUNDLHNCQUF0QyxFQUE4RDtFQUM1REMsc0JBQXNCO0FBQ3ZCOztBQVFELFNBQVNDLGVBQVQsQ0FBeUJDLE1BQXpCLEVBQWlEO0VBQy9DO0VBQ0E7RUFDQSxJQUFJQyxPQUFPLENBQUNDLEdBQVIsQ0FBWUMsUUFBWixLQUF5QixNQUE3QixFQUFxQztJQUNuQ0gsTUFBTSxLQUFLNUIsVUFBWCxJQUNFO0lBQ0FnQyxPQUFPLENBQUNDLElBQVIsQ0FDRSx3Q0FDSztBQUNiO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsQ0FaUSxHQWFLLHdEQWRQLENBRkY7RUFrQkQ7QUFDRjs7QUFFRCxPQUFPLFNBQVNDLFlBQVQsR0FBMEQ7RUFDL0QsTUFBTUMsZUFBK0IsR0FBR3ZDLEtBQUssQ0FBQ3dDLFVBQU4sQ0FBaUJoQyxnQkFBakIsQ0FBeEM7RUFDQSxNQUFNaUMsV0FBVyxHQUFHekMsS0FBSyxDQUFDd0MsVUFBTixDQUFpQjdCLGtCQUFqQixDQUFwQjtFQUNBLE1BQU1PLFNBQVMsR0FBR2xCLEtBQUssQ0FBQ3dDLFVBQU4sQ0FBaUI5QixnQkFBakIsQ0FBbEI7RUFDQXFCLGVBQWUsQ0FBQ1EsZUFBRCxDQUFmO0VBRUEsTUFBTUcsY0FBYyxHQUFHMUMsS0FBSyxDQUFDMkMsTUFBTixDQUFpQyxFQUFqQyxDQUF2QjtFQUNBLE1BQU1DLHNCQUFzQixHQUFHNUMsS0FBSyxDQUFDMkMsTUFBTixDQUFhLEVBQWIsQ0FBL0I7RUFFQSxPQUFPLENBQ0wsU0FBU0UsR0FBVCxDQUFhQyxLQUFiLEVBQWlDO0lBQy9CLE1BQU1DLFNBQVMsR0FBRzlDLE1BQU0sQ0FBQzZDLEtBQUQsRUFBUVAsZUFBUixDQUF4Qjs7SUFDQSxJQUFJLEVBQUUsOENBQUYsQ0FBSixFQUErQjtNQUM3QixPQUFPUSxTQUFQO0lBQ0Q7O0lBQ0QsTUFBTTtNQUFDQyxLQUFEO01BQVFDO0lBQVIsSUFBbUIsSUFBSUMsS0FBSixDQUFVLG1CQUFWLENBQXpCO0lBRUEsTUFBTUMsUUFBUSxHQUFHLENBQUNWLFdBQUQsRUFBY3ZCLFNBQWQsQ0FBakI7O0lBQ0EsSUFDRTBCLHNCQUFzQixDQUFDUSxPQUF2QixDQUErQixDQUEvQixNQUFzQ0QsUUFBUSxDQUFDLENBQUQsQ0FBOUMsSUFDQVAsc0JBQXNCLENBQUNRLE9BQXZCLENBQStCLENBQS9CLE1BQXNDRCxRQUFRLENBQUMsQ0FBRCxDQUZoRCxFQUdFO01BQ0EsSUFBSVYsV0FBVyxJQUFJLENBQUN2QixTQUFwQixFQUErQjtRQUM3QndCLGNBQWMsQ0FBQ1UsT0FBZixHQUF5QlgsV0FBVyxDQUFDaEIsS0FBWixDQUFrQjtVQUN6QzRCLFNBQVMsRUFBRTtZQUFDTCxLQUFEO1lBQVFDO1VBQVIsQ0FEOEI7VUFFekNLLFVBQVUsRUFBRTtRQUY2QixDQUFsQixDQUF6QjtNQUlEOztNQUNEVixzQkFBc0IsQ0FBQ1EsT0FBdkIsR0FBaUNELFFBQWpDO0lBQ0Q7O0lBRUQsSUFBSVQsY0FBYyxDQUFDVSxPQUFuQixFQUE0QjtNQUMxQixPQUFRLEdBQUVWLGNBQWMsQ0FBQ1UsT0FBUSxJQUFHTCxTQUFVLEVBQTlDO0lBQ0Q7O0lBRUQsT0FBT0EsU0FBUDtFQUNELENBM0JJLENBQVA7QUE2QkQ7QUFFRCxPQUFPLFNBQVNRLFlBQVQsQ0FBc0I7RUFDM0JyRCxlQUQyQjtFQUUzQkQsTUFGMkI7RUFHM0J1RDtBQUgyQixDQUF0QixFQUl3QjtFQUM3QixTQUFTQyxNQUFULENBQWdCQyxJQUFoQixFQUEyQkMsUUFBM0IsRUFBcUM7SUFDbkMsMkNBQWE7TUFDWCxJQUFJRCxJQUFJLENBQUNFLGFBQVQsRUFBd0I7UUFDdEI7UUFDQXhCLE9BQU8sQ0FBQ0MsSUFBUixDQUNFLDhEQURGO1FBR0FELE9BQU8sQ0FBQ0MsSUFBUixDQUNFLDhGQURGO1FBR0E7TUFDRDtJQUNGOztJQUVELE1BQU13QixhQUF3QixHQUFHO01BQy9CQyxRQUFRLEVBQUUsRUFEcUI7TUFFL0JKLElBQUksRUFBRUEsSUFGeUI7TUFHL0J6RCxNQUgrQjtNQUkvQkMsZUFKK0I7TUFLL0JzRDtJQUwrQixDQUFqQzs7SUFRQSxJQUFJLDhDQUFKLEVBQTRCO01BQzFCTyxnQkFBZ0IsQ0FBQ0YsYUFBRCxFQUFnQixDQUFoQixDQUFoQjtJQUNEOztJQUVELE9BQU9HLDRCQUE0QixDQUNqQ0Msa0JBQWtCLENBQUNKLGFBQUQsRUFBZ0JGLFFBQWhCLENBRGUsQ0FBbkM7RUFHRDs7RUFFRCxPQUFPRixNQUFQO0FBQ0Q7QUFFRCxPQUFPLE1BQU1BLE1BQWdCLEdBQUdGLFlBQVksQ0FBQztFQUMzQ3JELGVBRDJDO0VBRTNDRCxNQUYyQztFQUczQ3VELE9BQU8sRUFBRTFDLFNBQVMsSUFBSUE7QUFIcUIsQ0FBRCxDQUFyQztBQU1QLE9BQU8sTUFBTW9ELGFBQThCLEdBQUcsQ0FBQ0MsU0FBRCxFQUFZQyxXQUFaLEtBQTRCO0VBQ3hFLE1BQU1DLFNBQVMsR0FBR0YsU0FBUyxDQUFDUCxhQUE1Qjs7RUFFQSxJQUFJLDhDQUFKLEVBQTRCO0lBQzFCRyxnQkFBZ0IsQ0FBQ00sU0FBRCxFQUFZLENBQVosQ0FBaEI7RUFDRDs7RUFFRCxPQUFPTCw0QkFBNEIsQ0FBQ00sY0FBYyxDQUFDRCxTQUFELEVBQVlELFdBQVosQ0FBZixDQUFuQztBQUNELENBUk07QUFVUCxPQUFPLE1BQU1HLGFBQTBCLEdBQUcsQ0FBQ0osU0FBRCxFQUFZUixRQUFaLEtBQXlCO0VBQ2pFO0VBQ0EsTUFBTVUsU0FBUyxHQUFHRixTQUFTLENBQUNQLGFBQTVCOztFQUVBLDJDQUFhO0lBQ1gsSUFBSSxDQUFDUyxTQUFMLEVBQWdCO01BQ2Q7TUFDQWpDLE9BQU8sQ0FBQ0MsSUFBUixDQUNFLHlGQURGO01BR0E7SUFDRDtFQUNGOztFQUVELElBQUksOENBQUosRUFBNEI7SUFDMUIwQixnQkFBZ0IsQ0FBQ00sU0FBRCxFQUFZLENBQVosQ0FBaEI7SUFDQSxPQUFPTCw0QkFBNEIsQ0FDakNRLFlBQVksQ0FBQ0MsZUFBZSxDQUFDSixTQUFELEVBQVlWLFFBQVosQ0FBaEIsRUFBdUNRLFNBQXZDLEVBQWtEUixRQUFsRCxDQURxQixDQUFuQztFQUdELENBTEQsTUFLTztJQUNMLE9BQU9LLDRCQUE0QixDQUFDUyxlQUFlLENBQUNKLFNBQUQsRUFBWVYsUUFBWixDQUFoQixDQUFuQztFQUNEO0FBQ0YsQ0F0Qk07QUF3QlAsT0FBTyxNQUFNZSxTQUFTLEdBQUdILGFBQWxCO0FBRVAsT0FBTyxNQUFNSSxXQUEwQixHQUFHLENBQUNSLFNBQUQsRUFBWVgsT0FBWixLQUF3QjtFQUNoRSxNQUFNYSxTQUFTLEdBQUdGLFNBQVMsQ0FBQ1AsYUFBNUI7O0VBRUEsMkNBQWE7SUFDWCxJQUFJLENBQUNTLFNBQUwsRUFBZ0I7TUFDZDtNQUNBakMsT0FBTyxDQUFDQyxJQUFSLENBQ0UsMkZBREY7TUFHQTtJQUNEO0VBQ0Y7O0VBRUQsTUFBTXVDLFFBQVEsR0FBRztJQUNmMUUsZUFBZSxFQUFFbUUsU0FBUyxDQUFDbkUsZUFEWjtJQUVmd0QsSUFBSSxFQUFFVyxTQUFTLENBQUNYLElBRkQ7SUFHZnpELE1BQU0sRUFBRW9FLFNBQVMsQ0FBQ3BFLE1BSEg7SUFJZnVELE9BQU8sRUFBRUEsT0FKTTtJQUtmTSxRQUFRLEVBQUVPLFNBQVMsQ0FBQ1A7RUFMTCxDQUFqQjs7RUFRQSxJQUFJLDhDQUFKLEVBQTRCO0lBQzFCQyxnQkFBZ0IsQ0FBQ2EsUUFBRCxFQUFXLENBQVgsQ0FBaEI7RUFDRDs7RUFFRCxPQUFPWiw0QkFBNEIsQ0FBQ1ksUUFBRCxDQUFuQztBQUNELENBMUJNO0FBNEJQLE9BQU8sU0FBU1gsa0JBQVQsQ0FDTEksU0FESyxFQUVMVixRQUZLLEVBR0w7RUFDQSxJQUFJLE9BQU9BLFFBQVAsS0FBb0IsVUFBeEIsRUFBb0M7SUFDbEMsT0FBT2tCLHFCQUFxQixDQUFDUixTQUFELEVBQVlWLFFBQVosQ0FBNUI7RUFDRDs7RUFFRCxPQUFPbUIsb0JBQW9CLENBQUNULFNBQUQsRUFBWVYsUUFBWixDQUEzQjtBQUNEOztBQUVELFNBQVNhLFlBQVQsQ0FBc0JJLFFBQXRCLEVBQWdDVCxTQUFoQyxFQUEyQ1IsUUFBM0MsRUFBcUQ7RUFDbkQsT0FBTyxFQUNMLEdBQUdpQixRQURFO0lBRUxHLEdBQUcsRUFBRTtNQUNIQyxJQUFJLEVBQUVyQixRQURIO01BRUhzQixJQUFJLEVBQUVkLFNBQVMsQ0FBQ2UsV0FGYjtNQUdIeEIsSUFBSSxFQUFFUyxTQUFTLENBQUNQLGFBQVYsQ0FBd0JGLElBSDNCO01BSUh4RCxlQUFlLEVBQUVpRSxTQUFTLENBQUNQLGFBQVYsQ0FBd0JFLFFBQXhCLENBQWlDcUIsTUFBakMsR0FDYmhCLFNBQVMsQ0FBQ1AsYUFBVixDQUF3QkUsUUFBeEIsQ0FBaUMsQ0FBakMsRUFBb0NzQixPQUR2QixHQUViakIsU0FBUyxDQUFDUCxhQUFWLENBQXdCMUQ7SUFOekI7RUFGQSxDQUFQO0FBV0Q7O0FBRUQsT0FBTyxTQUFTdUUsZUFBVCxDQUNMSixTQURLLEVBRUxWLFFBRkssRUFHTDtFQUNBLElBQUksT0FBT0EsUUFBUCxLQUFvQixVQUF4QixFQUFvQztJQUNsQyxPQUFPMEIsa0JBQWtCLENBQUNoQixTQUFELEVBQVlWLFFBQVosQ0FBekI7RUFDRDs7RUFFRCxPQUFPMkIsaUJBQWlCLENBQUNqQixTQUFELEVBQVlWLFFBQVosQ0FBeEI7QUFDRDtBQUVELE9BQU8sU0FBU21CLG9CQUFULENBQThCVCxTQUE5QixFQUFvRHZCLEtBQXBELEVBQXdFO0VBQzdFLE9BQU95QyxhQUFhLENBQUNsQixTQUFELEVBQVltQix5QkFBeUIsQ0FBQzFDLEtBQUQsQ0FBckMsQ0FBcEI7QUFDRDtBQUVELE9BQU8sU0FBU3dDLGlCQUFULENBQTJCakIsU0FBM0IsRUFBaUR2QixLQUFqRCxFQUFxRTtFQUMxRSxPQUFPeUMsYUFBYSxDQUFDbEIsU0FBRCxFQUFZb0Isc0JBQXNCLENBQUMzQyxLQUFELENBQWxDLENBQXBCO0FBQ0Q7QUFFRCxPQUFPLFNBQVMrQixxQkFBVCxDQUNMUixTQURLLEVBRUxxQixPQUZLLEVBR0w7RUFDQSxPQUFPcEIsY0FBYyxDQUFRRCxTQUFSLEVBQW1CLENBQUN2QixLQUFELEVBQVE5QixLQUFSLEtBQ3RDMkUsWUFBWSxDQUFDN0MsS0FBRCxFQUFRNEMsT0FBTyxDQUFDMUUsS0FBRCxDQUFmLENBRE8sQ0FBckI7QUFHRDtBQUVELE9BQU8sU0FBU3FFLGtCQUFULENBQ0xoQixTQURLLEVBRUxxQixPQUZLLEVBR0w7RUFDQSxPQUFPcEIsY0FBYyxDQUFRRCxTQUFSLEVBQW1CLENBQUN2QixLQUFELEVBQVE5QixLQUFSLEtBQ3RDNEUsU0FBUyxDQUFDOUMsS0FBRCxFQUFRNEMsT0FBTyxDQUFDMUUsS0FBRCxDQUFmLENBRFUsQ0FBckI7QUFHRDtBQUVELE9BQU8sU0FBU3dFLHlCQUFULENBQ0wxQyxLQURLLEVBRWtDO0VBQ3ZDLE9BQU87SUFDTHNDLE9BQU8sRUFBRVMsVUFBVSxJQUFJRixZQUFZLENBQUNFLFVBQUQsRUFBYS9DLEtBQWIsQ0FEOUI7SUFFTGdELHFCQUFxQixFQUFFLElBRmxCO0lBR0xDLE9BQU8sRUFBRVAseUJBSEo7SUFJTDFDLEtBQUssRUFBRUE7RUFKRixDQUFQO0FBTUQ7QUFFRCxPQUFPLFNBQVMyQyxzQkFBVCxDQUNMM0MsS0FESyxFQUVrQztFQUN2QyxPQUFPO0lBQ0xzQyxPQUFPLEVBQUVTLFVBQVUsSUFBSUQsU0FBUyxDQUFDQyxVQUFELEVBQWEvQyxLQUFiLENBRDNCO0lBRUxnRCxxQkFBcUIsRUFBRSxJQUZsQjtJQUdMQyxPQUFPLEVBQUVOLHNCQUhKO0lBSUwzQyxLQUFLLEVBQUVBO0VBSkYsQ0FBUDtBQU1EO0FBRUQsT0FBTyxTQUFTeUMsYUFBVCxDQUNMbEIsU0FESyxFQUVMMkIsZ0JBRkssRUFHTDtFQUNBLElBQUkzQixTQUFTLENBQUNQLFFBQVYsQ0FBbUJxQixNQUFuQixLQUE4QixDQUFsQyxFQUFxQztJQUNuQyxNQUFNckMsS0FBSyxHQUFHa0QsZ0JBQWdCLENBQUNaLE9BQWpCLENBQXlCZixTQUFTLENBQUNuRSxlQUFWLEVBQXpCLENBQWQ7SUFDQSxNQUFNK0YsTUFBaUIsR0FBRztNQUN4Qm5DLFFBQVEsRUFBRU8sU0FBUyxDQUFDUCxRQURJO01BRXhCSixJQUFJLEVBQUVXLFNBQVMsQ0FBQ1gsSUFGUTtNQUd4QnpELE1BQU0sRUFBRW9FLFNBQVMsQ0FBQ3BFLE1BSE07TUFJeEJ1RCxPQUFPLEVBQUVhLFNBQVMsQ0FBQ2IsT0FKSztNQUt4QnRELGVBQWUsRUFBRSxNQUFNNEM7SUFMQyxDQUExQjs7SUFPQSxJQUFJLDhDQUFKLEVBQTRCO01BQzFCbUQsTUFBTSxDQUFDeEUsS0FBUCxHQUFlNEMsU0FBUyxDQUFDNUMsS0FBekI7SUFDRDs7SUFDRCxPQUFPd0UsTUFBUDtFQUNELENBYkQsTUFhTztJQUNMLE1BQU1DLElBQUksR0FBRzdCLFNBQVMsQ0FBQ1AsUUFBVixDQUFtQixDQUFuQixDQUFiOztJQUVBLElBQ0VvQyxJQUFJLENBQUNKLHFCQUFMLEtBQStCLElBQS9CLElBQ0FFLGdCQUFnQixDQUFDRixxQkFBakIsS0FBMkMsSUFGN0MsRUFHRTtNQUNBLE1BQU1sQixRQUFRLEdBQUdvQixnQkFBZ0IsQ0FBQ1osT0FBakIsQ0FBeUJjLElBQUksQ0FBQ3BELEtBQTlCLENBQWpCO01BRUEsTUFBTW1ELE1BQWlCLEdBQUc7UUFDeEIvRixlQUFlLEVBQUVtRSxTQUFTLENBQUNuRSxlQURIO1FBRXhCd0QsSUFBSSxFQUFFVyxTQUFTLENBQUNYLElBRlE7UUFHeEJ6RCxNQUFNLEVBQUVvRSxTQUFTLENBQUNwRSxNQUhNO1FBSXhCdUQsT0FBTyxFQUFFYSxTQUFTLENBQUNiLE9BSks7UUFLeEJNLFFBQVEsRUFBRSxDQUFDb0MsSUFBSSxDQUFDSCxPQUFMLENBQWFuQixRQUFiLENBQUQsRUFBeUJ1QixNQUF6QixDQUNSOUIsU0FBUyxDQUFDUCxRQUFWLENBQW1Cc0MsS0FBbkIsQ0FBeUIsQ0FBekIsQ0FEUTtNQUxjLENBQTFCOztNQVVBLElBQUksOENBQUosRUFBNEI7UUFDMUJILE1BQU0sQ0FBQ3hFLEtBQVAsR0FBZTRDLFNBQVMsQ0FBQzVDLEtBQXpCO01BQ0Q7O01BRUQsT0FBT3dFLE1BQVA7SUFDRDs7SUFFRCxPQUFPM0IsY0FBYyxDQUFDRCxTQUFELEVBQVkyQixnQkFBZ0IsQ0FBQ1osT0FBN0IsQ0FBckI7RUFDRDtBQUNGO0FBRUQsT0FBTyxTQUFTZCxjQUFULENBQ0xELFNBREssRUFFTGUsT0FGSyxFQUdMO0VBQ0EsTUFBTVIsUUFBbUIsR0FBRztJQUMxQjFFLGVBQWUsRUFBRW1FLFNBQVMsQ0FBQ25FLGVBREQ7SUFFMUJ3RCxJQUFJLEVBQUVXLFNBQVMsQ0FBQ1gsSUFGVTtJQUcxQnpELE1BQU0sRUFBRW9FLFNBQVMsQ0FBQ3BFLE1BSFE7SUFJMUJ1RCxPQUFPLEVBQUVhLFNBQVMsQ0FBQ2IsT0FKTztJQUsxQjtJQUNBTSxRQUFRLEVBQUUsQ0FBQztNQUFDZ0MscUJBQXFCLEVBQUUsS0FBeEI7TUFBK0JWO0lBQS9CLENBQUQsRUFBMENlLE1BQTFDLENBQ1I5QixTQUFTLENBQUNQLFFBREY7RUFOZ0IsQ0FBNUI7O0VBVUEsSUFBSSw4Q0FBSixFQUE0QjtJQUMxQmMsUUFBUSxDQUFDbkQsS0FBVCxHQUFpQjRDLFNBQVMsQ0FBQzVDLEtBQTNCO0VBQ0Q7O0VBQ0QsT0FBT21ELFFBQVA7QUFDRDtBQUVELE9BQU8sU0FBU1osNEJBQVQsQ0FBc0NLLFNBQXRDLEVBQTREO0VBQ2pFLE1BQU07SUFBQ1AsUUFBRDtJQUFXSixJQUFYO0lBQWlCekQsTUFBakI7SUFBeUJ1RCxPQUF6QjtJQUFrQ3RELGVBQWxDO0lBQW1ENkU7RUFBbkQsSUFBMERWLFNBQWhFOztFQUVBLElBQUksOENBQUosRUFBNEI7SUFDMUIsSUFBSWdDLGNBQUosRUFBb0JDLGVBQXBCOztJQUNBLElBQUlqQyxTQUFTLENBQUM1QyxLQUFkLEVBQXFCO01BQ25CNEUsY0FBYyxHQUFHaEMsU0FBUyxDQUFDNUMsS0FBVixDQUFnQjRCLFNBQWpDO01BQ0FpRCxlQUFlLEdBQUdqQyxTQUFTLENBQUM1QyxLQUFWLENBQWdCNkIsVUFBbEM7SUFDRDtFQUNGOztFQUVELElBQUksOENBQUosRUFBNEI7SUFDMUIsSUFBSVosY0FBSjtFQUNEOztFQUVELE1BQU02RCxhQUFhLGdCQUFHdkcsS0FBSyxDQUFDd0csVUFBTixDQUFzQyxDQUFDeEYsS0FBRCxFQUFReUYsR0FBUixLQUFnQjtJQUMxRSxNQUFNcEMsU0FBeUIsR0FBR3JFLEtBQUssQ0FBQ3dDLFVBQU4sQ0FBaUJoQyxnQkFBakIsQ0FBbEM7SUFDQSxNQUFNaUMsV0FBVyxHQUFHekMsS0FBSyxDQUFDd0MsVUFBTixDQUFpQjdCLGtCQUFqQixDQUFwQjtJQUNBLE1BQU1PLFNBQVMsR0FBR2xCLEtBQUssQ0FBQ3dDLFVBQU4sQ0FBaUI5QixnQkFBakIsQ0FBbEI7SUFDQXFCLGVBQWUsQ0FBQ3NDLFNBQUQsQ0FBZjtJQUVBLE1BQU1xQyxZQUFpQixHQUFHQyxnQkFBZ0IsQ0FBQzNGLEtBQUQsQ0FBMUM7SUFDQSxJQUFJOEIsS0FBSyxHQUFHOEQsWUFBWSxDQUFDMUcsZUFBRCxFQUFrQjRELFFBQWxCLEVBQTRCOUMsS0FBNUIsQ0FBeEI7O0lBRUEsSUFBSUEsS0FBSyxDQUFDNkYsTUFBVixFQUFrQjtNQUNoQixJQUFJLE9BQU83RixLQUFLLENBQUM2RixNQUFiLEtBQXdCLFVBQTVCLEVBQXdDO1FBQ3RDL0QsS0FBSyxHQUFHOEMsU0FBUyxDQUFDOUMsS0FBRCxFQUFROUIsS0FBSyxDQUFDNkYsTUFBTixDQUFhN0YsS0FBYixDQUFSLENBQWpCO01BQ0QsQ0FGRCxNQUVPO1FBQ0w4QixLQUFLLEdBQUc4QyxTQUFTLENBQUM5QyxLQUFELEVBQVE5QixLQUFLLENBQUM2RixNQUFkLENBQWpCO01BQ0Q7SUFDRjs7SUFFRCxNQUFNQyxnQkFBZ0IsR0FBRzdHLE1BQU0sQ0FBQzZDLEtBQUQsRUFBUXVCLFNBQVIsQ0FBL0I7SUFDQSxNQUFNMEMsT0FBTyxHQUFHL0YsS0FBSyxDQUFDZ0csR0FBTixHQUFZaEcsS0FBSyxDQUFDZ0csR0FBbEIsR0FBd0J0RCxJQUF4QztJQUNBZ0QsWUFBWSxDQUFDM0QsU0FBYixHQUF5Qi9CLEtBQUssQ0FBQytCLFNBQU4sR0FDcEIsR0FBRS9CLEtBQUssQ0FBQytCLFNBQVUsSUFBRytELGdCQUFpQixFQURsQixHQUVyQkEsZ0JBRko7O0lBSUEsSUFBSSxrREFBMEJyRSxXQUExQixJQUF5QyxDQUFDdkIsU0FBOUMsRUFBeUQ7TUFDdkQsSUFBSSxDQUFDd0IsY0FBTCxFQUFxQjtRQUNuQkEsY0FBYyxHQUFHRCxXQUFXLENBQUNoQixLQUFaLENBQWtCO1VBQ2pDNEIsU0FBUyxFQUFFZ0QsY0FEc0I7VUFFakMvQyxVQUFVLEVBQUVnRDtRQUZxQixDQUFsQixDQUFqQjtNQUlEOztNQUVELE1BQU1XLE1BQU0sR0FBSSxHQUFFdkUsY0FBZSxJQUFHZ0UsWUFBWSxDQUFDM0QsU0FBVSxFQUEzRDtNQUNBMkQsWUFBWSxDQUFDM0QsU0FBYixHQUF5QmtFLE1BQXpCO0lBQ0Q7O0lBRUQsSUFBSSxrREFBMEJyRixNQUFNLENBQUNDLHNCQUFyQyxFQUE2RDtNQUMzREQsTUFBTSxDQUFDQyxzQkFBUCxDQUE4QnFGLFNBQTlCLENBQXdDQyxHQUF4QyxDQUNFVCxZQUFZLENBQUMzRCxTQURmLEVBRUVELEtBRkY7O01BSUEsSUFBSWlDLEdBQUosRUFBUztRQUNQbkQsTUFBTSxDQUFDQyxzQkFBUCxDQUE4QnVGLGFBQTlCLENBQTRDRCxHQUE1QyxDQUNFVCxZQUFZLENBQUMzRCxTQURmLEVBRUU7VUFDRVcsSUFBSSxFQUFFcUIsR0FBRyxDQUFDckIsSUFEWjtVQUVFd0IsV0FBVyxFQUFFSCxHQUFHLENBQUNFLElBRm5CO1VBR0VvQyxhQUFhLEVBQUV0QyxHQUFHLENBQUM3RSxlQUFKLENBQW9CLEVBQXBCLEVBQXdCYyxLQUF4QixDQUhqQjtVQUlFc0csY0FBYyxFQUNaLE9BQU92QyxHQUFHLENBQUNDLElBQVgsS0FBb0IsVUFBcEIsR0FBaUNELEdBQUcsQ0FBQ0MsSUFBSixDQUFTaEUsS0FBVCxDQUFqQyxHQUFtRCtELEdBQUcsQ0FBQ0M7UUFMM0QsQ0FGRjtNQVVEO0lBQ0Y7O0lBRUQsSUFBSWhFLEtBQUssQ0FBQ3VHLElBQVYsRUFBZ0I7TUFDZDtNQUNBbkYsT0FBTyxDQUFDQyxJQUFSLENBQ0UsdUdBREY7SUFHRDs7SUFDRCxvQkFBTyxvQkFBQyxPQUFELGVBQWFxRSxZQUFiO01BQTJCLEdBQUcsRUFBRUQsR0FBRyxJQUFJekYsS0FBSyxDQUFDdUc7SUFBN0MsR0FBUDtFQUNELENBN0RxQixDQUF0QjtFQStEQSxNQUFNQyxPQUFPLEdBQUdoRSxPQUFPLENBQUMrQyxhQUFELENBQXZCO0VBQ0FpQixPQUFPLENBQUM1RCxhQUFSLEdBQXdCO0lBQ3RCRixJQURzQjtJQUV0QkksUUFGc0I7SUFHdEI3RCxNQUhzQjtJQUl0QnVELE9BSnNCO0lBS3RCdEQ7RUFMc0IsQ0FBeEI7O0VBUUEsMkNBQWE7SUFDWCxJQUFJZ0YsV0FBSjs7SUFFQSxJQUFJLE9BQU94QixJQUFQLEtBQWdCLFFBQXBCLEVBQThCO01BQzVCd0IsV0FBVyxHQUFHeEIsSUFBZDtJQUNELENBRkQsTUFFTyxJQUFJQSxJQUFJLENBQUN3QixXQUFULEVBQXNCO01BQzNCQSxXQUFXLEdBQUd4QixJQUFJLENBQUN3QixXQUFuQjtJQUNELENBRk0sTUFFQSxJQUFJeEIsSUFBSSxDQUFDdUIsSUFBVCxFQUFlO01BQ3BCQyxXQUFXLEdBQUd4QixJQUFJLENBQUN1QixJQUFuQjtJQUNELENBRk0sTUFFQTtNQUNMQyxXQUFXLEdBQUcsU0FBZDtJQUNEOztJQUVEc0MsT0FBTyxDQUFDdEMsV0FBUixHQUF1QixVQUFTQSxXQUFZLEdBQTVDO0VBQ0Q7O0VBRUQsT0FBT3NDLE9BQVA7QUFDRCxDLENBRUQ7O0FBRUEsT0FBTyxTQUFTWixZQUFULENBQ0wxRyxlQURLLEVBRUw0RCxRQUZLLEVBR0w5QyxLQUhLLEVBSVE7RUFDYixJQUFJaUYsTUFBTSxHQUFHL0YsZUFBZSxFQUE1QjtFQUNBLElBQUl1SCxDQUFDLEdBQUczRCxRQUFRLENBQUNxQixNQUFqQjs7RUFDQSxPQUFPc0MsQ0FBQyxFQUFSLEVBQVk7SUFDVjtJQUNBLE1BQU1yQyxPQUFPLEdBQUd0QixRQUFRLENBQUMyRCxDQUFELENBQVIsQ0FBWXJDLE9BQTVCO0lBSUFhLE1BQU0sR0FBR2IsT0FBTyxDQUFDYSxNQUFELEVBQVNqRixLQUFULENBQWhCO0VBQ0Q7O0VBQ0QsT0FBT2lGLE1BQVA7QUFDRDs7QUFFRCxTQUFTeUIsUUFBVCxDQUFrQkMsQ0FBbEIsRUFBMEI7RUFDeEIsT0FBTyxPQUFPQSxDQUFQLEtBQWEsUUFBYixJQUF5QkEsQ0FBQyxLQUFLLElBQXRDO0FBQ0Q7O0FBRUQsU0FBU2hCLGdCQUFULENBQTBCaUIsTUFBMUIsRUFBa0M7RUFDaEMsTUFBTTNCLE1BQU0sR0FBRyxFQUFmOztFQUVBLEtBQUssTUFBTTRCLEdBQVgsSUFBa0JELE1BQWxCLEVBQTBCO0lBQ3hCLElBQUlDLEdBQUcsQ0FBQyxDQUFELENBQUgsS0FBVyxHQUFmLEVBQW9CO01BQ2xCNUIsTUFBTSxDQUFDNEIsR0FBRCxDQUFOLEdBQWNELE1BQU0sQ0FBQ0MsR0FBRCxDQUFwQjtJQUNEO0VBQ0Y7O0VBRUQsT0FBTzVCLE1BQVA7QUFDRDs7QUFFRCxTQUFTTCxTQUFULENBQW1Ca0MsQ0FBbkIsRUFBc0JDLENBQXRCLEVBQXlCO0VBQ3ZCLE1BQU05QixNQUFNLEdBQUcrQixNQUFNLENBQUMsRUFBRCxFQUFLRixDQUFMLENBQXJCOztFQUVBLEtBQUssTUFBTUQsR0FBWCxJQUFrQkUsQ0FBbEIsRUFBcUI7SUFDbkIsTUFBTUUsR0FBRyxHQUFHRixDQUFDLENBQUNGLEdBQUQsQ0FBYjs7SUFFQSxJQUFJSCxRQUFRLENBQUNPLEdBQUQsQ0FBUixJQUFpQlAsUUFBUSxDQUFDSSxDQUFDLENBQUNELEdBQUQsQ0FBRixDQUE3QixFQUF1QztNQUNyQzVCLE1BQU0sQ0FBQzRCLEdBQUQsQ0FBTixHQUFjakMsU0FBUyxDQUFDa0MsQ0FBQyxDQUFDRCxHQUFELENBQUYsRUFBU0ksR0FBVCxDQUF2QjtJQUNELENBRkQsTUFFTztNQUNMaEMsTUFBTSxDQUFDNEIsR0FBRCxDQUFOLEdBQWNJLEdBQWQ7SUFDRDtFQUNGOztFQUVELE9BQU9oQyxNQUFQO0FBQ0Q7O0FBRUQsU0FBU04sWUFBVCxDQUFzQm1DLENBQXRCLEVBQXlCQyxDQUF6QixFQUE0QjtFQUMxQixPQUFPQyxNQUFNLENBQUNBLE1BQU0sQ0FBQyxFQUFELEVBQUtGLENBQUwsQ0FBUCxFQUFnQkMsQ0FBaEIsQ0FBYjtBQUNEOztBQUVELFNBQVNDLE1BQVQsQ0FBZ0JFLE1BQWhCLEVBQXdCTixNQUF4QixFQUFnQztFQUM5QixLQUFLLE1BQU1DLEdBQVgsSUFBa0JELE1BQWxCLEVBQTBCO0lBQ3hCTSxNQUFNLENBQUNMLEdBQUQsQ0FBTixHQUFjRCxNQUFNLENBQUNDLEdBQUQsQ0FBcEI7RUFDRDs7RUFDRCxPQUFPSyxNQUFQO0FBQ0QifQ==