"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
Object.defineProperty(exports, "DebugEngine", {
  enumerable: true,
  get: function () {
    return _devTool.DebugEngine;
  }
});
exports.Provider = void 0;
exports.autoComposeDeep = autoComposeDeep;
exports.autoComposeShallow = autoComposeShallow;
exports.composeDynamic = composeDynamic;
exports.composeStatic = composeStatic;
exports.createDeepMergeReducer = createDeepMergeReducer;
exports.createShallowMergeReducer = createShallowMergeReducer;
exports.createStyled = createStyled;
exports.createStyledElementComponent = createStyledElementComponent;
exports.dynamicComposeDeep = dynamicComposeDeep;
exports.dynamicComposeShallow = dynamicComposeShallow;
exports.resolveStyle = resolveStyle;
exports.staticComposeDeep = staticComposeDeep;
exports.staticComposeShallow = staticComposeShallow;
exports.styled = void 0;
exports.useStyletron = useStyletron;
exports.withWrapper = exports.withTransform = exports.withStyleDeep = exports.withStyle = void 0;

var React = _interopRequireWildcard(require("react"));

var _styletronStandard = require("styletron-standard");

var _devTool = require("./dev-tool");

function _getRequireWildcardCache(nodeInterop) { if (typeof WeakMap !== "function") return null; var cacheBabelInterop = new WeakMap(); var cacheNodeInterop = new WeakMap(); return (_getRequireWildcardCache = function (nodeInterop) { return nodeInterop ? cacheNodeInterop : cacheBabelInterop; })(nodeInterop); }

function _interopRequireWildcard(obj, nodeInterop) { if (!nodeInterop && obj && obj.__esModule) { return obj; } if (obj === null || typeof obj !== "object" && typeof obj !== "function") { return { default: obj }; } var cache = _getRequireWildcardCache(nodeInterop); if (cache && cache.has(obj)) { return cache.get(obj); } var newObj = {}; var hasPropertyDescriptor = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var key in obj) { if (key !== "default" && Object.prototype.hasOwnProperty.call(obj, key)) { var desc = hasPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : null; if (desc && (desc.get || desc.set)) { Object.defineProperty(newObj, key, desc); } else { newObj[key] = obj[key]; } } } newObj.default = obj; if (cache) { cache.set(obj, newObj); } return newObj; }

function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

const noopEngine = {
  renderStyle: () => "",
  renderKeyframes: () => "",
  renderFontFace: () => ""
};
const StyletronContext = /*#__PURE__*/React.createContext(noopEngine);
const HydrationContext = /*#__PURE__*/React.createContext(false);
const DebugEngineContext = /*#__PURE__*/React.createContext(undefined); //todo: theme context removed

class DevProvider extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      hydrating: Boolean(props.debugAfterHydration)
    };
  }

  componentDidMount() {
    if (true) {
      if (this.state.hydrating === true) {
        this.setState({
          hydrating: false
        });
      }
    }
  }

  render() {
    return /*#__PURE__*/React.createElement(StyletronContext.Provider, {
      value: this.props.value
    }, /*#__PURE__*/React.createElement(DebugEngineContext.Provider, {
      value: this.props.debug
    }, /*#__PURE__*/React.createElement(HydrationContext.Provider, {
      value: this.state.hydrating
    }, this.props.children)));
  }

}

const Provider = true && process.env.NODE_ENV !== "production" ? DevProvider : StyletronContext.Provider;
exports.Provider = Provider;

if (true && process.env.NODE_ENV !== "production" && !window.__STYLETRON_DEVTOOLS__) {
  (0, _devTool.setupDevtoolsExtension)();
}

function checkNoopEngine(engine) {
  // if no engine provided, we default to no-op, handy for tests
  // however, print a warning in other envs
  if (process.env.NODE_ENV !== "test") {
    engine === noopEngine && // eslint-disable-next-line no-console
    console.warn(process.env.NODE_ENV !== "production" ? `
Styletron has been switched to a no-op (test) mode.

A Styletron styled component was rendered, but no Styletron engine instance was provided in React context.

Did you forget to provide a Styletron engine instance to React context via using the Styletron provider component?

Note: Providers and Consumers must come from the exact same React.createContext call to work.
If your app has multiple instances of the "styletron-react" package in your node_module tree,
your Provider may be coming from a different React.createContext call, which means the styled components
will not recieve the provided engine instance. This scenario can arise, for example, when using "npm link".
` : `Styletron Provider is not set up. Defaulting to no-op.`);
  }
}

function useStyletron() {
  const styletronEngine = React.useContext(StyletronContext);
  const debugEngine = React.useContext(DebugEngineContext);
  const hydrating = React.useContext(HydrationContext);
  checkNoopEngine(styletronEngine);
  const debugClassName = React.useRef("");
  const prevDebugClassNameDeps = React.useRef([]);
  return [function css(style) {
    const className = (0, _styletronStandard.driver)(style, styletronEngine);

    if (!(true && process.env.NODE_ENV !== "production")) {
      return className;
    }

    const {
      stack,
      message
    } = new Error("stacktrace source");
    const nextDeps = [debugEngine, hydrating];

    if (prevDebugClassNameDeps.current[0] !== nextDeps[0] || prevDebugClassNameDeps.current[1] !== nextDeps[1]) {
      if (debugEngine && !hydrating) {
        debugClassName.current = debugEngine.debug({
          stackInfo: {
            stack,
            message
          },
          stackIndex: 1
        });
      }

      prevDebugClassNameDeps.current = nextDeps;
    }

    if (debugClassName.current) {
      return `${debugClassName.current} ${className}`;
    }

    return className;
  }];
}

function createStyled({
  getInitialStyle,
  driver,
  wrapper
}) {
  function styled(base, styleArg) {
    if (process.env.NODE_ENV !== "production") {
      if (base.__STYLETRON__) {
        /* eslint-disable no-console */
        console.warn("It appears you are passing a styled component into `styled`.");
        console.warn("For composition with existing styled components, use `withStyle` or `withTransform` instead.");
        /* eslint-enable no-console */
      }
    }

    const baseStyletron = {
      reducers: [],
      base: base,
      driver,
      getInitialStyle,
      wrapper
    };

    if (true && process.env.NODE_ENV !== "production") {
      (0, _devTool.addDebugMetadata)(baseStyletron, 2);
    }

    return createStyledElementComponent(autoComposeShallow(baseStyletron, styleArg));
  }

  return styled;
}

const styled = createStyled({
  getInitialStyle: _styletronStandard.getInitialStyle,
  driver: _styletronStandard.driver,
  wrapper: Component => Component
});
exports.styled = styled;

const withTransform = (component, transformer) => {
  const styletron = component.__STYLETRON__;

  if (true && process.env.NODE_ENV !== "production") {
    (0, _devTool.addDebugMetadata)(styletron, 2);
  }

  return createStyledElementComponent(composeDynamic(styletron, transformer));
};

exports.withTransform = withTransform;

const withStyleDeep = (component, styleArg) => {
  // @ts-ignore
  const styletron = component.__STYLETRON__;

  if (process.env.NODE_ENV !== "production") {
    if (!styletron) {
      /* eslint-disable no-console */
      console.warn("The first parameter to `withStyle` must be a styled component (without extra wrappers).");
      /* eslint-enable no-console */
    }
  }

  if (true && process.env.NODE_ENV !== "production") {
    (0, _devTool.addDebugMetadata)(styletron, 2);
    return createStyledElementComponent(addExtension(autoComposeDeep(styletron, styleArg), component, styleArg));
  } else {
    return createStyledElementComponent(autoComposeDeep(styletron, styleArg));
  }
};

exports.withStyleDeep = withStyleDeep;
const withStyle = withStyleDeep;
exports.withStyle = withStyle;

const withWrapper = (component, wrapper) => {
  const styletron = component.__STYLETRON__;

  if (process.env.NODE_ENV !== "production") {
    if (!styletron) {
      /* eslint-disable no-console */
      console.warn("The first parameter to `withWrapper` must be a styled component (without extra wrappers).");
      /* eslint-enable no-console */
    }
  }

  const composed = {
    getInitialStyle: styletron.getInitialStyle,
    base: styletron.base,
    driver: styletron.driver,
    wrapper: wrapper,
    reducers: styletron.reducers
  };

  if (true && process.env.NODE_ENV !== "production") {
    (0, _devTool.addDebugMetadata)(composed, 2);
  }

  return createStyledElementComponent(composed);
};

exports.withWrapper = withWrapper;

function autoComposeShallow(styletron, styleArg) {
  if (typeof styleArg === "function") {
    return dynamicComposeShallow(styletron, styleArg);
  }

  return staticComposeShallow(styletron, styleArg);
}

function addExtension(composed, component, styleArg) {
  return { ...composed,
    ext: {
      with: styleArg,
      name: component.displayName,
      base: component.__STYLETRON__.base,
      getInitialStyle: component.__STYLETRON__.reducers.length ? component.__STYLETRON__.reducers[0].reducer : component.__STYLETRON__.getInitialStyle
    }
  };
}

function autoComposeDeep(styletron, styleArg) {
  if (typeof styleArg === "function") {
    return dynamicComposeDeep(styletron, styleArg);
  }

  return staticComposeDeep(styletron, styleArg);
}

function staticComposeShallow(styletron, style) {
  return composeStatic(styletron, createShallowMergeReducer(style));
}

function staticComposeDeep(styletron, style) {
  return composeStatic(styletron, createDeepMergeReducer(style));
}

function dynamicComposeShallow(styletron, styleFn) {
  return composeDynamic(styletron, (style, props) => shallowMerge(style, styleFn(props)));
}

function dynamicComposeDeep(styletron, styleFn) {
  return composeDynamic(styletron, (style, props) => deepMerge(style, styleFn(props)));
}

function createShallowMergeReducer(style) {
  return {
    reducer: inputStyle => shallowMerge(inputStyle, style),
    assignmentCommutative: true,
    factory: createShallowMergeReducer,
    style: style
  };
}

function createDeepMergeReducer(style) {
  return {
    reducer: inputStyle => deepMerge(inputStyle, style),
    assignmentCommutative: true,
    factory: createDeepMergeReducer,
    style: style
  };
}

function composeStatic(styletron, reducerContainer) {
  if (styletron.reducers.length === 0) {
    const style = reducerContainer.reducer(styletron.getInitialStyle());
    const result = {
      reducers: styletron.reducers,
      base: styletron.base,
      driver: styletron.driver,
      wrapper: styletron.wrapper,
      getInitialStyle: () => style
    };

    if (true && process.env.NODE_ENV !== "production") {
      result.debug = styletron.debug;
    }

    return result;
  } else {
    const last = styletron.reducers[0];

    if (last.assignmentCommutative === true && reducerContainer.assignmentCommutative === true) {
      const composed = reducerContainer.reducer(last.style);
      const result = {
        getInitialStyle: styletron.getInitialStyle,
        base: styletron.base,
        driver: styletron.driver,
        wrapper: styletron.wrapper,
        reducers: [last.factory(composed)].concat(styletron.reducers.slice(1))
      };

      if (true && process.env.NODE_ENV !== "production") {
        result.debug = styletron.debug;
      }

      return result;
    }

    return composeDynamic(styletron, reducerContainer.reducer);
  }
}

function composeDynamic(styletron, reducer) {
  const composed = {
    getInitialStyle: styletron.getInitialStyle,
    base: styletron.base,
    driver: styletron.driver,
    wrapper: styletron.wrapper,
    // @ts-ignore
    reducers: [{
      assignmentCommutative: false,
      reducer
    }].concat(styletron.reducers)
  };

  if (true && process.env.NODE_ENV !== "production") {
    composed.debug = styletron.debug;
  }

  return composed;
}

function createStyledElementComponent(styletron) {
  const {
    reducers,
    base,
    driver,
    wrapper,
    getInitialStyle,
    ext
  } = styletron;

  if (true && process.env.NODE_ENV !== "production") {
    var debugStackInfo, debugStackIndex;

    if (styletron.debug) {
      debugStackInfo = styletron.debug.stackInfo;
      debugStackIndex = styletron.debug.stackIndex;
    }
  }

  if (true && process.env.NODE_ENV !== "production") {
    var debugClassName;
  }

  const StyledElement = /*#__PURE__*/React.forwardRef((props, ref) => {
    const styletron = React.useContext(StyletronContext);
    const debugEngine = React.useContext(DebugEngineContext);
    const hydrating = React.useContext(HydrationContext);
    checkNoopEngine(styletron);
    const elementProps = omitPrefixedKeys(props);
    let style = resolveStyle(getInitialStyle, reducers, props);

    if (props.$style) {
      if (typeof props.$style === "function") {
        style = deepMerge(style, props.$style(props));
      } else {
        style = deepMerge(style, props.$style);
      }
    }

    const styleClassString = driver(style, styletron);
    const Element = props.$as ? props.$as : base;
    elementProps.className = props.className ? `${props.className} ${styleClassString}` : styleClassString;

    if (true && process.env.NODE_ENV !== "production" && debugEngine && !hydrating) {
      if (!debugClassName) {
        debugClassName = debugEngine.debug({
          stackInfo: debugStackInfo,
          stackIndex: debugStackIndex
        });
      }

      const joined = `${debugClassName} ${elementProps.className}`;
      elementProps.className = joined;
    }

    if (true && process.env.NODE_ENV !== "production" && window.__STYLETRON_DEVTOOLS__) {
      window.__STYLETRON_DEVTOOLS__.stylesMap.set(elementProps.className, style);

      if (ext) {
        window.__STYLETRON_DEVTOOLS__.extensionsMap.set(elementProps.className, {
          base: ext.base,
          displayName: ext.name,
          initialStyles: ext.getInitialStyle({}, props),
          styleOverrides: typeof ext.with === "function" ? ext.with(props) : ext.with
        });
      }
    }

    if (props.$ref) {
      // eslint-disable-next-line no-console
      console.warn("The prop `$ref` has been deprecated. Use `ref` instead. Refs are now forwarded with React.forwardRef.");
    }

    return /*#__PURE__*/React.createElement(Element, _extends({}, elementProps, {
      ref: ref || props.$ref
    }));
  });
  const Wrapped = wrapper(StyledElement);
  Wrapped.__STYLETRON__ = {
    base,
    reducers,
    driver,
    wrapper,
    getInitialStyle
  };

  if (process.env.NODE_ENV !== "production") {
    let displayName;

    if (typeof base === "string") {
      displayName = base;
    } else if (base.displayName) {
      displayName = base.displayName;
    } else if (base.name) {
      displayName = base.name;
    } else {
      displayName = "Unknown";
    }

    Wrapped.displayName = `Styled(${displayName})`;
  }

  return Wrapped;
} // Utility functions


function resolveStyle(getInitialStyle, reducers, props) {
  let result = getInitialStyle();
  let i = reducers.length;

  while (i--) {
    // Cast to allow passing unused props param in case of static reducer
    const reducer = reducers[i].reducer;
    result = reducer(result, props);
  }

  return result;
}

function isObject(x) {
  return typeof x === "object" && x !== null;
}

function omitPrefixedKeys(source) {
  const result = {};

  for (const key in source) {
    if (key[0] !== "$") {
      result[key] = source[key];
    }
  }

  return result;
}

function deepMerge(a, b) {
  const result = assign({}, a);

  for (const key in b) {
    const val = b[key];

    if (isObject(val) && isObject(a[key])) {
      result[key] = deepMerge(a[key], val);
    } else {
      result[key] = val;
    }
  }

  return result;
}

function shallowMerge(a, b) {
  return assign(assign({}, a), b);
}

function assign(target, source) {
  for (const key in source) {
    target[key] = source[key];
  }

  return target;
}
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJub29wRW5naW5lIiwicmVuZGVyU3R5bGUiLCJyZW5kZXJLZXlmcmFtZXMiLCJyZW5kZXJGb250RmFjZSIsIlN0eWxldHJvbkNvbnRleHQiLCJSZWFjdCIsImNyZWF0ZUNvbnRleHQiLCJIeWRyYXRpb25Db250ZXh0IiwiRGVidWdFbmdpbmVDb250ZXh0IiwidW5kZWZpbmVkIiwiRGV2UHJvdmlkZXIiLCJDb21wb25lbnQiLCJjb25zdHJ1Y3RvciIsInByb3BzIiwic3RhdGUiLCJoeWRyYXRpbmciLCJCb29sZWFuIiwiZGVidWdBZnRlckh5ZHJhdGlvbiIsImNvbXBvbmVudERpZE1vdW50Iiwic2V0U3RhdGUiLCJyZW5kZXIiLCJ2YWx1ZSIsImRlYnVnIiwiY2hpbGRyZW4iLCJQcm92aWRlciIsIndpbmRvdyIsIl9fU1RZTEVUUk9OX0RFVlRPT0xTX18iLCJzZXR1cERldnRvb2xzRXh0ZW5zaW9uIiwiY2hlY2tOb29wRW5naW5lIiwiZW5naW5lIiwicHJvY2VzcyIsImVudiIsIk5PREVfRU5WIiwiY29uc29sZSIsIndhcm4iLCJ1c2VTdHlsZXRyb24iLCJzdHlsZXRyb25FbmdpbmUiLCJ1c2VDb250ZXh0IiwiZGVidWdFbmdpbmUiLCJkZWJ1Z0NsYXNzTmFtZSIsInVzZVJlZiIsInByZXZEZWJ1Z0NsYXNzTmFtZURlcHMiLCJjc3MiLCJzdHlsZSIsImNsYXNzTmFtZSIsImRyaXZlciIsInN0YWNrIiwibWVzc2FnZSIsIkVycm9yIiwibmV4dERlcHMiLCJjdXJyZW50Iiwic3RhY2tJbmZvIiwic3RhY2tJbmRleCIsImNyZWF0ZVN0eWxlZCIsImdldEluaXRpYWxTdHlsZSIsIndyYXBwZXIiLCJzdHlsZWQiLCJiYXNlIiwic3R5bGVBcmciLCJfX1NUWUxFVFJPTl9fIiwiYmFzZVN0eWxldHJvbiIsInJlZHVjZXJzIiwiYWRkRGVidWdNZXRhZGF0YSIsImNyZWF0ZVN0eWxlZEVsZW1lbnRDb21wb25lbnQiLCJhdXRvQ29tcG9zZVNoYWxsb3ciLCJ3aXRoVHJhbnNmb3JtIiwiY29tcG9uZW50IiwidHJhbnNmb3JtZXIiLCJzdHlsZXRyb24iLCJjb21wb3NlRHluYW1pYyIsIndpdGhTdHlsZURlZXAiLCJhZGRFeHRlbnNpb24iLCJhdXRvQ29tcG9zZURlZXAiLCJ3aXRoU3R5bGUiLCJ3aXRoV3JhcHBlciIsImNvbXBvc2VkIiwiZHluYW1pY0NvbXBvc2VTaGFsbG93Iiwic3RhdGljQ29tcG9zZVNoYWxsb3ciLCJleHQiLCJ3aXRoIiwibmFtZSIsImRpc3BsYXlOYW1lIiwibGVuZ3RoIiwicmVkdWNlciIsImR5bmFtaWNDb21wb3NlRGVlcCIsInN0YXRpY0NvbXBvc2VEZWVwIiwiY29tcG9zZVN0YXRpYyIsImNyZWF0ZVNoYWxsb3dNZXJnZVJlZHVjZXIiLCJjcmVhdGVEZWVwTWVyZ2VSZWR1Y2VyIiwic3R5bGVGbiIsInNoYWxsb3dNZXJnZSIsImRlZXBNZXJnZSIsImlucHV0U3R5bGUiLCJhc3NpZ25tZW50Q29tbXV0YXRpdmUiLCJmYWN0b3J5IiwicmVkdWNlckNvbnRhaW5lciIsInJlc3VsdCIsImxhc3QiLCJjb25jYXQiLCJzbGljZSIsImRlYnVnU3RhY2tJbmZvIiwiZGVidWdTdGFja0luZGV4IiwiU3R5bGVkRWxlbWVudCIsImZvcndhcmRSZWYiLCJyZWYiLCJlbGVtZW50UHJvcHMiLCJvbWl0UHJlZml4ZWRLZXlzIiwicmVzb2x2ZVN0eWxlIiwiJHN0eWxlIiwic3R5bGVDbGFzc1N0cmluZyIsIkVsZW1lbnQiLCIkYXMiLCJqb2luZWQiLCJzdHlsZXNNYXAiLCJzZXQiLCJleHRlbnNpb25zTWFwIiwiaW5pdGlhbFN0eWxlcyIsInN0eWxlT3ZlcnJpZGVzIiwiJHJlZiIsIldyYXBwZWQiLCJpIiwiaXNPYmplY3QiLCJ4Iiwic291cmNlIiwia2V5IiwiYSIsImIiLCJhc3NpZ24iLCJ2YWwiLCJ0YXJnZXQiXSwic291cmNlcyI6WyJzcmMvaW5kZXgudHN4Il0sInNvdXJjZXNDb250ZW50IjpbIi8qIGVzbGludC1lbnYgYnJvd3NlciAqL1xuLyogZXNsaW50LWRpc2FibGUgbm8tdW51c2VkLXZhcnMsIG5vLXJlZGVjbGFyZSwgbm8tc2hhZG93ICovXG5cbmRlY2xhcmUgdmFyIF9fREVWX186IGJvb2xlYW47XG5cbmRlY2xhcmUgdmFyIF9fQlJPV1NFUl9fOiBib29sZWFuO1xuZGVjbGFyZSBnbG9iYWwge1xuICBpbnRlcmZhY2UgV2luZG93IHtcbiAgICBfX1NUWUxFVFJPTl9ERVZUT09MU19fOiBhbnk7XG4gIH1cbn1cblxuZGVjbGFyZSB2YXIgcHJvY2VzczogYW55O1xuXG5pbXBvcnQgKiBhcyBSZWFjdCBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCB7XG4gIGRyaXZlcixcbiAgZ2V0SW5pdGlhbFN0eWxlLFxuICB0eXBlIFN0YW5kYXJkRW5naW5lLFxuICB0eXBlIFN0eWxlT2JqZWN0LFxufSBmcm9tIFwic3R5bGV0cm9uLXN0YW5kYXJkXCI7XG5cbmltcG9ydCB0eXBlIHtcbiAgU3R5bGV0cm9uLFxuICBTdHlsZXRyb25Db21wb25lbnQsXG4gIFJlZHVjZXJDb250YWluZXIsXG4gIEFzc2lnbm1lbnRDb21tdXRhdGl2ZVJlZHVjZXJDb250YWluZXIsXG4gIE5vbkFzc2lnbm1lbnRDb21tdXRhdGl2ZVJlZHVjZXJDb250YWluZXIsXG4gIFN0eWxlZEZuLFxuICBXaXRoU3R5bGVGbixcbiAgV2l0aFRyYW5zZm9ybUZuLFxuICBXaXRoV3JhcHBlckZuLFxuICBTdHlsZXRyb25Qcm9wcyxcbn0gZnJvbSBcIi4vdHlwZXNcIjtcbmltcG9ydCB7XG4gIGFkZERlYnVnTWV0YWRhdGEsXG4gIHNldHVwRGV2dG9vbHNFeHRlbnNpb24sXG4gIERlYnVnRW5naW5lLFxufSBmcm9tIFwiLi9kZXYtdG9vbFwiO1xuXG5leHBvcnQge0RlYnVnRW5naW5lfTtcbmV4cG9ydCB0eXBlIHtTdHlsZU9iamVjdH07XG5leHBvcnQgdHlwZSB7U3R5bGV0cm9uUHJvcHN9O1xuZXhwb3J0IHR5cGUge1N0eWxldHJvbkNvbXBvbmVudH07XG5cbmNvbnN0IG5vb3BFbmdpbmUgPSB7XG4gIHJlbmRlclN0eWxlOiAoKSA9PiBcIlwiLFxuICByZW5kZXJLZXlmcmFtZXM6ICgpID0+IFwiXCIsXG4gIHJlbmRlckZvbnRGYWNlOiAoKSA9PiBcIlwiLFxufTtcblxuY29uc3QgU3R5bGV0cm9uQ29udGV4dCA9IFJlYWN0LmNyZWF0ZUNvbnRleHQ8U3RhbmRhcmRFbmdpbmU+KG5vb3BFbmdpbmUpO1xuY29uc3QgSHlkcmF0aW9uQ29udGV4dCA9IFJlYWN0LmNyZWF0ZUNvbnRleHQoZmFsc2UpO1xuY29uc3QgRGVidWdFbmdpbmVDb250ZXh0ID0gUmVhY3QuY3JlYXRlQ29udGV4dDxcbiAgSW5zdGFuY2VUeXBlPHR5cGVvZiBEZWJ1Z0VuZ2luZT4gfCB1bmRlZmluZWRcbj4odW5kZWZpbmVkKTtcbi8vdG9kbzogdGhlbWUgY29udGV4dCByZW1vdmVkXG5cbnR5cGUgRGV2UHJvdmlkZXJQcm9wcyA9IHtcbiAgY2hpbGRyZW46IFJlYWN0LlJlYWN0Tm9kZTtcbiAgdmFsdWU6IFN0YW5kYXJkRW5naW5lO1xuICBkZWJ1Z0FmdGVySHlkcmF0aW9uPzogYm9vbGVhbjtcbiAgZGVidWc/OiBhbnk7XG59O1xuXG5jbGFzcyBEZXZQcm92aWRlciBleHRlbmRzIFJlYWN0LkNvbXBvbmVudDxcbiAgRGV2UHJvdmlkZXJQcm9wcyxcbiAge1xuICAgIGh5ZHJhdGluZzogYm9vbGVhbjtcbiAgfVxuPiB7XG4gIGNvbnN0cnVjdG9yKHByb3BzOiBEZXZQcm92aWRlclByb3BzKSB7XG4gICAgc3VwZXIocHJvcHMpO1xuICAgIHRoaXMuc3RhdGUgPSB7XG4gICAgICBoeWRyYXRpbmc6IEJvb2xlYW4ocHJvcHMuZGVidWdBZnRlckh5ZHJhdGlvbiksXG4gICAgfTtcbiAgfVxuXG4gIGNvbXBvbmVudERpZE1vdW50KCkge1xuICAgIGlmIChfX0JST1dTRVJfXykge1xuICAgICAgaWYgKHRoaXMuc3RhdGUuaHlkcmF0aW5nID09PSB0cnVlKSB7XG4gICAgICAgIHRoaXMuc2V0U3RhdGUoe1xuICAgICAgICAgIGh5ZHJhdGluZzogZmFsc2UsXG4gICAgICAgIH0pO1xuICAgICAgfVxuICAgIH1cbiAgfVxuXG4gIHJlbmRlcigpIHtcbiAgICByZXR1cm4gKFxuICAgICAgPFN0eWxldHJvbkNvbnRleHQuUHJvdmlkZXIgdmFsdWU9e3RoaXMucHJvcHMudmFsdWV9PlxuICAgICAgICA8RGVidWdFbmdpbmVDb250ZXh0LlByb3ZpZGVyIHZhbHVlPXt0aGlzLnByb3BzLmRlYnVnfT5cbiAgICAgICAgICA8SHlkcmF0aW9uQ29udGV4dC5Qcm92aWRlciB2YWx1ZT17dGhpcy5zdGF0ZS5oeWRyYXRpbmd9PlxuICAgICAgICAgICAge3RoaXMucHJvcHMuY2hpbGRyZW59XG4gICAgICAgICAgPC9IeWRyYXRpb25Db250ZXh0LlByb3ZpZGVyPlxuICAgICAgICA8L0RlYnVnRW5naW5lQ29udGV4dC5Qcm92aWRlcj5cbiAgICAgIDwvU3R5bGV0cm9uQ29udGV4dC5Qcm92aWRlcj5cbiAgICApO1xuICB9XG59XG5cbmV4cG9ydCBjb25zdCBQcm92aWRlciA9XG4gIF9fQlJPV1NFUl9fICYmIF9fREVWX18gPyBEZXZQcm92aWRlciA6IFN0eWxldHJvbkNvbnRleHQuUHJvdmlkZXI7XG5cbmlmIChfX0JST1dTRVJfXyAmJiBfX0RFVl9fICYmICF3aW5kb3cuX19TVFlMRVRST05fREVWVE9PTFNfXykge1xuICBzZXR1cERldnRvb2xzRXh0ZW5zaW9uKCk7XG59XG5cbnR5cGUgY3JlYXRlU3R5bGVkT3B0cyA9IHtcbiAgZ2V0SW5pdGlhbFN0eWxlOiAoKSA9PiBTdHlsZU9iamVjdDtcbiAgZHJpdmVyOiB0eXBlb2YgZHJpdmVyO1xuICB3cmFwcGVyOiAoZmM6IFJlYWN0LkZDPGFueT4pID0+IFJlYWN0LkNvbXBvbmVudFR5cGU8YW55Pjtcbn07XG5cbmZ1bmN0aW9uIGNoZWNrTm9vcEVuZ2luZShlbmdpbmU6IFN0YW5kYXJkRW5naW5lKSB7XG4gIC8vIGlmIG5vIGVuZ2luZSBwcm92aWRlZCwgd2UgZGVmYXVsdCB0byBuby1vcCwgaGFuZHkgZm9yIHRlc3RzXG4gIC8vIGhvd2V2ZXIsIHByaW50IGEgd2FybmluZyBpbiBvdGhlciBlbnZzXG4gIGlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJ0ZXN0XCIpIHtcbiAgICBlbmdpbmUgPT09IG5vb3BFbmdpbmUgJiZcbiAgICAgIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBuby1jb25zb2xlXG4gICAgICBjb25zb2xlLndhcm4oXG4gICAgICAgIF9fREVWX19cbiAgICAgICAgICA/IGBcblN0eWxldHJvbiBoYXMgYmVlbiBzd2l0Y2hlZCB0byBhIG5vLW9wICh0ZXN0KSBtb2RlLlxuXG5BIFN0eWxldHJvbiBzdHlsZWQgY29tcG9uZW50IHdhcyByZW5kZXJlZCwgYnV0IG5vIFN0eWxldHJvbiBlbmdpbmUgaW5zdGFuY2Ugd2FzIHByb3ZpZGVkIGluIFJlYWN0IGNvbnRleHQuXG5cbkRpZCB5b3UgZm9yZ2V0IHRvIHByb3ZpZGUgYSBTdHlsZXRyb24gZW5naW5lIGluc3RhbmNlIHRvIFJlYWN0IGNvbnRleHQgdmlhIHVzaW5nIHRoZSBTdHlsZXRyb24gcHJvdmlkZXIgY29tcG9uZW50P1xuXG5Ob3RlOiBQcm92aWRlcnMgYW5kIENvbnN1bWVycyBtdXN0IGNvbWUgZnJvbSB0aGUgZXhhY3Qgc2FtZSBSZWFjdC5jcmVhdGVDb250ZXh0IGNhbGwgdG8gd29yay5cbklmIHlvdXIgYXBwIGhhcyBtdWx0aXBsZSBpbnN0YW5jZXMgb2YgdGhlIFwic3R5bGV0cm9uLXJlYWN0XCIgcGFja2FnZSBpbiB5b3VyIG5vZGVfbW9kdWxlIHRyZWUsXG55b3VyIFByb3ZpZGVyIG1heSBiZSBjb21pbmcgZnJvbSBhIGRpZmZlcmVudCBSZWFjdC5jcmVhdGVDb250ZXh0IGNhbGwsIHdoaWNoIG1lYW5zIHRoZSBzdHlsZWQgY29tcG9uZW50c1xud2lsbCBub3QgcmVjaWV2ZSB0aGUgcHJvdmlkZWQgZW5naW5lIGluc3RhbmNlLiBUaGlzIHNjZW5hcmlvIGNhbiBhcmlzZSwgZm9yIGV4YW1wbGUsIHdoZW4gdXNpbmcgXCJucG0gbGlua1wiLlxuYFxuICAgICAgICAgIDogYFN0eWxldHJvbiBQcm92aWRlciBpcyBub3Qgc2V0IHVwLiBEZWZhdWx0aW5nIHRvIG5vLW9wLmAsXG4gICAgICApO1xuICB9XG59XG5cbmV4cG9ydCBmdW5jdGlvbiB1c2VTdHlsZXRyb24oKTogWyhzdHlsZTogU3R5bGVPYmplY3QpID0+IHN0cmluZ10ge1xuICBjb25zdCBzdHlsZXRyb25FbmdpbmU6IFN0YW5kYXJkRW5naW5lID0gUmVhY3QudXNlQ29udGV4dChTdHlsZXRyb25Db250ZXh0KTtcbiAgY29uc3QgZGVidWdFbmdpbmUgPSBSZWFjdC51c2VDb250ZXh0KERlYnVnRW5naW5lQ29udGV4dCk7XG4gIGNvbnN0IGh5ZHJhdGluZyA9IFJlYWN0LnVzZUNvbnRleHQoSHlkcmF0aW9uQ29udGV4dCk7XG4gIGNoZWNrTm9vcEVuZ2luZShzdHlsZXRyb25FbmdpbmUpO1xuXG4gIGNvbnN0IGRlYnVnQ2xhc3NOYW1lID0gUmVhY3QudXNlUmVmPHN0cmluZyB8IHVuZGVmaW5lZD4oXCJcIik7XG4gIGNvbnN0IHByZXZEZWJ1Z0NsYXNzTmFtZURlcHMgPSBSZWFjdC51c2VSZWYoW10pO1xuXG4gIHJldHVybiBbXG4gICAgZnVuY3Rpb24gY3NzKHN0eWxlOiBTdHlsZU9iamVjdCkge1xuICAgICAgY29uc3QgY2xhc3NOYW1lID0gZHJpdmVyKHN0eWxlLCBzdHlsZXRyb25FbmdpbmUpO1xuICAgICAgaWYgKCEoX19CUk9XU0VSX18gJiYgX19ERVZfXykpIHtcbiAgICAgICAgcmV0dXJuIGNsYXNzTmFtZTtcbiAgICAgIH1cbiAgICAgIGNvbnN0IHtzdGFjaywgbWVzc2FnZX0gPSBuZXcgRXJyb3IoXCJzdGFja3RyYWNlIHNvdXJjZVwiKTtcblxuICAgICAgY29uc3QgbmV4dERlcHMgPSBbZGVidWdFbmdpbmUsIGh5ZHJhdGluZ107XG4gICAgICBpZiAoXG4gICAgICAgIHByZXZEZWJ1Z0NsYXNzTmFtZURlcHMuY3VycmVudFswXSAhPT0gbmV4dERlcHNbMF0gfHxcbiAgICAgICAgcHJldkRlYnVnQ2xhc3NOYW1lRGVwcy5jdXJyZW50WzFdICE9PSBuZXh0RGVwc1sxXVxuICAgICAgKSB7XG4gICAgICAgIGlmIChkZWJ1Z0VuZ2luZSAmJiAhaHlkcmF0aW5nKSB7XG4gICAgICAgICAgZGVidWdDbGFzc05hbWUuY3VycmVudCA9IGRlYnVnRW5naW5lLmRlYnVnKHtcbiAgICAgICAgICAgIHN0YWNrSW5mbzoge3N0YWNrLCBtZXNzYWdlfSxcbiAgICAgICAgICAgIHN0YWNrSW5kZXg6IDEsXG4gICAgICAgICAgfSk7XG4gICAgICAgIH1cbiAgICAgICAgcHJldkRlYnVnQ2xhc3NOYW1lRGVwcy5jdXJyZW50ID0gbmV4dERlcHM7XG4gICAgICB9XG5cbiAgICAgIGlmIChkZWJ1Z0NsYXNzTmFtZS5jdXJyZW50KSB7XG4gICAgICAgIHJldHVybiBgJHtkZWJ1Z0NsYXNzTmFtZS5jdXJyZW50fSAke2NsYXNzTmFtZX1gO1xuICAgICAgfVxuXG4gICAgICByZXR1cm4gY2xhc3NOYW1lO1xuICAgIH0sXG4gIF07XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBjcmVhdGVTdHlsZWQoe1xuICBnZXRJbml0aWFsU3R5bGUsXG4gIGRyaXZlcixcbiAgd3JhcHBlcixcbn06IGNyZWF0ZVN0eWxlZE9wdHMpOiBTdHlsZWRGbiB7XG4gIGZ1bmN0aW9uIHN0eWxlZChiYXNlOiBhbnksIHN0eWxlQXJnKSB7XG4gICAgaWYgKF9fREVWX18pIHtcbiAgICAgIGlmIChiYXNlLl9fU1RZTEVUUk9OX18pIHtcbiAgICAgICAgLyogZXNsaW50LWRpc2FibGUgbm8tY29uc29sZSAqL1xuICAgICAgICBjb25zb2xlLndhcm4oXG4gICAgICAgICAgXCJJdCBhcHBlYXJzIHlvdSBhcmUgcGFzc2luZyBhIHN0eWxlZCBjb21wb25lbnQgaW50byBgc3R5bGVkYC5cIixcbiAgICAgICAgKTtcbiAgICAgICAgY29uc29sZS53YXJuKFxuICAgICAgICAgIFwiRm9yIGNvbXBvc2l0aW9uIHdpdGggZXhpc3Rpbmcgc3R5bGVkIGNvbXBvbmVudHMsIHVzZSBgd2l0aFN0eWxlYCBvciBgd2l0aFRyYW5zZm9ybWAgaW5zdGVhZC5cIixcbiAgICAgICAgKTtcbiAgICAgICAgLyogZXNsaW50LWVuYWJsZSBuby1jb25zb2xlICovXG4gICAgICB9XG4gICAgfVxuXG4gICAgY29uc3QgYmFzZVN0eWxldHJvbjogU3R5bGV0cm9uID0ge1xuICAgICAgcmVkdWNlcnM6IFtdLFxuICAgICAgYmFzZTogYmFzZSxcbiAgICAgIGRyaXZlcixcbiAgICAgIGdldEluaXRpYWxTdHlsZSxcbiAgICAgIHdyYXBwZXIsXG4gICAgfTtcblxuICAgIGlmIChfX0JST1dTRVJfXyAmJiBfX0RFVl9fKSB7XG4gICAgICBhZGREZWJ1Z01ldGFkYXRhKGJhc2VTdHlsZXRyb24sIDIpO1xuICAgIH1cblxuICAgIHJldHVybiBjcmVhdGVTdHlsZWRFbGVtZW50Q29tcG9uZW50KFxuICAgICAgYXV0b0NvbXBvc2VTaGFsbG93KGJhc2VTdHlsZXRyb24sIHN0eWxlQXJnKSxcbiAgICApO1xuICB9XG5cbiAgcmV0dXJuIHN0eWxlZDtcbn1cblxuZXhwb3J0IGNvbnN0IHN0eWxlZDogU3R5bGVkRm4gPSBjcmVhdGVTdHlsZWQoe1xuICBnZXRJbml0aWFsU3R5bGUsXG4gIGRyaXZlcixcbiAgd3JhcHBlcjogQ29tcG9uZW50ID0+IENvbXBvbmVudCxcbn0pO1xuXG5leHBvcnQgY29uc3Qgd2l0aFRyYW5zZm9ybTogV2l0aFRyYW5zZm9ybUZuID0gKGNvbXBvbmVudCwgdHJhbnNmb3JtZXIpID0+IHtcbiAgY29uc3Qgc3R5bGV0cm9uID0gY29tcG9uZW50Ll9fU1RZTEVUUk9OX187XG5cbiAgaWYgKF9fQlJPV1NFUl9fICYmIF9fREVWX18pIHtcbiAgICBhZGREZWJ1Z01ldGFkYXRhKHN0eWxldHJvbiwgMik7XG4gIH1cblxuICByZXR1cm4gY3JlYXRlU3R5bGVkRWxlbWVudENvbXBvbmVudChjb21wb3NlRHluYW1pYyhzdHlsZXRyb24sIHRyYW5zZm9ybWVyKSk7XG59O1xuXG5leHBvcnQgY29uc3Qgd2l0aFN0eWxlRGVlcDogV2l0aFN0eWxlRm4gPSAoY29tcG9uZW50LCBzdHlsZUFyZykgPT4ge1xuICAvLyBAdHMtaWdub3JlXG4gIGNvbnN0IHN0eWxldHJvbiA9IGNvbXBvbmVudC5fX1NUWUxFVFJPTl9fO1xuXG4gIGlmIChfX0RFVl9fKSB7XG4gICAgaWYgKCFzdHlsZXRyb24pIHtcbiAgICAgIC8qIGVzbGludC1kaXNhYmxlIG5vLWNvbnNvbGUgKi9cbiAgICAgIGNvbnNvbGUud2FybihcbiAgICAgICAgXCJUaGUgZmlyc3QgcGFyYW1ldGVyIHRvIGB3aXRoU3R5bGVgIG11c3QgYmUgYSBzdHlsZWQgY29tcG9uZW50ICh3aXRob3V0IGV4dHJhIHdyYXBwZXJzKS5cIixcbiAgICAgICk7XG4gICAgICAvKiBlc2xpbnQtZW5hYmxlIG5vLWNvbnNvbGUgKi9cbiAgICB9XG4gIH1cblxuICBpZiAoX19CUk9XU0VSX18gJiYgX19ERVZfXykge1xuICAgIGFkZERlYnVnTWV0YWRhdGEoc3R5bGV0cm9uLCAyKTtcbiAgICByZXR1cm4gY3JlYXRlU3R5bGVkRWxlbWVudENvbXBvbmVudChcbiAgICAgIGFkZEV4dGVuc2lvbihhdXRvQ29tcG9zZURlZXAoc3R5bGV0cm9uLCBzdHlsZUFyZyksIGNvbXBvbmVudCwgc3R5bGVBcmcpLFxuICAgICk7XG4gIH0gZWxzZSB7XG4gICAgcmV0dXJuIGNyZWF0ZVN0eWxlZEVsZW1lbnRDb21wb25lbnQoYXV0b0NvbXBvc2VEZWVwKHN0eWxldHJvbiwgc3R5bGVBcmcpKTtcbiAgfVxufTtcblxuZXhwb3J0IGNvbnN0IHdpdGhTdHlsZSA9IHdpdGhTdHlsZURlZXA7XG5cbmV4cG9ydCBjb25zdCB3aXRoV3JhcHBlcjogV2l0aFdyYXBwZXJGbiA9IChjb21wb25lbnQsIHdyYXBwZXIpID0+IHtcbiAgY29uc3Qgc3R5bGV0cm9uID0gY29tcG9uZW50Ll9fU1RZTEVUUk9OX187XG5cbiAgaWYgKF9fREVWX18pIHtcbiAgICBpZiAoIXN0eWxldHJvbikge1xuICAgICAgLyogZXNsaW50LWRpc2FibGUgbm8tY29uc29sZSAqL1xuICAgICAgY29uc29sZS53YXJuKFxuICAgICAgICBcIlRoZSBmaXJzdCBwYXJhbWV0ZXIgdG8gYHdpdGhXcmFwcGVyYCBtdXN0IGJlIGEgc3R5bGVkIGNvbXBvbmVudCAod2l0aG91dCBleHRyYSB3cmFwcGVycykuXCIsXG4gICAgICApO1xuICAgICAgLyogZXNsaW50LWVuYWJsZSBuby1jb25zb2xlICovXG4gICAgfVxuICB9XG5cbiAgY29uc3QgY29tcG9zZWQgPSB7XG4gICAgZ2V0SW5pdGlhbFN0eWxlOiBzdHlsZXRyb24uZ2V0SW5pdGlhbFN0eWxlLFxuICAgIGJhc2U6IHN0eWxldHJvbi5iYXNlLFxuICAgIGRyaXZlcjogc3R5bGV0cm9uLmRyaXZlcixcbiAgICB3cmFwcGVyOiB3cmFwcGVyLFxuICAgIHJlZHVjZXJzOiBzdHlsZXRyb24ucmVkdWNlcnMsXG4gIH07XG5cbiAgaWYgKF9fQlJPV1NFUl9fICYmIF9fREVWX18pIHtcbiAgICBhZGREZWJ1Z01ldGFkYXRhKGNvbXBvc2VkLCAyKTtcbiAgfVxuXG4gIHJldHVybiBjcmVhdGVTdHlsZWRFbGVtZW50Q29tcG9uZW50KGNvbXBvc2VkKTtcbn07XG5cbmV4cG9ydCBmdW5jdGlvbiBhdXRvQ29tcG9zZVNoYWxsb3c8UHJvcHM+KFxuICBzdHlsZXRyb246IFN0eWxldHJvbixcbiAgc3R5bGVBcmc6IFN0eWxlT2JqZWN0IHwgKChhOiBQcm9wcykgPT4gU3R5bGVPYmplY3QpLFxuKSB7XG4gIGlmICh0eXBlb2Ygc3R5bGVBcmcgPT09IFwiZnVuY3Rpb25cIikge1xuICAgIHJldHVybiBkeW5hbWljQ29tcG9zZVNoYWxsb3coc3R5bGV0cm9uLCBzdHlsZUFyZyk7XG4gIH1cblxuICByZXR1cm4gc3RhdGljQ29tcG9zZVNoYWxsb3coc3R5bGV0cm9uLCBzdHlsZUFyZyk7XG59XG5cbmZ1bmN0aW9uIGFkZEV4dGVuc2lvbihjb21wb3NlZCwgY29tcG9uZW50LCBzdHlsZUFyZykge1xuICByZXR1cm4ge1xuICAgIC4uLmNvbXBvc2VkLFxuICAgIGV4dDoge1xuICAgICAgd2l0aDogc3R5bGVBcmcsXG4gICAgICBuYW1lOiBjb21wb25lbnQuZGlzcGxheU5hbWUsXG4gICAgICBiYXNlOiBjb21wb25lbnQuX19TVFlMRVRST05fXy5iYXNlLFxuICAgICAgZ2V0SW5pdGlhbFN0eWxlOiBjb21wb25lbnQuX19TVFlMRVRST05fXy5yZWR1Y2Vycy5sZW5ndGhcbiAgICAgICAgPyBjb21wb25lbnQuX19TVFlMRVRST05fXy5yZWR1Y2Vyc1swXS5yZWR1Y2VyXG4gICAgICAgIDogY29tcG9uZW50Ll9fU1RZTEVUUk9OX18uZ2V0SW5pdGlhbFN0eWxlLFxuICAgIH0sXG4gIH07XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBhdXRvQ29tcG9zZURlZXA8UHJvcHM+KFxuICBzdHlsZXRyb246IFN0eWxldHJvbixcbiAgc3R5bGVBcmc6IFN0eWxlT2JqZWN0IHwgKChhOiBQcm9wcykgPT4gU3R5bGVPYmplY3QpLFxuKSB7XG4gIGlmICh0eXBlb2Ygc3R5bGVBcmcgPT09IFwiZnVuY3Rpb25cIikge1xuICAgIHJldHVybiBkeW5hbWljQ29tcG9zZURlZXAoc3R5bGV0cm9uLCBzdHlsZUFyZyk7XG4gIH1cblxuICByZXR1cm4gc3RhdGljQ29tcG9zZURlZXAoc3R5bGV0cm9uLCBzdHlsZUFyZyk7XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBzdGF0aWNDb21wb3NlU2hhbGxvdyhzdHlsZXRyb246IFN0eWxldHJvbiwgc3R5bGU6IFN0eWxlT2JqZWN0KSB7XG4gIHJldHVybiBjb21wb3NlU3RhdGljKHN0eWxldHJvbiwgY3JlYXRlU2hhbGxvd01lcmdlUmVkdWNlcihzdHlsZSkpO1xufVxuXG5leHBvcnQgZnVuY3Rpb24gc3RhdGljQ29tcG9zZURlZXAoc3R5bGV0cm9uOiBTdHlsZXRyb24sIHN0eWxlOiBTdHlsZU9iamVjdCkge1xuICByZXR1cm4gY29tcG9zZVN0YXRpYyhzdHlsZXRyb24sIGNyZWF0ZURlZXBNZXJnZVJlZHVjZXIoc3R5bGUpKTtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIGR5bmFtaWNDb21wb3NlU2hhbGxvdzxQcm9wcz4oXG4gIHN0eWxldHJvbjogU3R5bGV0cm9uLFxuICBzdHlsZUZuOiAoYTogUHJvcHMpID0+IFN0eWxlT2JqZWN0LFxuKSB7XG4gIHJldHVybiBjb21wb3NlRHluYW1pYzxQcm9wcz4oc3R5bGV0cm9uLCAoc3R5bGUsIHByb3BzKSA9PlxuICAgIHNoYWxsb3dNZXJnZShzdHlsZSwgc3R5bGVGbihwcm9wcykpLFxuICApO1xufVxuXG5leHBvcnQgZnVuY3Rpb24gZHluYW1pY0NvbXBvc2VEZWVwPFByb3BzPihcbiAgc3R5bGV0cm9uOiBTdHlsZXRyb24sXG4gIHN0eWxlRm46IChhOiBQcm9wcykgPT4gU3R5bGVPYmplY3QsXG4pIHtcbiAgcmV0dXJuIGNvbXBvc2VEeW5hbWljPFByb3BzPihzdHlsZXRyb24sIChzdHlsZSwgcHJvcHMpID0+XG4gICAgZGVlcE1lcmdlKHN0eWxlLCBzdHlsZUZuKHByb3BzKSksXG4gICk7XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBjcmVhdGVTaGFsbG93TWVyZ2VSZWR1Y2VyKFxuICBzdHlsZTogU3R5bGVPYmplY3QsXG4pOiBBc3NpZ25tZW50Q29tbXV0YXRpdmVSZWR1Y2VyQ29udGFpbmVyIHtcbiAgcmV0dXJuIHtcbiAgICByZWR1Y2VyOiBpbnB1dFN0eWxlID0+IHNoYWxsb3dNZXJnZShpbnB1dFN0eWxlLCBzdHlsZSksXG4gICAgYXNzaWdubWVudENvbW11dGF0aXZlOiB0cnVlLFxuICAgIGZhY3Rvcnk6IGNyZWF0ZVNoYWxsb3dNZXJnZVJlZHVjZXIsXG4gICAgc3R5bGU6IHN0eWxlLFxuICB9O1xufVxuXG5leHBvcnQgZnVuY3Rpb24gY3JlYXRlRGVlcE1lcmdlUmVkdWNlcihcbiAgc3R5bGU6IFN0eWxlT2JqZWN0LFxuKTogQXNzaWdubWVudENvbW11dGF0aXZlUmVkdWNlckNvbnRhaW5lciB7XG4gIHJldHVybiB7XG4gICAgcmVkdWNlcjogaW5wdXRTdHlsZSA9PiBkZWVwTWVyZ2UoaW5wdXRTdHlsZSwgc3R5bGUpLFxuICAgIGFzc2lnbm1lbnRDb21tdXRhdGl2ZTogdHJ1ZSxcbiAgICBmYWN0b3J5OiBjcmVhdGVEZWVwTWVyZ2VSZWR1Y2VyLFxuICAgIHN0eWxlOiBzdHlsZSxcbiAgfTtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIGNvbXBvc2VTdGF0aWMoXG4gIHN0eWxldHJvbjogU3R5bGV0cm9uLFxuICByZWR1Y2VyQ29udGFpbmVyOiBBc3NpZ25tZW50Q29tbXV0YXRpdmVSZWR1Y2VyQ29udGFpbmVyLFxuKSB7XG4gIGlmIChzdHlsZXRyb24ucmVkdWNlcnMubGVuZ3RoID09PSAwKSB7XG4gICAgY29uc3Qgc3R5bGUgPSByZWR1Y2VyQ29udGFpbmVyLnJlZHVjZXIoc3R5bGV0cm9uLmdldEluaXRpYWxTdHlsZSgpKTtcbiAgICBjb25zdCByZXN1bHQ6IFN0eWxldHJvbiA9IHtcbiAgICAgIHJlZHVjZXJzOiBzdHlsZXRyb24ucmVkdWNlcnMsXG4gICAgICBiYXNlOiBzdHlsZXRyb24uYmFzZSxcbiAgICAgIGRyaXZlcjogc3R5bGV0cm9uLmRyaXZlcixcbiAgICAgIHdyYXBwZXI6IHN0eWxldHJvbi53cmFwcGVyLFxuICAgICAgZ2V0SW5pdGlhbFN0eWxlOiAoKSA9PiBzdHlsZSxcbiAgICB9O1xuICAgIGlmIChfX0JST1dTRVJfXyAmJiBfX0RFVl9fKSB7XG4gICAgICByZXN1bHQuZGVidWcgPSBzdHlsZXRyb24uZGVidWc7XG4gICAgfVxuICAgIHJldHVybiByZXN1bHQ7XG4gIH0gZWxzZSB7XG4gICAgY29uc3QgbGFzdCA9IHN0eWxldHJvbi5yZWR1Y2Vyc1swXTtcblxuICAgIGlmIChcbiAgICAgIGxhc3QuYXNzaWdubWVudENvbW11dGF0aXZlID09PSB0cnVlICYmXG4gICAgICByZWR1Y2VyQ29udGFpbmVyLmFzc2lnbm1lbnRDb21tdXRhdGl2ZSA9PT0gdHJ1ZVxuICAgICkge1xuICAgICAgY29uc3QgY29tcG9zZWQgPSByZWR1Y2VyQ29udGFpbmVyLnJlZHVjZXIobGFzdC5zdHlsZSk7XG5cbiAgICAgIGNvbnN0IHJlc3VsdDogU3R5bGV0cm9uID0ge1xuICAgICAgICBnZXRJbml0aWFsU3R5bGU6IHN0eWxldHJvbi5nZXRJbml0aWFsU3R5bGUsXG4gICAgICAgIGJhc2U6IHN0eWxldHJvbi5iYXNlLFxuICAgICAgICBkcml2ZXI6IHN0eWxldHJvbi5kcml2ZXIsXG4gICAgICAgIHdyYXBwZXI6IHN0eWxldHJvbi53cmFwcGVyLFxuICAgICAgICByZWR1Y2VyczogW2xhc3QuZmFjdG9yeShjb21wb3NlZCldLmNvbmNhdChcbiAgICAgICAgICBzdHlsZXRyb24ucmVkdWNlcnMuc2xpY2UoMSkgYXMgYW55LFxuICAgICAgICApLFxuICAgICAgfTtcblxuICAgICAgaWYgKF9fQlJPV1NFUl9fICYmIF9fREVWX18pIHtcbiAgICAgICAgcmVzdWx0LmRlYnVnID0gc3R5bGV0cm9uLmRlYnVnO1xuICAgICAgfVxuXG4gICAgICByZXR1cm4gcmVzdWx0O1xuICAgIH1cblxuICAgIHJldHVybiBjb21wb3NlRHluYW1pYyhzdHlsZXRyb24sIHJlZHVjZXJDb250YWluZXIucmVkdWNlcik7XG4gIH1cbn1cblxuZXhwb3J0IGZ1bmN0aW9uIGNvbXBvc2VEeW5hbWljPFByb3BzPihcbiAgc3R5bGV0cm9uOiBTdHlsZXRyb24sXG4gIHJlZHVjZXI6IChiOiBTdHlsZU9iamVjdCwgYTogUHJvcHMpID0+IFN0eWxlT2JqZWN0LFxuKSB7XG4gIGNvbnN0IGNvbXBvc2VkOiBTdHlsZXRyb24gPSB7XG4gICAgZ2V0SW5pdGlhbFN0eWxlOiBzdHlsZXRyb24uZ2V0SW5pdGlhbFN0eWxlLFxuICAgIGJhc2U6IHN0eWxldHJvbi5iYXNlLFxuICAgIGRyaXZlcjogc3R5bGV0cm9uLmRyaXZlcixcbiAgICB3cmFwcGVyOiBzdHlsZXRyb24ud3JhcHBlcixcbiAgICAvLyBAdHMtaWdub3JlXG4gICAgcmVkdWNlcnM6IFt7YXNzaWdubWVudENvbW11dGF0aXZlOiBmYWxzZSwgcmVkdWNlcn1dLmNvbmNhdChcbiAgICAgIHN0eWxldHJvbi5yZWR1Y2VycyxcbiAgICApLFxuICB9O1xuICBpZiAoX19CUk9XU0VSX18gJiYgX19ERVZfXykge1xuICAgIGNvbXBvc2VkLmRlYnVnID0gc3R5bGV0cm9uLmRlYnVnO1xuICB9XG4gIHJldHVybiBjb21wb3NlZDtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIGNyZWF0ZVN0eWxlZEVsZW1lbnRDb21wb25lbnQoc3R5bGV0cm9uOiBTdHlsZXRyb24pIHtcbiAgY29uc3Qge3JlZHVjZXJzLCBiYXNlLCBkcml2ZXIsIHdyYXBwZXIsIGdldEluaXRpYWxTdHlsZSwgZXh0fSA9IHN0eWxldHJvbjtcblxuICBpZiAoX19CUk9XU0VSX18gJiYgX19ERVZfXykge1xuICAgIHZhciBkZWJ1Z1N0YWNrSW5mbywgZGVidWdTdGFja0luZGV4O1xuICAgIGlmIChzdHlsZXRyb24uZGVidWcpIHtcbiAgICAgIGRlYnVnU3RhY2tJbmZvID0gc3R5bGV0cm9uLmRlYnVnLnN0YWNrSW5mbztcbiAgICAgIGRlYnVnU3RhY2tJbmRleCA9IHN0eWxldHJvbi5kZWJ1Zy5zdGFja0luZGV4O1xuICAgIH1cbiAgfVxuXG4gIGlmIChfX0JST1dTRVJfXyAmJiBfX0RFVl9fKSB7XG4gICAgdmFyIGRlYnVnQ2xhc3NOYW1lO1xuICB9XG5cbiAgY29uc3QgU3R5bGVkRWxlbWVudCA9IFJlYWN0LmZvcndhcmRSZWY8U3R5bGV0cm9uUHJvcHMsIGFueT4oKHByb3BzLCByZWYpID0+IHtcbiAgICBjb25zdCBzdHlsZXRyb246IFN0YW5kYXJkRW5naW5lID0gUmVhY3QudXNlQ29udGV4dChTdHlsZXRyb25Db250ZXh0KTtcbiAgICBjb25zdCBkZWJ1Z0VuZ2luZSA9IFJlYWN0LnVzZUNvbnRleHQoRGVidWdFbmdpbmVDb250ZXh0KTtcbiAgICBjb25zdCBoeWRyYXRpbmcgPSBSZWFjdC51c2VDb250ZXh0KEh5ZHJhdGlvbkNvbnRleHQpO1xuICAgIGNoZWNrTm9vcEVuZ2luZShzdHlsZXRyb24pO1xuXG4gICAgY29uc3QgZWxlbWVudFByb3BzOiBhbnkgPSBvbWl0UHJlZml4ZWRLZXlzKHByb3BzKTtcbiAgICBsZXQgc3R5bGUgPSByZXNvbHZlU3R5bGUoZ2V0SW5pdGlhbFN0eWxlLCByZWR1Y2VycywgcHJvcHMpO1xuXG4gICAgaWYgKHByb3BzLiRzdHlsZSkge1xuICAgICAgaWYgKHR5cGVvZiBwcm9wcy4kc3R5bGUgPT09IFwiZnVuY3Rpb25cIikge1xuICAgICAgICBzdHlsZSA9IGRlZXBNZXJnZShzdHlsZSwgcHJvcHMuJHN0eWxlKHByb3BzKSk7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBzdHlsZSA9IGRlZXBNZXJnZShzdHlsZSwgcHJvcHMuJHN0eWxlKTtcbiAgICAgIH1cbiAgICB9XG5cbiAgICBjb25zdCBzdHlsZUNsYXNzU3RyaW5nID0gZHJpdmVyKHN0eWxlLCBzdHlsZXRyb24pO1xuICAgIGNvbnN0IEVsZW1lbnQgPSBwcm9wcy4kYXMgPyBwcm9wcy4kYXMgOiBiYXNlO1xuICAgIGVsZW1lbnRQcm9wcy5jbGFzc05hbWUgPSBwcm9wcy5jbGFzc05hbWVcbiAgICAgID8gYCR7cHJvcHMuY2xhc3NOYW1lfSAke3N0eWxlQ2xhc3NTdHJpbmd9YFxuICAgICAgOiBzdHlsZUNsYXNzU3RyaW5nO1xuXG4gICAgaWYgKF9fQlJPV1NFUl9fICYmIF9fREVWX18gJiYgZGVidWdFbmdpbmUgJiYgIWh5ZHJhdGluZykge1xuICAgICAgaWYgKCFkZWJ1Z0NsYXNzTmFtZSkge1xuICAgICAgICBkZWJ1Z0NsYXNzTmFtZSA9IGRlYnVnRW5naW5lLmRlYnVnKHtcbiAgICAgICAgICBzdGFja0luZm86IGRlYnVnU3RhY2tJbmZvLFxuICAgICAgICAgIHN0YWNrSW5kZXg6IGRlYnVnU3RhY2tJbmRleCxcbiAgICAgICAgfSk7XG4gICAgICB9XG5cbiAgICAgIGNvbnN0IGpvaW5lZCA9IGAke2RlYnVnQ2xhc3NOYW1lfSAke2VsZW1lbnRQcm9wcy5jbGFzc05hbWV9YDtcbiAgICAgIGVsZW1lbnRQcm9wcy5jbGFzc05hbWUgPSBqb2luZWQ7XG4gICAgfVxuXG4gICAgaWYgKF9fQlJPV1NFUl9fICYmIF9fREVWX18gJiYgd2luZG93Ll9fU1RZTEVUUk9OX0RFVlRPT0xTX18pIHtcbiAgICAgIHdpbmRvdy5fX1NUWUxFVFJPTl9ERVZUT09MU19fLnN0eWxlc01hcC5zZXQoXG4gICAgICAgIGVsZW1lbnRQcm9wcy5jbGFzc05hbWUsXG4gICAgICAgIHN0eWxlLFxuICAgICAgKTtcbiAgICAgIGlmIChleHQpIHtcbiAgICAgICAgd2luZG93Ll9fU1RZTEVUUk9OX0RFVlRPT0xTX18uZXh0ZW5zaW9uc01hcC5zZXQoXG4gICAgICAgICAgZWxlbWVudFByb3BzLmNsYXNzTmFtZSxcbiAgICAgICAgICB7XG4gICAgICAgICAgICBiYXNlOiBleHQuYmFzZSxcbiAgICAgICAgICAgIGRpc3BsYXlOYW1lOiBleHQubmFtZSxcbiAgICAgICAgICAgIGluaXRpYWxTdHlsZXM6IGV4dC5nZXRJbml0aWFsU3R5bGUoe30sIHByb3BzKSxcbiAgICAgICAgICAgIHN0eWxlT3ZlcnJpZGVzOlxuICAgICAgICAgICAgICB0eXBlb2YgZXh0LndpdGggPT09IFwiZnVuY3Rpb25cIiA/IGV4dC53aXRoKHByb3BzKSA6IGV4dC53aXRoLFxuICAgICAgICAgIH0sXG4gICAgICAgICk7XG4gICAgICB9XG4gICAgfVxuXG4gICAgaWYgKHByb3BzLiRyZWYpIHtcbiAgICAgIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBuby1jb25zb2xlXG4gICAgICBjb25zb2xlLndhcm4oXG4gICAgICAgIFwiVGhlIHByb3AgYCRyZWZgIGhhcyBiZWVuIGRlcHJlY2F0ZWQuIFVzZSBgcmVmYCBpbnN0ZWFkLiBSZWZzIGFyZSBub3cgZm9yd2FyZGVkIHdpdGggUmVhY3QuZm9yd2FyZFJlZi5cIixcbiAgICAgICk7XG4gICAgfVxuICAgIHJldHVybiA8RWxlbWVudCB7Li4uZWxlbWVudFByb3BzfSByZWY9e3JlZiB8fCBwcm9wcy4kcmVmfSAvPjtcbiAgfSk7XG5cbiAgY29uc3QgV3JhcHBlZCA9IHdyYXBwZXIoU3R5bGVkRWxlbWVudCk7XG4gIFdyYXBwZWQuX19TVFlMRVRST05fXyA9IHtcbiAgICBiYXNlLFxuICAgIHJlZHVjZXJzLFxuICAgIGRyaXZlcixcbiAgICB3cmFwcGVyLFxuICAgIGdldEluaXRpYWxTdHlsZSxcbiAgfTtcblxuICBpZiAoX19ERVZfXykge1xuICAgIGxldCBkaXNwbGF5TmFtZTtcblxuICAgIGlmICh0eXBlb2YgYmFzZSA9PT0gXCJzdHJpbmdcIikge1xuICAgICAgZGlzcGxheU5hbWUgPSBiYXNlO1xuICAgIH0gZWxzZSBpZiAoYmFzZS5kaXNwbGF5TmFtZSkge1xuICAgICAgZGlzcGxheU5hbWUgPSBiYXNlLmRpc3BsYXlOYW1lO1xuICAgIH0gZWxzZSBpZiAoYmFzZS5uYW1lKSB7XG4gICAgICBkaXNwbGF5TmFtZSA9IGJhc2UubmFtZTtcbiAgICB9IGVsc2Uge1xuICAgICAgZGlzcGxheU5hbWUgPSBcIlVua25vd25cIjtcbiAgICB9XG5cbiAgICBXcmFwcGVkLmRpc3BsYXlOYW1lID0gYFN0eWxlZCgke2Rpc3BsYXlOYW1lfSlgO1xuICB9XG5cbiAgcmV0dXJuIFdyYXBwZWQ7XG59XG5cbi8vIFV0aWxpdHkgZnVuY3Rpb25zXG5cbmV4cG9ydCBmdW5jdGlvbiByZXNvbHZlU3R5bGUoXG4gIGdldEluaXRpYWxTdHlsZTogKGE6IHZvaWQpID0+IFN0eWxlT2JqZWN0LFxuICByZWR1Y2VyczogQXJyYXk8UmVkdWNlckNvbnRhaW5lcj4sXG4gIHByb3BzOiBhbnksXG4pOiBTdHlsZU9iamVjdCB7XG4gIGxldCByZXN1bHQgPSBnZXRJbml0aWFsU3R5bGUoKTtcbiAgbGV0IGkgPSByZWR1Y2Vycy5sZW5ndGg7XG4gIHdoaWxlIChpLS0pIHtcbiAgICAvLyBDYXN0IHRvIGFsbG93IHBhc3NpbmcgdW51c2VkIHByb3BzIHBhcmFtIGluIGNhc2Ugb2Ygc3RhdGljIHJlZHVjZXJcbiAgICBjb25zdCByZWR1Y2VyID0gcmVkdWNlcnNbaV0ucmVkdWNlciBhcyAoXG4gICAgICBiOiBTdHlsZU9iamVjdCxcbiAgICAgIGE6IGFueSxcbiAgICApID0+IFN0eWxlT2JqZWN0O1xuICAgIHJlc3VsdCA9IHJlZHVjZXIocmVzdWx0LCBwcm9wcyk7XG4gIH1cbiAgcmV0dXJuIHJlc3VsdDtcbn1cblxuZnVuY3Rpb24gaXNPYmplY3QoeDogYW55KSB7XG4gIHJldHVybiB0eXBlb2YgeCA9PT0gXCJvYmplY3RcIiAmJiB4ICE9PSBudWxsO1xufVxuXG5mdW5jdGlvbiBvbWl0UHJlZml4ZWRLZXlzKHNvdXJjZSkge1xuICBjb25zdCByZXN1bHQgPSB7fTtcblxuICBmb3IgKGNvbnN0IGtleSBpbiBzb3VyY2UpIHtcbiAgICBpZiAoa2V5WzBdICE9PSBcIiRcIikge1xuICAgICAgcmVzdWx0W2tleV0gPSBzb3VyY2Vba2V5XTtcbiAgICB9XG4gIH1cblxuICByZXR1cm4gcmVzdWx0O1xufVxuXG5mdW5jdGlvbiBkZWVwTWVyZ2UoYSwgYikge1xuICBjb25zdCByZXN1bHQgPSBhc3NpZ24oe30sIGEpO1xuXG4gIGZvciAoY29uc3Qga2V5IGluIGIpIHtcbiAgICBjb25zdCB2YWwgPSBiW2tleV07XG5cbiAgICBpZiAoaXNPYmplY3QodmFsKSAmJiBpc09iamVjdChhW2tleV0pKSB7XG4gICAgICByZXN1bHRba2V5XSA9IGRlZXBNZXJnZShhW2tleV0sIHZhbCk7XG4gICAgfSBlbHNlIHtcbiAgICAgIHJlc3VsdFtrZXldID0gdmFsO1xuICAgIH1cbiAgfVxuXG4gIHJldHVybiByZXN1bHQ7XG59XG5cbmZ1bmN0aW9uIHNoYWxsb3dNZXJnZShhLCBiKSB7XG4gIHJldHVybiBhc3NpZ24oYXNzaWduKHt9LCBhKSwgYik7XG59XG5cbmZ1bmN0aW9uIGFzc2lnbih0YXJnZXQsIHNvdXJjZSkge1xuICBmb3IgKGNvbnN0IGtleSBpbiBzb3VyY2UpIHtcbiAgICB0YXJnZXRba2V5XSA9IHNvdXJjZVtrZXldO1xuICB9XG4gIHJldHVybiB0YXJnZXQ7XG59XG4iXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBY0E7O0FBQ0E7O0FBbUJBOzs7Ozs7OztBQVdBLE1BQU1BLFVBQVUsR0FBRztFQUNqQkMsV0FBVyxFQUFFLE1BQU0sRUFERjtFQUVqQkMsZUFBZSxFQUFFLE1BQU0sRUFGTjtFQUdqQkMsY0FBYyxFQUFFLE1BQU07QUFITCxDQUFuQjtBQU1BLE1BQU1DLGdCQUFnQixnQkFBR0MsS0FBSyxDQUFDQyxhQUFOLENBQW9DTixVQUFwQyxDQUF6QjtBQUNBLE1BQU1PLGdCQUFnQixnQkFBR0YsS0FBSyxDQUFDQyxhQUFOLENBQW9CLEtBQXBCLENBQXpCO0FBQ0EsTUFBTUUsa0JBQWtCLGdCQUFHSCxLQUFLLENBQUNDLGFBQU4sQ0FFekJHLFNBRnlCLENBQTNCLEMsQ0FHQTs7QUFTQSxNQUFNQyxXQUFOLFNBQTBCTCxLQUFLLENBQUNNLFNBQWhDLENBS0U7RUFDQUMsV0FBVyxDQUFDQyxLQUFELEVBQTBCO0lBQ25DLE1BQU1BLEtBQU47SUFDQSxLQUFLQyxLQUFMLEdBQWE7TUFDWEMsU0FBUyxFQUFFQyxPQUFPLENBQUNILEtBQUssQ0FBQ0ksbUJBQVA7SUFEUCxDQUFiO0VBR0Q7O0VBRURDLGlCQUFpQixHQUFHO0lBQ2xCLFVBQWlCO01BQ2YsSUFBSSxLQUFLSixLQUFMLENBQVdDLFNBQVgsS0FBeUIsSUFBN0IsRUFBbUM7UUFDakMsS0FBS0ksUUFBTCxDQUFjO1VBQ1pKLFNBQVMsRUFBRTtRQURDLENBQWQ7TUFHRDtJQUNGO0VBQ0Y7O0VBRURLLE1BQU0sR0FBRztJQUNQLG9CQUNFLG9CQUFDLGdCQUFELENBQWtCLFFBQWxCO01BQTJCLEtBQUssRUFBRSxLQUFLUCxLQUFMLENBQVdRO0lBQTdDLGdCQUNFLG9CQUFDLGtCQUFELENBQW9CLFFBQXBCO01BQTZCLEtBQUssRUFBRSxLQUFLUixLQUFMLENBQVdTO0lBQS9DLGdCQUNFLG9CQUFDLGdCQUFELENBQWtCLFFBQWxCO01BQTJCLEtBQUssRUFBRSxLQUFLUixLQUFMLENBQVdDO0lBQTdDLEdBQ0csS0FBS0YsS0FBTCxDQUFXVSxRQURkLENBREYsQ0FERixDQURGO0VBU0Q7O0FBNUJEOztBQStCSyxNQUFNQyxRQUFRLEdBQ25CLGdEQUF5QmQsV0FBekIsR0FBdUNOLGdCQUFnQixDQUFDb0IsUUFEbkQ7OztBQUdQLElBQUksaURBQTBCLENBQUNDLE1BQU0sQ0FBQ0Msc0JBQXRDLEVBQThEO0VBQzVELElBQUFDLCtCQUFBO0FBQ0Q7O0FBUUQsU0FBU0MsZUFBVCxDQUF5QkMsTUFBekIsRUFBaUQ7RUFDL0M7RUFDQTtFQUNBLElBQUlDLE9BQU8sQ0FBQ0MsR0FBUixDQUFZQyxRQUFaLEtBQXlCLE1BQTdCLEVBQXFDO0lBQ25DSCxNQUFNLEtBQUs3QixVQUFYLElBQ0U7SUFDQWlDLE9BQU8sQ0FBQ0MsSUFBUixDQUNFLHdDQUNLO0FBQ2I7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxDQVpRLEdBYUssd0RBZFAsQ0FGRjtFQWtCRDtBQUNGOztBQUVNLFNBQVNDLFlBQVQsR0FBMEQ7RUFDL0QsTUFBTUMsZUFBK0IsR0FBRy9CLEtBQUssQ0FBQ2dDLFVBQU4sQ0FBaUJqQyxnQkFBakIsQ0FBeEM7RUFDQSxNQUFNa0MsV0FBVyxHQUFHakMsS0FBSyxDQUFDZ0MsVUFBTixDQUFpQjdCLGtCQUFqQixDQUFwQjtFQUNBLE1BQU1PLFNBQVMsR0FBR1YsS0FBSyxDQUFDZ0MsVUFBTixDQUFpQjlCLGdCQUFqQixDQUFsQjtFQUNBcUIsZUFBZSxDQUFDUSxlQUFELENBQWY7RUFFQSxNQUFNRyxjQUFjLEdBQUdsQyxLQUFLLENBQUNtQyxNQUFOLENBQWlDLEVBQWpDLENBQXZCO0VBQ0EsTUFBTUMsc0JBQXNCLEdBQUdwQyxLQUFLLENBQUNtQyxNQUFOLENBQWEsRUFBYixDQUEvQjtFQUVBLE9BQU8sQ0FDTCxTQUFTRSxHQUFULENBQWFDLEtBQWIsRUFBaUM7SUFDL0IsTUFBTUMsU0FBUyxHQUFHLElBQUFDLHlCQUFBLEVBQU9GLEtBQVAsRUFBY1AsZUFBZCxDQUFsQjs7SUFDQSxJQUFJLEVBQUUsNkNBQUYsQ0FBSixFQUErQjtNQUM3QixPQUFPUSxTQUFQO0lBQ0Q7O0lBQ0QsTUFBTTtNQUFDRSxLQUFEO01BQVFDO0lBQVIsSUFBbUIsSUFBSUMsS0FBSixDQUFVLG1CQUFWLENBQXpCO0lBRUEsTUFBTUMsUUFBUSxHQUFHLENBQUNYLFdBQUQsRUFBY3ZCLFNBQWQsQ0FBakI7O0lBQ0EsSUFDRTBCLHNCQUFzQixDQUFDUyxPQUF2QixDQUErQixDQUEvQixNQUFzQ0QsUUFBUSxDQUFDLENBQUQsQ0FBOUMsSUFDQVIsc0JBQXNCLENBQUNTLE9BQXZCLENBQStCLENBQS9CLE1BQXNDRCxRQUFRLENBQUMsQ0FBRCxDQUZoRCxFQUdFO01BQ0EsSUFBSVgsV0FBVyxJQUFJLENBQUN2QixTQUFwQixFQUErQjtRQUM3QndCLGNBQWMsQ0FBQ1csT0FBZixHQUF5QlosV0FBVyxDQUFDaEIsS0FBWixDQUFrQjtVQUN6QzZCLFNBQVMsRUFBRTtZQUFDTCxLQUFEO1lBQVFDO1VBQVIsQ0FEOEI7VUFFekNLLFVBQVUsRUFBRTtRQUY2QixDQUFsQixDQUF6QjtNQUlEOztNQUNEWCxzQkFBc0IsQ0FBQ1MsT0FBdkIsR0FBaUNELFFBQWpDO0lBQ0Q7O0lBRUQsSUFBSVYsY0FBYyxDQUFDVyxPQUFuQixFQUE0QjtNQUMxQixPQUFRLEdBQUVYLGNBQWMsQ0FBQ1csT0FBUSxJQUFHTixTQUFVLEVBQTlDO0lBQ0Q7O0lBRUQsT0FBT0EsU0FBUDtFQUNELENBM0JJLENBQVA7QUE2QkQ7O0FBRU0sU0FBU1MsWUFBVCxDQUFzQjtFQUMzQkMsZUFEMkI7RUFFM0JULE1BRjJCO0VBRzNCVTtBQUgyQixDQUF0QixFQUl3QjtFQUM3QixTQUFTQyxNQUFULENBQWdCQyxJQUFoQixFQUEyQkMsUUFBM0IsRUFBcUM7SUFDbkMsMkNBQWE7TUFDWCxJQUFJRCxJQUFJLENBQUNFLGFBQVQsRUFBd0I7UUFDdEI7UUFDQTFCLE9BQU8sQ0FBQ0MsSUFBUixDQUNFLDhEQURGO1FBR0FELE9BQU8sQ0FBQ0MsSUFBUixDQUNFLDhGQURGO1FBR0E7TUFDRDtJQUNGOztJQUVELE1BQU0wQixhQUF3QixHQUFHO01BQy9CQyxRQUFRLEVBQUUsRUFEcUI7TUFFL0JKLElBQUksRUFBRUEsSUFGeUI7TUFHL0JaLE1BSCtCO01BSS9CUyxlQUorQjtNQUsvQkM7SUFMK0IsQ0FBakM7O0lBUUEsSUFBSSw2Q0FBSixFQUE0QjtNQUMxQixJQUFBTyx5QkFBQSxFQUFpQkYsYUFBakIsRUFBZ0MsQ0FBaEM7SUFDRDs7SUFFRCxPQUFPRyw0QkFBNEIsQ0FDakNDLGtCQUFrQixDQUFDSixhQUFELEVBQWdCRixRQUFoQixDQURlLENBQW5DO0VBR0Q7O0VBRUQsT0FBT0YsTUFBUDtBQUNEOztBQUVNLE1BQU1BLE1BQWdCLEdBQUdILFlBQVksQ0FBQztFQUMzQ0MsZUFBZSxFQUFmQSxrQ0FEMkM7RUFFM0NULE1BQU0sRUFBTkEseUJBRjJDO0VBRzNDVSxPQUFPLEVBQUU1QyxTQUFTLElBQUlBO0FBSHFCLENBQUQsQ0FBckM7OztBQU1BLE1BQU1zRCxhQUE4QixHQUFHLENBQUNDLFNBQUQsRUFBWUMsV0FBWixLQUE0QjtFQUN4RSxNQUFNQyxTQUFTLEdBQUdGLFNBQVMsQ0FBQ1AsYUFBNUI7O0VBRUEsSUFBSSw2Q0FBSixFQUE0QjtJQUMxQixJQUFBRyx5QkFBQSxFQUFpQk0sU0FBakIsRUFBNEIsQ0FBNUI7RUFDRDs7RUFFRCxPQUFPTCw0QkFBNEIsQ0FBQ00sY0FBYyxDQUFDRCxTQUFELEVBQVlELFdBQVosQ0FBZixDQUFuQztBQUNELENBUk07Ozs7QUFVQSxNQUFNRyxhQUEwQixHQUFHLENBQUNKLFNBQUQsRUFBWVIsUUFBWixLQUF5QjtFQUNqRTtFQUNBLE1BQU1VLFNBQVMsR0FBR0YsU0FBUyxDQUFDUCxhQUE1Qjs7RUFFQSwyQ0FBYTtJQUNYLElBQUksQ0FBQ1MsU0FBTCxFQUFnQjtNQUNkO01BQ0FuQyxPQUFPLENBQUNDLElBQVIsQ0FDRSx5RkFERjtNQUdBO0lBQ0Q7RUFDRjs7RUFFRCxJQUFJLDZDQUFKLEVBQTRCO0lBQzFCLElBQUE0Qix5QkFBQSxFQUFpQk0sU0FBakIsRUFBNEIsQ0FBNUI7SUFDQSxPQUFPTCw0QkFBNEIsQ0FDakNRLFlBQVksQ0FBQ0MsZUFBZSxDQUFDSixTQUFELEVBQVlWLFFBQVosQ0FBaEIsRUFBdUNRLFNBQXZDLEVBQWtEUixRQUFsRCxDQURxQixDQUFuQztFQUdELENBTEQsTUFLTztJQUNMLE9BQU9LLDRCQUE0QixDQUFDUyxlQUFlLENBQUNKLFNBQUQsRUFBWVYsUUFBWixDQUFoQixDQUFuQztFQUNEO0FBQ0YsQ0F0Qk07OztBQXdCQSxNQUFNZSxTQUFTLEdBQUdILGFBQWxCOzs7QUFFQSxNQUFNSSxXQUEwQixHQUFHLENBQUNSLFNBQUQsRUFBWVgsT0FBWixLQUF3QjtFQUNoRSxNQUFNYSxTQUFTLEdBQUdGLFNBQVMsQ0FBQ1AsYUFBNUI7O0VBRUEsMkNBQWE7SUFDWCxJQUFJLENBQUNTLFNBQUwsRUFBZ0I7TUFDZDtNQUNBbkMsT0FBTyxDQUFDQyxJQUFSLENBQ0UsMkZBREY7TUFHQTtJQUNEO0VBQ0Y7O0VBRUQsTUFBTXlDLFFBQVEsR0FBRztJQUNmckIsZUFBZSxFQUFFYyxTQUFTLENBQUNkLGVBRFo7SUFFZkcsSUFBSSxFQUFFVyxTQUFTLENBQUNYLElBRkQ7SUFHZlosTUFBTSxFQUFFdUIsU0FBUyxDQUFDdkIsTUFISDtJQUlmVSxPQUFPLEVBQUVBLE9BSk07SUFLZk0sUUFBUSxFQUFFTyxTQUFTLENBQUNQO0VBTEwsQ0FBakI7O0VBUUEsSUFBSSw2Q0FBSixFQUE0QjtJQUMxQixJQUFBQyx5QkFBQSxFQUFpQmEsUUFBakIsRUFBMkIsQ0FBM0I7RUFDRDs7RUFFRCxPQUFPWiw0QkFBNEIsQ0FBQ1ksUUFBRCxDQUFuQztBQUNELENBMUJNOzs7O0FBNEJBLFNBQVNYLGtCQUFULENBQ0xJLFNBREssRUFFTFYsUUFGSyxFQUdMO0VBQ0EsSUFBSSxPQUFPQSxRQUFQLEtBQW9CLFVBQXhCLEVBQW9DO0lBQ2xDLE9BQU9rQixxQkFBcUIsQ0FBQ1IsU0FBRCxFQUFZVixRQUFaLENBQTVCO0VBQ0Q7O0VBRUQsT0FBT21CLG9CQUFvQixDQUFDVCxTQUFELEVBQVlWLFFBQVosQ0FBM0I7QUFDRDs7QUFFRCxTQUFTYSxZQUFULENBQXNCSSxRQUF0QixFQUFnQ1QsU0FBaEMsRUFBMkNSLFFBQTNDLEVBQXFEO0VBQ25ELE9BQU8sRUFDTCxHQUFHaUIsUUFERTtJQUVMRyxHQUFHLEVBQUU7TUFDSEMsSUFBSSxFQUFFckIsUUFESDtNQUVIc0IsSUFBSSxFQUFFZCxTQUFTLENBQUNlLFdBRmI7TUFHSHhCLElBQUksRUFBRVMsU0FBUyxDQUFDUCxhQUFWLENBQXdCRixJQUgzQjtNQUlISCxlQUFlLEVBQUVZLFNBQVMsQ0FBQ1AsYUFBVixDQUF3QkUsUUFBeEIsQ0FBaUNxQixNQUFqQyxHQUNiaEIsU0FBUyxDQUFDUCxhQUFWLENBQXdCRSxRQUF4QixDQUFpQyxDQUFqQyxFQUFvQ3NCLE9BRHZCLEdBRWJqQixTQUFTLENBQUNQLGFBQVYsQ0FBd0JMO0lBTnpCO0VBRkEsQ0FBUDtBQVdEOztBQUVNLFNBQVNrQixlQUFULENBQ0xKLFNBREssRUFFTFYsUUFGSyxFQUdMO0VBQ0EsSUFBSSxPQUFPQSxRQUFQLEtBQW9CLFVBQXhCLEVBQW9DO0lBQ2xDLE9BQU8wQixrQkFBa0IsQ0FBQ2hCLFNBQUQsRUFBWVYsUUFBWixDQUF6QjtFQUNEOztFQUVELE9BQU8yQixpQkFBaUIsQ0FBQ2pCLFNBQUQsRUFBWVYsUUFBWixDQUF4QjtBQUNEOztBQUVNLFNBQVNtQixvQkFBVCxDQUE4QlQsU0FBOUIsRUFBb0R6QixLQUFwRCxFQUF3RTtFQUM3RSxPQUFPMkMsYUFBYSxDQUFDbEIsU0FBRCxFQUFZbUIseUJBQXlCLENBQUM1QyxLQUFELENBQXJDLENBQXBCO0FBQ0Q7O0FBRU0sU0FBUzBDLGlCQUFULENBQTJCakIsU0FBM0IsRUFBaUR6QixLQUFqRCxFQUFxRTtFQUMxRSxPQUFPMkMsYUFBYSxDQUFDbEIsU0FBRCxFQUFZb0Isc0JBQXNCLENBQUM3QyxLQUFELENBQWxDLENBQXBCO0FBQ0Q7O0FBRU0sU0FBU2lDLHFCQUFULENBQ0xSLFNBREssRUFFTHFCLE9BRkssRUFHTDtFQUNBLE9BQU9wQixjQUFjLENBQVFELFNBQVIsRUFBbUIsQ0FBQ3pCLEtBQUQsRUFBUTlCLEtBQVIsS0FDdEM2RSxZQUFZLENBQUMvQyxLQUFELEVBQVE4QyxPQUFPLENBQUM1RSxLQUFELENBQWYsQ0FETyxDQUFyQjtBQUdEOztBQUVNLFNBQVN1RSxrQkFBVCxDQUNMaEIsU0FESyxFQUVMcUIsT0FGSyxFQUdMO0VBQ0EsT0FBT3BCLGNBQWMsQ0FBUUQsU0FBUixFQUFtQixDQUFDekIsS0FBRCxFQUFROUIsS0FBUixLQUN0QzhFLFNBQVMsQ0FBQ2hELEtBQUQsRUFBUThDLE9BQU8sQ0FBQzVFLEtBQUQsQ0FBZixDQURVLENBQXJCO0FBR0Q7O0FBRU0sU0FBUzBFLHlCQUFULENBQ0w1QyxLQURLLEVBRWtDO0VBQ3ZDLE9BQU87SUFDTHdDLE9BQU8sRUFBRVMsVUFBVSxJQUFJRixZQUFZLENBQUNFLFVBQUQsRUFBYWpELEtBQWIsQ0FEOUI7SUFFTGtELHFCQUFxQixFQUFFLElBRmxCO0lBR0xDLE9BQU8sRUFBRVAseUJBSEo7SUFJTDVDLEtBQUssRUFBRUE7RUFKRixDQUFQO0FBTUQ7O0FBRU0sU0FBUzZDLHNCQUFULENBQ0w3QyxLQURLLEVBRWtDO0VBQ3ZDLE9BQU87SUFDTHdDLE9BQU8sRUFBRVMsVUFBVSxJQUFJRCxTQUFTLENBQUNDLFVBQUQsRUFBYWpELEtBQWIsQ0FEM0I7SUFFTGtELHFCQUFxQixFQUFFLElBRmxCO0lBR0xDLE9BQU8sRUFBRU4sc0JBSEo7SUFJTDdDLEtBQUssRUFBRUE7RUFKRixDQUFQO0FBTUQ7O0FBRU0sU0FBUzJDLGFBQVQsQ0FDTGxCLFNBREssRUFFTDJCLGdCQUZLLEVBR0w7RUFDQSxJQUFJM0IsU0FBUyxDQUFDUCxRQUFWLENBQW1CcUIsTUFBbkIsS0FBOEIsQ0FBbEMsRUFBcUM7SUFDbkMsTUFBTXZDLEtBQUssR0FBR29ELGdCQUFnQixDQUFDWixPQUFqQixDQUF5QmYsU0FBUyxDQUFDZCxlQUFWLEVBQXpCLENBQWQ7SUFDQSxNQUFNMEMsTUFBaUIsR0FBRztNQUN4Qm5DLFFBQVEsRUFBRU8sU0FBUyxDQUFDUCxRQURJO01BRXhCSixJQUFJLEVBQUVXLFNBQVMsQ0FBQ1gsSUFGUTtNQUd4QlosTUFBTSxFQUFFdUIsU0FBUyxDQUFDdkIsTUFITTtNQUl4QlUsT0FBTyxFQUFFYSxTQUFTLENBQUNiLE9BSks7TUFLeEJELGVBQWUsRUFBRSxNQUFNWDtJQUxDLENBQTFCOztJQU9BLElBQUksNkNBQUosRUFBNEI7TUFDMUJxRCxNQUFNLENBQUMxRSxLQUFQLEdBQWU4QyxTQUFTLENBQUM5QyxLQUF6QjtJQUNEOztJQUNELE9BQU8wRSxNQUFQO0VBQ0QsQ0FiRCxNQWFPO0lBQ0wsTUFBTUMsSUFBSSxHQUFHN0IsU0FBUyxDQUFDUCxRQUFWLENBQW1CLENBQW5CLENBQWI7O0lBRUEsSUFDRW9DLElBQUksQ0FBQ0oscUJBQUwsS0FBK0IsSUFBL0IsSUFDQUUsZ0JBQWdCLENBQUNGLHFCQUFqQixLQUEyQyxJQUY3QyxFQUdFO01BQ0EsTUFBTWxCLFFBQVEsR0FBR29CLGdCQUFnQixDQUFDWixPQUFqQixDQUF5QmMsSUFBSSxDQUFDdEQsS0FBOUIsQ0FBakI7TUFFQSxNQUFNcUQsTUFBaUIsR0FBRztRQUN4QjFDLGVBQWUsRUFBRWMsU0FBUyxDQUFDZCxlQURIO1FBRXhCRyxJQUFJLEVBQUVXLFNBQVMsQ0FBQ1gsSUFGUTtRQUd4QlosTUFBTSxFQUFFdUIsU0FBUyxDQUFDdkIsTUFITTtRQUl4QlUsT0FBTyxFQUFFYSxTQUFTLENBQUNiLE9BSks7UUFLeEJNLFFBQVEsRUFBRSxDQUFDb0MsSUFBSSxDQUFDSCxPQUFMLENBQWFuQixRQUFiLENBQUQsRUFBeUJ1QixNQUF6QixDQUNSOUIsU0FBUyxDQUFDUCxRQUFWLENBQW1Cc0MsS0FBbkIsQ0FBeUIsQ0FBekIsQ0FEUTtNQUxjLENBQTFCOztNQVVBLElBQUksNkNBQUosRUFBNEI7UUFDMUJILE1BQU0sQ0FBQzFFLEtBQVAsR0FBZThDLFNBQVMsQ0FBQzlDLEtBQXpCO01BQ0Q7O01BRUQsT0FBTzBFLE1BQVA7SUFDRDs7SUFFRCxPQUFPM0IsY0FBYyxDQUFDRCxTQUFELEVBQVkyQixnQkFBZ0IsQ0FBQ1osT0FBN0IsQ0FBckI7RUFDRDtBQUNGOztBQUVNLFNBQVNkLGNBQVQsQ0FDTEQsU0FESyxFQUVMZSxPQUZLLEVBR0w7RUFDQSxNQUFNUixRQUFtQixHQUFHO0lBQzFCckIsZUFBZSxFQUFFYyxTQUFTLENBQUNkLGVBREQ7SUFFMUJHLElBQUksRUFBRVcsU0FBUyxDQUFDWCxJQUZVO0lBRzFCWixNQUFNLEVBQUV1QixTQUFTLENBQUN2QixNQUhRO0lBSTFCVSxPQUFPLEVBQUVhLFNBQVMsQ0FBQ2IsT0FKTztJQUsxQjtJQUNBTSxRQUFRLEVBQUUsQ0FBQztNQUFDZ0MscUJBQXFCLEVBQUUsS0FBeEI7TUFBK0JWO0lBQS9CLENBQUQsRUFBMENlLE1BQTFDLENBQ1I5QixTQUFTLENBQUNQLFFBREY7RUFOZ0IsQ0FBNUI7O0VBVUEsSUFBSSw2Q0FBSixFQUE0QjtJQUMxQmMsUUFBUSxDQUFDckQsS0FBVCxHQUFpQjhDLFNBQVMsQ0FBQzlDLEtBQTNCO0VBQ0Q7O0VBQ0QsT0FBT3FELFFBQVA7QUFDRDs7QUFFTSxTQUFTWiw0QkFBVCxDQUFzQ0ssU0FBdEMsRUFBNEQ7RUFDakUsTUFBTTtJQUFDUCxRQUFEO0lBQVdKLElBQVg7SUFBaUJaLE1BQWpCO0lBQXlCVSxPQUF6QjtJQUFrQ0QsZUFBbEM7SUFBbUR3QjtFQUFuRCxJQUEwRFYsU0FBaEU7O0VBRUEsSUFBSSw2Q0FBSixFQUE0QjtJQUMxQixJQUFJZ0MsY0FBSixFQUFvQkMsZUFBcEI7O0lBQ0EsSUFBSWpDLFNBQVMsQ0FBQzlDLEtBQWQsRUFBcUI7TUFDbkI4RSxjQUFjLEdBQUdoQyxTQUFTLENBQUM5QyxLQUFWLENBQWdCNkIsU0FBakM7TUFDQWtELGVBQWUsR0FBR2pDLFNBQVMsQ0FBQzlDLEtBQVYsQ0FBZ0I4QixVQUFsQztJQUNEO0VBQ0Y7O0VBRUQsSUFBSSw2Q0FBSixFQUE0QjtJQUMxQixJQUFJYixjQUFKO0VBQ0Q7O0VBRUQsTUFBTStELGFBQWEsZ0JBQUdqRyxLQUFLLENBQUNrRyxVQUFOLENBQXNDLENBQUMxRixLQUFELEVBQVEyRixHQUFSLEtBQWdCO0lBQzFFLE1BQU1wQyxTQUF5QixHQUFHL0QsS0FBSyxDQUFDZ0MsVUFBTixDQUFpQmpDLGdCQUFqQixDQUFsQztJQUNBLE1BQU1rQyxXQUFXLEdBQUdqQyxLQUFLLENBQUNnQyxVQUFOLENBQWlCN0Isa0JBQWpCLENBQXBCO0lBQ0EsTUFBTU8sU0FBUyxHQUFHVixLQUFLLENBQUNnQyxVQUFOLENBQWlCOUIsZ0JBQWpCLENBQWxCO0lBQ0FxQixlQUFlLENBQUN3QyxTQUFELENBQWY7SUFFQSxNQUFNcUMsWUFBaUIsR0FBR0MsZ0JBQWdCLENBQUM3RixLQUFELENBQTFDO0lBQ0EsSUFBSThCLEtBQUssR0FBR2dFLFlBQVksQ0FBQ3JELGVBQUQsRUFBa0JPLFFBQWxCLEVBQTRCaEQsS0FBNUIsQ0FBeEI7O0lBRUEsSUFBSUEsS0FBSyxDQUFDK0YsTUFBVixFQUFrQjtNQUNoQixJQUFJLE9BQU8vRixLQUFLLENBQUMrRixNQUFiLEtBQXdCLFVBQTVCLEVBQXdDO1FBQ3RDakUsS0FBSyxHQUFHZ0QsU0FBUyxDQUFDaEQsS0FBRCxFQUFROUIsS0FBSyxDQUFDK0YsTUFBTixDQUFhL0YsS0FBYixDQUFSLENBQWpCO01BQ0QsQ0FGRCxNQUVPO1FBQ0w4QixLQUFLLEdBQUdnRCxTQUFTLENBQUNoRCxLQUFELEVBQVE5QixLQUFLLENBQUMrRixNQUFkLENBQWpCO01BQ0Q7SUFDRjs7SUFFRCxNQUFNQyxnQkFBZ0IsR0FBR2hFLE1BQU0sQ0FBQ0YsS0FBRCxFQUFReUIsU0FBUixDQUEvQjtJQUNBLE1BQU0wQyxPQUFPLEdBQUdqRyxLQUFLLENBQUNrRyxHQUFOLEdBQVlsRyxLQUFLLENBQUNrRyxHQUFsQixHQUF3QnRELElBQXhDO0lBQ0FnRCxZQUFZLENBQUM3RCxTQUFiLEdBQXlCL0IsS0FBSyxDQUFDK0IsU0FBTixHQUNwQixHQUFFL0IsS0FBSyxDQUFDK0IsU0FBVSxJQUFHaUUsZ0JBQWlCLEVBRGxCLEdBRXJCQSxnQkFGSjs7SUFJQSxJQUFJLGlEQUEwQnZFLFdBQTFCLElBQXlDLENBQUN2QixTQUE5QyxFQUF5RDtNQUN2RCxJQUFJLENBQUN3QixjQUFMLEVBQXFCO1FBQ25CQSxjQUFjLEdBQUdELFdBQVcsQ0FBQ2hCLEtBQVosQ0FBa0I7VUFDakM2QixTQUFTLEVBQUVpRCxjQURzQjtVQUVqQ2hELFVBQVUsRUFBRWlEO1FBRnFCLENBQWxCLENBQWpCO01BSUQ7O01BRUQsTUFBTVcsTUFBTSxHQUFJLEdBQUV6RSxjQUFlLElBQUdrRSxZQUFZLENBQUM3RCxTQUFVLEVBQTNEO01BQ0E2RCxZQUFZLENBQUM3RCxTQUFiLEdBQXlCb0UsTUFBekI7SUFDRDs7SUFFRCxJQUFJLGlEQUEwQnZGLE1BQU0sQ0FBQ0Msc0JBQXJDLEVBQTZEO01BQzNERCxNQUFNLENBQUNDLHNCQUFQLENBQThCdUYsU0FBOUIsQ0FBd0NDLEdBQXhDLENBQ0VULFlBQVksQ0FBQzdELFNBRGYsRUFFRUQsS0FGRjs7TUFJQSxJQUFJbUMsR0FBSixFQUFTO1FBQ1ByRCxNQUFNLENBQUNDLHNCQUFQLENBQThCeUYsYUFBOUIsQ0FBNENELEdBQTVDLENBQ0VULFlBQVksQ0FBQzdELFNBRGYsRUFFRTtVQUNFYSxJQUFJLEVBQUVxQixHQUFHLENBQUNyQixJQURaO1VBRUV3QixXQUFXLEVBQUVILEdBQUcsQ0FBQ0UsSUFGbkI7VUFHRW9DLGFBQWEsRUFBRXRDLEdBQUcsQ0FBQ3hCLGVBQUosQ0FBb0IsRUFBcEIsRUFBd0J6QyxLQUF4QixDQUhqQjtVQUlFd0csY0FBYyxFQUNaLE9BQU92QyxHQUFHLENBQUNDLElBQVgsS0FBb0IsVUFBcEIsR0FBaUNELEdBQUcsQ0FBQ0MsSUFBSixDQUFTbEUsS0FBVCxDQUFqQyxHQUFtRGlFLEdBQUcsQ0FBQ0M7UUFMM0QsQ0FGRjtNQVVEO0lBQ0Y7O0lBRUQsSUFBSWxFLEtBQUssQ0FBQ3lHLElBQVYsRUFBZ0I7TUFDZDtNQUNBckYsT0FBTyxDQUFDQyxJQUFSLENBQ0UsdUdBREY7SUFHRDs7SUFDRCxvQkFBTyxvQkFBQyxPQUFELGVBQWF1RSxZQUFiO01BQTJCLEdBQUcsRUFBRUQsR0FBRyxJQUFJM0YsS0FBSyxDQUFDeUc7SUFBN0MsR0FBUDtFQUNELENBN0RxQixDQUF0QjtFQStEQSxNQUFNQyxPQUFPLEdBQUdoRSxPQUFPLENBQUMrQyxhQUFELENBQXZCO0VBQ0FpQixPQUFPLENBQUM1RCxhQUFSLEdBQXdCO0lBQ3RCRixJQURzQjtJQUV0QkksUUFGc0I7SUFHdEJoQixNQUhzQjtJQUl0QlUsT0FKc0I7SUFLdEJEO0VBTHNCLENBQXhCOztFQVFBLDJDQUFhO0lBQ1gsSUFBSTJCLFdBQUo7O0lBRUEsSUFBSSxPQUFPeEIsSUFBUCxLQUFnQixRQUFwQixFQUE4QjtNQUM1QndCLFdBQVcsR0FBR3hCLElBQWQ7SUFDRCxDQUZELE1BRU8sSUFBSUEsSUFBSSxDQUFDd0IsV0FBVCxFQUFzQjtNQUMzQkEsV0FBVyxHQUFHeEIsSUFBSSxDQUFDd0IsV0FBbkI7SUFDRCxDQUZNLE1BRUEsSUFBSXhCLElBQUksQ0FBQ3VCLElBQVQsRUFBZTtNQUNwQkMsV0FBVyxHQUFHeEIsSUFBSSxDQUFDdUIsSUFBbkI7SUFDRCxDQUZNLE1BRUE7TUFDTEMsV0FBVyxHQUFHLFNBQWQ7SUFDRDs7SUFFRHNDLE9BQU8sQ0FBQ3RDLFdBQVIsR0FBdUIsVUFBU0EsV0FBWSxHQUE1QztFQUNEOztFQUVELE9BQU9zQyxPQUFQO0FBQ0QsQyxDQUVEOzs7QUFFTyxTQUFTWixZQUFULENBQ0xyRCxlQURLLEVBRUxPLFFBRkssRUFHTGhELEtBSEssRUFJUTtFQUNiLElBQUltRixNQUFNLEdBQUcxQyxlQUFlLEVBQTVCO0VBQ0EsSUFBSWtFLENBQUMsR0FBRzNELFFBQVEsQ0FBQ3FCLE1BQWpCOztFQUNBLE9BQU9zQyxDQUFDLEVBQVIsRUFBWTtJQUNWO0lBQ0EsTUFBTXJDLE9BQU8sR0FBR3RCLFFBQVEsQ0FBQzJELENBQUQsQ0FBUixDQUFZckMsT0FBNUI7SUFJQWEsTUFBTSxHQUFHYixPQUFPLENBQUNhLE1BQUQsRUFBU25GLEtBQVQsQ0FBaEI7RUFDRDs7RUFDRCxPQUFPbUYsTUFBUDtBQUNEOztBQUVELFNBQVN5QixRQUFULENBQWtCQyxDQUFsQixFQUEwQjtFQUN4QixPQUFPLE9BQU9BLENBQVAsS0FBYSxRQUFiLElBQXlCQSxDQUFDLEtBQUssSUFBdEM7QUFDRDs7QUFFRCxTQUFTaEIsZ0JBQVQsQ0FBMEJpQixNQUExQixFQUFrQztFQUNoQyxNQUFNM0IsTUFBTSxHQUFHLEVBQWY7O0VBRUEsS0FBSyxNQUFNNEIsR0FBWCxJQUFrQkQsTUFBbEIsRUFBMEI7SUFDeEIsSUFBSUMsR0FBRyxDQUFDLENBQUQsQ0FBSCxLQUFXLEdBQWYsRUFBb0I7TUFDbEI1QixNQUFNLENBQUM0QixHQUFELENBQU4sR0FBY0QsTUFBTSxDQUFDQyxHQUFELENBQXBCO0lBQ0Q7RUFDRjs7RUFFRCxPQUFPNUIsTUFBUDtBQUNEOztBQUVELFNBQVNMLFNBQVQsQ0FBbUJrQyxDQUFuQixFQUFzQkMsQ0FBdEIsRUFBeUI7RUFDdkIsTUFBTTlCLE1BQU0sR0FBRytCLE1BQU0sQ0FBQyxFQUFELEVBQUtGLENBQUwsQ0FBckI7O0VBRUEsS0FBSyxNQUFNRCxHQUFYLElBQWtCRSxDQUFsQixFQUFxQjtJQUNuQixNQUFNRSxHQUFHLEdBQUdGLENBQUMsQ0FBQ0YsR0FBRCxDQUFiOztJQUVBLElBQUlILFFBQVEsQ0FBQ08sR0FBRCxDQUFSLElBQWlCUCxRQUFRLENBQUNJLENBQUMsQ0FBQ0QsR0FBRCxDQUFGLENBQTdCLEVBQXVDO01BQ3JDNUIsTUFBTSxDQUFDNEIsR0FBRCxDQUFOLEdBQWNqQyxTQUFTLENBQUNrQyxDQUFDLENBQUNELEdBQUQsQ0FBRixFQUFTSSxHQUFULENBQXZCO0lBQ0QsQ0FGRCxNQUVPO01BQ0xoQyxNQUFNLENBQUM0QixHQUFELENBQU4sR0FBY0ksR0FBZDtJQUNEO0VBQ0Y7O0VBRUQsT0FBT2hDLE1BQVA7QUFDRDs7QUFFRCxTQUFTTixZQUFULENBQXNCbUMsQ0FBdEIsRUFBeUJDLENBQXpCLEVBQTRCO0VBQzFCLE9BQU9DLE1BQU0sQ0FBQ0EsTUFBTSxDQUFDLEVBQUQsRUFBS0YsQ0FBTCxDQUFQLEVBQWdCQyxDQUFoQixDQUFiO0FBQ0Q7O0FBRUQsU0FBU0MsTUFBVCxDQUFnQkUsTUFBaEIsRUFBd0JOLE1BQXhCLEVBQWdDO0VBQzlCLEtBQUssTUFBTUMsR0FBWCxJQUFrQkQsTUFBbEIsRUFBMEI7SUFDeEJNLE1BQU0sQ0FBQ0wsR0FBRCxDQUFOLEdBQWNELE1BQU0sQ0FBQ0MsR0FBRCxDQUFwQjtFQUNEOztFQUNELE9BQU9LLE1BQVA7QUFDRCJ9