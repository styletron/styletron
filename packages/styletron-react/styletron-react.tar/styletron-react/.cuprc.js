module.exports = {
  babel: {
    presets: [require.resolve('@babel/preset-react')],
  },
};
